(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
var rect; // used to reference frame bounds
lib.ssMetadata = [];


// symbols:



(lib.Image = function() {
	this.initialize(img.Image);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.mc_nowstime = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYDCQgLgKAAgQQAAgPALgLQAKgKAOAAQAPAAAKAKQALAMAAAOQAAAQgLAKQgKAKgPAAQgOAAgKgKgAgTBhIgLkGIAAgmIA+AAIAAAmIgLEGg");
	this.shape.setTransform(555.775,28.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AguB0IAAi6IgkAAIAAgpIAkAAIAAhTIA7AAIAABTIBDAAIAAApIhDAAIAACzQAAAXAKAKQAKAIAXABIAbAAIAAAlQgWAGgaABQhRAAAAhPg");
	this.shape_1.setTransform(536.875,29.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhSByQgngpAAhIQAAhHArgrQApgqBBAAQA0AAAnAZIAAAuIgZAAQgZgZgqAAQgnAAgYAdQgZAdAAA0QAAA2AYAcQAXAcAoAAQAvAAAbgeIAWAAIAAArQgnAgg6AAQhEAAgngqg");
	this.shape_2.setTransform(511.775,33.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AheCFQgbgZAAgrQAAgtAhgXQAfgXA2AAQAgAAAhAIIAAgoQAAg0g9AAQgwAAgiAZIgTAAIAAgsQA1gaA3AAQByAAAABdIAADWIgYAAQgSAAgHgGQgHgHgCgUQgjAlg3AAQgrAAgZgXgAg/A+QAAA1A4AAQAmAAAfgjIAAhAQgcgGgdAAQhEAAAAA0g");
	this.shape_3.setTransform(480.375,33.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhlBxQgngqAAhHQAAhFAngrQAngpA+AAQA/AAAnApQAnAqgBBGQABBIgnApQgnApg/AAQg+AAgngpgAhQhgQgfAkAAA8QAAA+AfAjQAdAiAzAAQAzAAAegiQAdgjABg+QgBg8gdgkQgegigzgBQgzABgdAig");
	this.shape_4.setTransform(433.45,33.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AglB+IAAjVIgoAAIAAgWIAoAAIAAhVIAdAAIAABVIBPAAIAAAWIhPAAIAADSQAAAaAMAMQAMAKAcAAIAiAAIAAAUQgSAEgaAAQhHAAAAhFg");
	this.shape_5.setTransform(407.3,29.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhcBwQgkgoAAhHQAAhFAlgrQAmgqA5AAQA7AAAfAiQAjAkAABHIgBANIjjAAQAACBByAAQA/AAAfgfIAMAAIAAAVQgqAihDAAQhDAAglgqgABkgTQgChwheAAQgqAAgbAcQgcAdgFA3IDGAAIAAAAg");
	this.shape_6.setTransform(367.3,33.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AC0CZIAAjfQAAg5g4AAQgwAAg9AwIAADoIgcAAIAAjfQAAg5g4AAQgzAAg7AxIAADnIgdAAIAAktIANAAQAKAAADAFQADAFAAAUIAAAPQA+gxA7AAQA6AAANAyQA6gyA/AAQBLAAAABKIAADng");
	this.shape_7.setTransform(326.225,33.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgODCIAAktIAJAAQAMAAAEAFQADAGAAAUIAAEOgAgTitQAAgIAGgGQAGgGAHAAQAJAAAFAGQAGAGAAAIQAAATgUABQgTgBAAgTg");
	this.shape_8.setTransform(293.975,29);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AglB+IAAjVIgoAAIAAgWIAoAAIAAhVIAdAAIAABVIBQAAIAAAWIhQAAIAADSQAAAaAMAMQAMAKAcAAIAiAAIAAAUQgSAEgaAAQhHAAAAhFg");
	this.shape_9.setTransform(278.05,29.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhcBwQgkgoAAhHQAAhFAlgrQAmgqA5AAQA7AAAfAiQAjAkAABHIgBANIjjAAQAACBByAAQA/AAAfgfIAMAAIAAAVQgqAihDAAQhDAAglgqgABkgTQgChwheAAQgpAAgcAcQgcAdgFA3IDGAAIAAAAg");
	this.shape_10.setTransform(238.05,33.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ABbDLIAAjcQAAg8g8AAQg2AAhDAzIAADlIgdAAIAAmVIAKAAQANAAADAFQADAEAAATIAAB8QBBg0BDAAQBOAAAABRIAADgg");
	this.shape_11.setTransform(205.875,28.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AglB+IAAjVIgoAAIAAgWIAoAAIAAhVIAdAAIAABVIBPAAIAAAWIhPAAIAADSQAAAaAMAMQAMAKAbAAIAjAAIAAAUQgTAEgaAAQhGAAAAhFg");
	this.shape_12.setTransform(179.55,29.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhnB+IAAgZIAMAAQAgAeA1AAQBRAAAAhBQAAgbgSgMQgRgNgtgHQgvgHgXgRQgZgTAAglQAAgmAdgWQAagUAuAAQA1AAAiAWIAAAYIgLAAQgegYguAAQhJAAgBA3QABAaARANQARAMArAIQAzAHAWARQAaATgBAmQABBahtAAQg7AAgngcg");
	this.shape_13.setTransform(141.85,33.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgXAbQAWgFAAgRQAAgGgKgGQgJgGAAgLQAAgUAVAAQAXAAAAAfQAAAxgvAJg");
	this.shape_14.setTransform(123.775,12.025);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("ABRCXIhQj+IgBAAIhOD+IgbAAIhYkiIAAgLIAbAAIBMEBIABAAIBQkBIAYAAIBNEBIACAAIBMkBIAXAAIAAALIhXEig");
	this.shape_15.setTransform(97.15,33.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AhlBxQgngqAAhHQAAhFAngrQAmgpA/AAQBAAAAlApQAnAqAABGQAABIgnApQglAphAAAQg/AAgmgpgAhQhgQgeAkgBA8QABA+AeAjQAdAiAzAAQA0AAAdgiQAegjgBg+QABg8gegkQgdgig0gBQgzABgdAig");
	this.shape_16.setTransform(58.8,33.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AB1DLIjplsIgBAAIAAFsIgdAAIAAmVIAmAAIDhFdIAAAAIAAldIAeAAIAAGVg");
	this.shape_17.setTransform(21.75,28.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_nowstime, rect = new cjs.Rectangle(0,0,567,62), [rect]);


(lib.mc_logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgzAwQgUgUAAgcQAAgcAUgUQATgUAcAAQAVAAASAOIAAgLIAlAAIAACDIglAAIAAgMQgTAPgUAAQgcAAgTgVgAgYgYQgLAKAAAOQAAAOALAKQAKALAOAAQAOAAAKgLQALgKAAgOQAAgOgLgKQgKgLgOAAQgOAAgKALg");
	this.shape.setTransform(37.575,55.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgsBDIAAiDIAkAAIAAALQAKgKAPgDQAOgCAOAEIAAAiQgNgCgKACQgMACgJAKQgJAKAAAMIAAA/g");
	this.shape_1.setTransform(25.825,55.0019);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA6BcIgSgfIhQAAIgSAfIguAAIBoi3IBpC3gAAVAaIgVgjIgUAjIApAAg");
	this.shape_2.setTransform(10.55,52.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AiJDCIDemDIA1BcIiqEng");
	this.shape_3.setTransform(13.8,19.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgzgsIBnAAIg0BZg");
	this.shape_4.setTransform(27.85,23.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgzAtIAzhZIA0BZg");
	this.shape_5.setTransform(33.7,24.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgzgsIBnAAIg0BZg");
	this.shape_6.setTransform(33.725,33.875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgzgsIBnAAIg0BZg");
	this.shape_7.setTransform(22,33.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgzAtIAzhZIA0BZg");
	this.shape_8.setTransform(39.55,34.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgzAtIAzhZIA0BZg");
	this.shape_9.setTransform(27.85,34.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_logo, rect = new cjs.Rectangle(0,0,44.8,62), [rect]);


(lib.mc_headline = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiOCkIAAlHIB/AAQBAAAAwAvQAuAuAABCIAAAJQAABCguAuQgwAvhAAAgAiLChIB8AAQBAAAAugtQAtguAAhBIAAgJQAAhBgtgtQguguhAAAIh8AAg");
	this.shape.setTransform(-139.3568,-0.046,0.662,0.662);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah8CQIAAkfIBuAAQA5AAApApQApApAAA6IAAAIQAAA6gpAoQgoApg6AAgAhSBpIBBAAQApAAAegeQAdgdAAgrIAAgFQAAgqgdgeQgegegpAAIhBAAg");
	this.shape_1.setTransform(-139.3568,-0.046,0.662,0.662);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag4CjIAAgQIAbAAQAGAAAEgFQAFgFAAgGIAAkEQAAgFgFgGQgEgFgGAAIgbAAIAAgRIBxAAIAAARIgbAAQgGAAgFAFQgFAGAAAFIAAEEQAAAFAFAGQAFAFAGAAIAbAAIAAAQg");
	this.shape_2.setTransform(-125.0897,0.2356,0.662,0.662);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgVB4IAAjvIArAAIAADvg");
	this.shape_3.setTransform(-116.864,0.0701,0.662,0.662);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhBAWIAAgrICDAAIAAArg");
	this.shape_4.setTransform(-111.0877,9.4544,0.662,0.662);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAWA3IAAhBIhWAAIAAgsICBAAIAABtg");
	this.shape_5.setTransform(-108.2079,4.3567,0.662,0.662);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhBAWIAAgrICDAAIAAArg");
	this.shape_6.setTransform(-111.0877,-9.3142,0.662,0.662);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgVAWIAAgrIArAAIAAArg");
	this.shape_7.setTransform(-105.3115,-6.4344,0.662,0.662);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAjCjIA1g2IgSA2gAgQCjIAzg2IAjAAIg0A2gAhFCjIBohsIgRA2Ig0A2gAhFBtIAjAAIg1A2gAgiBtgAgQA3IAzg3IgRA3Ig0A2gAgQAAIAzg1IgRA1Ig0A3gAgQg1IAzg3IgRA3Ig0A1gAgQhsIAzg2IAjAAIhoBtgAAjhsIA0g2IgRA2gAhFhsIA0g2IAiAAIgzA2gAhGiiIAkAAIg1A2g");
	this.shape_8.setTransform(-95.526,0.0543,0.6621,0.6621);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AggCkIAAkFIhBAAIAAhCIDDAAIAABCIhBAAIAAEFg");
	this.shape_9.setTransform(-81.1755,0.0874,0.6621,0.6621);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("ABuClQgOAAgGgJIgZg3IhjAAIgVA5QgDAHgNAAIg/AAQgIAAAAgFIABgIIBxkuQAFgOAPAAQAOAAAGAOICCEvIABAGQAAAGgLAAgAAGgaIgaBMIgBADQAAAEAFAAIA6AAQAFAAAAgEIAAgCIgihNQAAgBgBAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAABgBAAQAAABAAAAg");
	this.shape_10.setTransform(-65.242,0.0701,0.662,0.662);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_11.setTransform(-40.5647,9.5537,0.662,0.662);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_12.setTransform(-44.3383,9.5537,0.662,0.662);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_13.setTransform(-48.1284,9.5537,0.662,0.662);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_14.setTransform(-51.9185,9.5537,0.662,0.662);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_15.setTransform(-51.9185,5.747,0.662,0.662);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_16.setTransform(-51.9185,1.9734,0.662,0.662);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_17.setTransform(-51.9185,-1.8333,0.662,0.662);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_18.setTransform(-51.9185,-5.6069,0.662,0.662);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_19.setTransform(-51.9185,-9.4136,0.662,0.662);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AheCjQgHAAgGgEQgEgFAAgHIAAgvQAAgHAEgEQAGgFAHAAIAsAAIAAinIgsAAQgHAAgGgEQgEgFAAgHIAAgvQAAgHAEgFQAGgEAHAAIC+AAQAHAAAEAEQAFAFAAAHIAAAvQAAAHgFAFQgEAEgHAAIgsAAIAACnIAsAAQAHAAAEAFQAFAFAAAGIAAAvQAAAHgFAFQgEAEgHAAg");
	this.shape_20.setTransform(-21.875,-0.0742,0.6621,0.6621);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("ABGCkIAAlHIAkAAIAAFHgAhpCkIAAlHIAjAAIAAFHgAgzhFIAAhZIBnDNIAABWg");
	this.shape_21.setTransform(-4.5948,-0.0908,0.6621,0.6621);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ABcCkIiijDIAADDIhGAAIAAlHIA1AAICfDEIAAjEIBEAAIAAFHgABmCOIASAAIAAkbIgbAAIAADqIi+jqIgVAAIAAEbIAaAAIAAjog");
	this.shape_22.setTransform(14.44,-0.0908,0.6621,0.6621);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgNCgQgFADgIAAQgLAAgGgIIgGABQgKAAgGgHQgHgGAAgJQgFgBgEgDQgFADgEAAQgKAAgHgHQgHgHAAgJIABgEQgJgGAAgMIAAAAQgEgGAAgHIABgGQgMgHAAgNQAAgJAIgIQgCgDAAgFQgKgHAAgMQAAgGAFgGIgBgDQAAgLAIgGQgGgGAAgKQAAgKAHgHIgBgGQAAgIAFgGQAFgGAHgCQgDgFAAgHQAAgIAFgHQAGgGAIgBQACgPAOgFQAEgNANgDQAHgHAKAAIAGABQAGgFAIAAQAGAAAEACQAFgDAHAAQAIAAAGAGQAGgFAIAAQAMAAAHAKIAGgBQAQAAAFAOQAMAAAHALIADAAQAJAAAHAHQAHAGAAAKIgBAFQAJAGAAAMQAAAGgCAEQAIACAEAGQAFAHAAAHQAAAGgDAGQADAGAAAFQAAAEgCAFIACAHQAEAGAAAHQAAAFgCADIACAJQAAAHgEAGIAAADQAAAEgCAFQACAFAAADQAAANgLAHQgBALgLAGIgBADIACAJQAAAJgGAHQgGAGgJABQgGAKgLACQAAAJgHAHQgGAHgKAAQgHAAgFgEQgEACgGAAIgEAAQAAAJgHAGQgHAGgJAAQgMAAgHgLgAgNB5QAHgHAJAAQAHAAADACQAGgKALgCQADgHAFgEQAHgFAHAAIAHABQAEgDAGgDIAAgEQAAgOAMgHQACgKAJgGIABgFQgBgEAAgFQAAgHAEgGIAAgDIABgJQgBgDAAgEQgEgGAAgHQAAgEABgEQgBgEAAgFIABgHQgNgGAAgPQAAgGADgGQgGgGAAgJIAAAAQgNgBgGgNQgGgEgDgHIgGAAQgEACgGAAQgMAAgGgKQgFADgHAAQgHAAgFgDQgHAHgKAAQgHAAgGgFIgCABIgJAGQgCAFgFAFIABAGQAAAPgOAGIABAGQAAAIgGAHQgGAHgJABQALAHAAAMQAAANgMAHQAAAGgEAEIABADIAAABQAJAHAAALIAAAEQACAFAAAFQAAALgHAGQAKAIAAAMIAAAAQAEAGAAAHIAAACQAEgCAFAAQAJAAAHAHQAGAGABAJQAHACAFAGIAGgBQAHAAAGAEg");
	this.shape_23.setTransform(35.1796,-0.0742,0.6621,0.6621);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgNCjIhskhQgCgHgHgGQgGgGgHAAIgMAAIAAgRIBoAAIAAARIgvAAIBvE0gAALBwIBUjlQAKgcgZAAIgYAAIAAgRIBkAAIAAARIgLAAQgHAAgHAFQgGAGgDAIIhlEMg");
	this.shape_24.setTransform(53.1657,-0.1266,0.662,0.662);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("ABcClIAAAAIAAhkIgDAAIAAgHIADAAIAAgGIACAAIAAgEIgkAAIAAAEIgFAAIAAgEIhpAAIAAAEIgGAAIAAgEIgkAAIAAAEIADAAIAAAGIADAAIAAAHIgDAAIAABkIAAAAQgFACgHAAIgCAAIgKgCIAAhkIgDAAIAAgHIADAAIAAgGIACAAIAAgbIgCAAIAAgHIgDAAIAAgGIADAAIAAhHIgDAAIAAgFIADAAIAAgKIACAAIAAgDQABgGAFgFIAEgCIgCgDIAGgEIgCgCIAEgEIACADIBHg4IgCgCIAEgDIACACIAHgGIADADIABgBQADgDAGgBQAGABAEADIABABIACgDIAHAGIACgCIAFADIgCACIBHA4IACgDIAEAEIgBACIAFAEIgCADIAEACQAGAFgBAGIAAADIADAAIAAAKIADAAIAAAFIgDAAIAABHIADAAIAAAGIgDAAIAAAHIgDAAIAAAbIADAAIAAAGIADAAIAAAHIgDAAIAABkIAAAAIgLACQgJAAgEgCgAhwBfIAAAGQAAABAAAAQAAAAAAABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAgBAAAAQAAAAAAgBIAAgGIgCgBQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAAAgAhwA5IAAAhQAAAAAAAAQAAAAAAABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAgBAAAAQAAAAAAAAIAAghIgCgBQAAAAAAABQAAAAgBAAQAAAAAAAAQAAAAAAAAgAARAiQAAAAAAAAQAAAAAAABQAAAAAAAAQABAAAAAAIAgAAQAAAAABAAQAAAAAAAAQAAgBAAAAQABAAAAAAIgCgCIggAAQAAAAgBAAQAAAAAAAAQAAABAAAAQAAAAAAABgAAEAiQAAAAABAAQAAAAAAABQAAAAAAAAQABAAAAAAIAGAAQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQgBAAAAAAIgGAAQAAAAgBAAQAAAAAAAAQAAABAAAAQgBAAAAABgAA6AZIAAADIAkAAIAAgDIgCAAIAAgHIgDAAIAAgGIADAAIAAhHIgDAAIAAgFIADAAIAAgLIgGgEIgCACIgEgCIACgDIhHg3IgCADIgEgEIACgCIgHgFIAAAAIgGAFIACACIgEAEIgCgDIhHA3IACADIgFACIgCgCIgFAEIAAALIADAAIAAAFIgDAAIAABHIADAAIAAAGIgDAAIAAAHIgDAAIAAADIAkAAIAAgDIAGAAIAAADIBpAAIAAgDgABfgbIAAAFQAAABABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABgBIAAgFQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAABAAAAQgBAAAAABgAhwgbIAAAFQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIACgBIAAgFQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAABgABfhCIAAAgQAAABABAAQAAAAAAABQAAAAAAAAQABAAAAAAIABgCIAAggQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAABAAAAQgBAAAAAAgAhwhCIAAAgQAAABAAAAQAAAAAAABQABAAAAAAQAAAAAAAAIACgCIAAggQAAAAAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAAAgAhnhVQgDABgBACQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAgBAAAAQAAgEADAAIABgBIAAgBIgBgCIgBABgAAEigIACAAIABgBIgBgBQgCgCgEAAIgFACQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAIABAAIABAAQAAAAABAAQAAAAAAgBQABAAAAAAQABAAAAAAQAAAAABAAQABAAAAAAQABABAAAAQABAAAAAAg");
	this.shape_25.setTransform(70.8751,-0.1266,0.662,0.662);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgFAHQgDgDAAgEQAAgDADgDQACgCADAAQAEAAADACQACADAAADQAAAEgCADQgDACgEAAQgDAAgCgCg");
	this.shape_26.setTransform(70.8585,-3.023,0.662,0.662);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgLCiIgGgDQgEgBAAgDIgBgLQgCgKgDh7IgCgvQAAgOACg1IgBgCIgBAAQgcgBg+gFQgEgBgBgBIgCgDQAAgGAGgBIABAAIAAgKQgHAAAAgEIADgUQABgEAEgBQAZgHBrAGIBpAHQAFAAABAFIACASIgBADIgDACIgEAAIgBALIAEACIACACQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAIgCAEIgBABIhkAAIgBABIAIBpQABAUgBBIIAAAjIgCAjIAAAAIgCACQgDACgDAAIgDAAIgFAAIgBAAIAAAAIgBAAIgCABQgEAAgNgFgAAKCgIABABIAEACIADAAIABgNIgKAAgAAFhNIgBACQAFBPgCATQgBATAAAqQgBArACADQAFAAAHgCQABAAAAgBQAAAAAAAAQABAAAAgBQAAAAAAgBQgGhfABgTQACgNgDhKQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAIgFAAgAAEhgIAJACIAAAAIAAgOIAAAAIgJgBgAhniEIAAALIDNAEIAAgNQhzgEg0AAQgeAAgIACg");
	this.shape_27.setTransform(87.2829,0.1284,0.6621,0.6621);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AhwB4QgjgsAAhMQABgyARgfQAOgaAggZQAZgRAVgIQAXgJAdABQCEAAABCWQAAA2gTAmQgPAegfAaQgXASgVAIQgWAIgZAAQhDgBglgugAg/huQgRAZAAA8QAABRAZAoQAYAmAvAAQAQAAAJgDQALgFAIgLQAVgfAAhMQAAhLgXghQgXgfgwAAQghAAgRAVg");
	this.shape_28.setTransform(105.2441,0.0085,0.6621,0.6621);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgqDFQgJgCgGgCIgOgFQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAIgCgHIABgJQACgIgBgEIgFgXIgIgZQgDgGADgXIADgbIgGgSIgFgTIgCgMIgHgPQgBgGAAgGIABgFIgGgEQAOgtABgIQAAgHgGgWQgCgGAAgFIAAgEQgBgHAFgIIAIgKQAEgEAZgNQAEgDACgFIAFgHIAIgGQAEgCAEgBIgBgBQACgBAEABIAAgCQACAAADAFQADgEADAEIAAAAIAEAGQACABADAIIgBAIQAAABABABQAAAAAAABQABAAAAAAQABABABAAQAAAGgEADQgBAAAAAAQgBAAgBABQAAAAgBAAQAAAAgBAAIgBgBIgDADIAEABQAEACAHgEQABAAAAAAQABAAAAgBQAAAAAAgBQAAgBAAgBQgDgHAFgEIADgEQAHgDALAHIAMAHIAIACIAKAAIAMACQAMAEAGAMQACAFAIACQAGAEgBAGQgBgCgDgEQgEgCgCAAIADAFIAEAEQAHAIgBAIQgDgJgIgFIADAHQACAFgCADIgCgGIAAAEIAAAAQgBAJAFAHQgEgCgCgEIgBABQgEALgCAPQgNAsgOAHQgLAGgYAAIgUAAIgCAGIAQAVIAEAAIAFAAIABAAQABAAAAABQAAAAAAAAQABAAAAABQAAAAAAABIAAAGIgBACIADACIABAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAIAAAJIADAGIADAFQABACABAFIACAGIACAAIAIADQAHAEAEAIQABADgCADIAEACIAFAAQADABAFAEQAEADACAEQAFAJgEAKIgBgHIgBAJIgBAGQAAgBgBAAQAAAAAAAAQAAABgBAAQAAABAAABQAAADACACIADAGIABAAIAEAGQABACAGACIADACIADAAQAAABABAAQAAAAgBAAQAAAAAAABQAAAAgBAAIABABQAAAAAAAAQAAABAAAAQAAAAgBAAQAAAAgBABQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAIgDgCIgEgCQgBAAAAAAQgBAAAAAAQAAABABAAQAAABABABIACADIAHAHIABABIAGAHQADADAGADQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAgBAAIgCACQAAAAAAAAQAAAAgBAAQAAAAgBAAQgBABgCAAIgFgDIgEgDIgBgBIACAGQABAAAAAAQAAABAAAAQAAAAAAAAQAAABgBAAQgDAAgCgFIgDgFIgHgHIgFgJIgLgJIgDAAQgBABAAAAQgBAAAAABQAAAAAAABQAAAAAAABIABADQgEgDAAgEIACgDQgBgBAAAAQgBAAgBgBQAAAAAAAAQgBABAAAAIgCAEIAAgBQgBgEABgCIADgDIgPgSQAAABAAABQAAAAAAABQgBAAAAABQgBAAAAAAQgEAAgEAFIgBgCQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAABgBQAAAAAAAAQABAAAAgBQAAAAAAgBQAAgBAAgBQgBABAAAAQgBAAAAAAQAAAAgBgBQAAAAAAAAIgBgBQAGACABgGQAAgBgCgGIgEgCIgGgDIgBgBIgBgEQAAgBgBAAQAAgBAAAAQgBAAAAAAQgBgBgBAAIgGgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIABgCIgDgEQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAAAQgDgCACgGIADgCIADgBQABgCgEgCQgLgEgIgFQgFgCgFgHIgHgJQgHgHgEgHQAAgBgBAAQAAgBgBAAQAAAAgBAAQgBAAAAAAQgBABAAAAQgBAAAAABQAAAAgBABQAAAAAAABIgDAPIgDAUIgEALQABAEgCAFIgBAgQgBAIACAHIADADIAMALIAPAGQAAADgFACIgLABIAHADIAFAEIgIgDIANAFQADACADADQAAABABAAQAAABAAAAQAAABAAAAQAAAAgBAAQgGACgGAAIgNgBIgFgCIAXAQQAFADACADQAAADgHADIgHABIgJgBgAgriHIgGABIgCACIgBACIgCACQAHAKABAMIAAAQIgCASIgCASQAKAJAIADIADgEIALgFQANgFAHAAQAQgCACgCQAFgDAKgaQACgDgDgFQgCgEAAgCIgDgFQgEgDABgCIACgJIgGAAQAAABgBAAQAAABAAAAQAAAAgBAAQAAABAAAAQgBAAgFgEIgGgBIgEgBIgDgCQgJgFgLgCIgUgDg");
	this.shape_29.setTransform(123.8982,0.0085,0.6621,0.6621);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgECmQg8AAg6gcQgIgDADgJIATgpQACgFAHAAIAEAAQA0AZAoABQA8AAABgiQAAgbgTgRQgJgIgggRQgdgOgMgMQgTgSABgdQAAgWASgPQAUgPAlAAQAjAAAlAPIALgZQgigOgxgBQgsgBgdAUQggAUgBAmQAAA7A6AbQAFADAAAFQAAADgDADQgDADgEAAIgFgBQhFghABhFQABgvAngZQAjgYAzABQAiAAAZAGQAUAFAVAKQAJAEgEAHIgSArQgCAFgHAAIgEgBQgmgRgkgBQg2gBgBAkQAAAWAPAOQAJAJAYANQAlARALALQAXAWAAAhQAAAVgPANQgUASguAAQgpgBgygWIgKAYQAwAXA0AAQAvABAegQQAjgUAAgoQABgjgSgYQgRgYgngRQgGgDAAgFQAAgFAFgDQAFgCAFACQBWAlgBBPQgBAugmAYQgiAXg4AAIgEAAg");
	this.shape_30.setTransform(140.3179,0.0086,0.6621,0.6621);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_headline, rect = new cjs.Rectangle(-148.8,-13.1,297.7,26.2), [rect]);


(lib.mc_course = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKALQgEgEAAgGQAAgGAEgFQAFgEAFAAQAGAAAEAEQAFAFAAAGQAAAGgFAEQgEAEgGAAQgFAAgFgEg");
	this.shape.setTransform(132,48.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgaBSIAAgHIARgnIgvhvIAAgGIAXAAIAjBXIAihXIAVAAIAAAGIg+Cdg");
	this.shape_1.setTransform(123.175,45.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgLBUIAAinIAMAAQAHAAACADQACADAAAKIAACXg");
	this.shape_2.setTransform(113.825,41.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgzAeIAAhdIAYAAIAABYQABATATAAQAPABATgMIAAhgIAZAAIAAB9IgQAAQgEAAgBgCQgCgDgCgJQgVAPgXAAQgiAAAAghg");
	this.shape_3.setTransform(103.85,43.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgpBMIAAgUIAKAAQAKAJAOAAQAWAAAAgYIAAh9IAbAAIAAB+QAAArgwAAQgUAAgPgJg");
	this.shape_4.setTransform(90.95,41.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAcBAIAAhWQAAgUgTAAQgOAAgWAMIAABeIgYAAIAAh9IAPAAQAFAAACADQACAEAAAJQAXgSAYAAQAgAAAAAjIAABcg");
	this.shape_5.setTransform(73.975,43.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgLBUIAAh9IAMAAQAHABACADQACADAAAMIAABqgAgJg7QgEgEAAgGQAAgFAEgEQAEgFAFAAQAGAAAEAFQAEAEAAAFQAAAGgEAEQgEAEgGABQgFgBgEgEg");
	this.shape_6.setTransform(64.075,41.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgSAwIAAhNIgPAAIAAgRIAPAAIAAgiIAXAAIAAAiIAcAAIAAARIgcAAIAABKQAAAJAFAFQADADAKAAIALAAIAAAQQgJADgKgBQghABAAghg");
	this.shape_7.setTransform(51.625,42.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AghA/IAAh8IAQAAQAEAAACADQACAEABAKQAPgSAUAAIAHABIAAAUIgGgBQgVAAgPAPIAABag");
	this.shape_8.setTransform(43.475,43.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgnA3QgKgKgBgSQAAgSAOgJQANgKAWAAQANAAAOADIAAgRQAAgUgZgBQgUAAgOAKIgIAAIAAgSQAWgLAWABQAwAAgBAmIAABYIgKAAQgHAAgDgCQgDgDgBgJQgOAPgWAAQgSAAgLgJgAgZAaQAAAWAWgBQAQAAANgOIAAgaQgMgDgMAAQgcAAABAWg");
	this.shape_9.setTransform(31.8,43.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgSAwIAAhNIgPAAIAAgRIAPAAIAAgiIAXAAIAAAiIAcAAIAAARIgcAAIAABKQAAAJAFAFQADADAKAAIALAAIAAAQQgJADgKgBQghABAAghg");
	this.shape_10.setTransform(21.725,42.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgrA1IAAgTIAIAAQAMALATAAQAZAAAAgSQAAgHgFgEQgFgFgPgCQgUgDgJgGQgKgKAAgQQAAgSAMgKQAMgJAUAAQAVAAAQAJIAAASIgIAAQgLgJgSAAQgWAAgBARQAAAHAHAEQAFAEAOACQAVADAKAIQAJAIABARQAAAngwAAQgXAAgRgLg");
	this.shape_11.setTransform(12.35,43.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgsA1IAAgTIAJAAQAMALATAAQAZAAAAgSQABgHgGgEQgFgFgPgCQgUgDgJgGQgLgKAAgQQAAgSANgKQAMgJAUAAQAVAAAPAJIAAASIgHAAQgMgJgRAAQgXAAAAARQABAHAFAEQAHAEANACQAVADAKAIQAKAIAAARQgBAnguAAQgZAAgRgLg");
	this.shape_12.setTransform(216.85,14.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgmAvQgQgRAAgeQAAgcAQgSQAQgRAZAAQA0gBAAA+IAAAHIhTAAQABApAjAAQAVAAAOgLIAIAAIAAARQgSANgcgBQgcABgPgSgAAfgKQgBgkgbAAQgcAAgDAkIA7AAIAAAAg");
	this.shape_13.setTransform(205,14.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgmAvQgQgRAAgeQAAgcARgSQAPgRAYAAQA1gBAAA+IAAAHIhTAAQABApAkAAQAUAAAPgLIAIAAIAAARQgUANgbgBQgbABgQgSgAAfgKQgBgkgcAAQgaAAgEAkIA7AAIAAAAg");
	this.shape_14.setTransform(192.2,14.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AghA/IAAh8IAQAAQAEAAACADQACAEABAKQAPgSAUAAIAHABIAAAUIgGgBQgVAAgPAPIAABag");
	this.shape_15.setTransform(181.675,14.875);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgxBKIAAgTIAIAAQAOALAXgBQAjAAAAgbIAAgOQgPAQgWAAQgVABgNgOQgPgQAAgdQAAghAQgRQAPgPAVAAQAWAAAOAOQACgMAKAAIALAAIAAB4QAAAWgQAMQgPALgaAAQgdAAgTgKgAgfgUQAAAqAfAAQARAAAOgPIAAg7QgMgMgQABQgiAAAAArg");
	this.shape_16.setTransform(169.3,16.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgmAvQgQgRAAgeQAAgcARgSQAQgRAXAAQA1gBAAA+IAAAHIhTAAQABApAjAAQAVAAAOgLIAJAAIAAARQgUANgbgBQgcABgPgSgAAfgKQgBgkgcAAQgaAAgEAkIA7AAIAAAAg");
	this.shape_17.setTransform(156.3,14.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgpBGQgOgRAAgfQAAghARgRQAOgPAUAAQAWAAANANIAAg2IAOAAQAHAAACADQACADAAALIAACWIgQAAQgEAAgCgDQgBgDgCgLQgPATgXAAQgVAAgNgPgAgfAVQABAuAeAAQAQAAAPgRIAAg/QgLgLgSAAQggAAgBAtg");
	this.shape_18.setTransform(142.6,12.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgMBUIAAiTIgwAAIAAgUIB5AAIAAAUIgwAAIAACTg");
	this.shape_19.setTransform(123.725,12.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgqA/QgVgWAAgpQABgnAVgXQAWgWAggBQAcAAAVAOIAAAVIgKAAQgPgPgXAAQgXABgNAQQgOARAAAfQAAAgANARQAMARAXAAQAZgBASgSIAIAAIAAAUQgUATgggBQghABgUgXg");
	this.shape_20.setTransform(109.4,12.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgMBUIAAinIAZAAIAACng");
	this.shape_21.setTransform(98.625,12.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgnAvQgPgRAAgeQAAgcARgSQAPgRAYAAQA1gBAAA+IAAAHIhTAAQABApAkAAQAUAAAPgLIAIAAIAAARQgUANgbgBQgbABgRgSgAAfgKQgBgkgcAAQgbAAgDAkIA7AAIAAAAg");
	this.shape_22.setTransform(83.55,14.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgLBUIAAinIAMAAQAHAAACADQACADAAAKIAACXg");
	this.shape_23.setTransform(74.225,12.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AghBHQgFAMgHAAIgKAAIAAinIANAAQAHAAACADQACADAAALIAAAqQASgSAWAAQAUAAAMANQAPARAAAgQAAAigQARQgOAPgWAAQgXAAgOgOgAgfgJIAABAQALAMASAAQAhAAAAguQAAgtgfAAQgOAAgRAPg");
	this.shape_24.setTransform(64.675,12.875);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgLBUIAAh9IAMAAQAHABACADQACADAAAMIAABqgAgJg7QgEgEAAgGQAAgFAEgEQAEgFAFAAQAGAAAEAFQAEAEAAAFQAAAGgEAEQgEAEgGABQgFgBgEgEg");
	this.shape_25.setTransform(54.375,12.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAgA/Ighg0IggA0IgUAAIAAgHIAmg5Iglg2IAAgHIAXAAIAeAvIAcgvIAUAAIAAAHIghA1IAmA6IAAAHg");
	this.shape_26.setTransform(45.125,14.925);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgmAvQgQgRAAgeQAAgcARgSQAPgRAYAAQA1gBAAA+IAAAHIhTAAQABApAjAAQAVAAAPgLIAIAAIAAARQgUANgbgBQgbABgQgSgAAfgKQgBgkgcAAQgaAAgEAkIA7AAIAAAAg");
	this.shape_27.setTransform(32.45,14.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgLBUIAAinIAMAAQAHAAACADQACADAAAKIAACXg");
	this.shape_28.setTransform(23.125,12.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgzBUIAAinIBnAAIAAAUIhNAAIAAA5IA6AAIAAASIg6AAIAABIg");
	this.shape_29.setTransform(14.025,12.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_course, rect = new cjs.Rectangle(5,0,224.9,56.8), [rect]);


(lib.mc_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_bg, rect = new cjs.Rectangle(0,0,728,90), [rect]);


(lib.mc_applynow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F94B8").s().p("AAbA/IgbhZIAAAAIgaBZIgWAAIgjh2IAAgHIAXAAIAZBaIABAAIAbhaIASAAIAbBaIABAAIAZhaIAUAAIAAAHIgjB2g");
	this.shape.setTransform(128.175,23.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F94B8").s().p("AgqAvQgRgRAAgdQAAgdARgSQARgRAZAAQAaAAARARQARASAAAdQAAAdgRARQgQARgbAAQgZAAgRgRgAgYghQgKAMAAAWQAAAWAKAMQAJALAPAAQAQAAAJgLQAKgMAAgWQAAgWgKgMQgJgMgQAAQgPAAgJAMg");
	this.shape_1.setTransform(111.75,23.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F94B8").s().p("AAcBAIAAhWQAAgUgTAAQgOAAgWAMIAABeIgYAAIAAh9IAPAAQAFAAACADQACAEAAAJQAXgSAYAAQAgAAAAAjIAABcg");
	this.shape_2.setTransform(97.675,23.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F94B8").s().p("AgaBSIAAgHIARgnIgvhvIAAgGIAXAAIAjBXIAihXIAVAAIAAAGIg+Cdg");
	this.shape_3.setTransform(78.325,25.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F94B8").s().p("AgLBUIAAinIAMAAQAHAAACADQACADAAAKIAACXg");
	this.shape_4.setTransform(68.625,21.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F94B8").s().p("Ag3BTIAAijIAPAAQAFAAACADQACADAAAKQASgSAWAAQAUAAAMANQAPARAAAgQAAAggRARQgOAPgWAAQgUAAgOgMIAAAzgAgfgwIAAA+QALAMASAAQAhAAAAgsQAAgtgeAAQgPAAgRAPg");
	this.shape_5.setTransform(58.725,25.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F94B8").s().p("Ag3BTIAAijIAPAAQAFAAACADQACADAAAKQASgSAWAAQAUAAAMANQAPARAAAgQAAAggRARQgOAPgWAAQgUAAgOgMIAAAzgAgfgwIAAA+QALAMASAAQAhAAAAgsQAAgtgeAAQgPAAgRAPg");
	this.shape_6.setTransform(44.475,25.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2F94B8").s().p("AAsBUIgPgvIg9AAIgPAvIgVAAIAAgIIA3ifIAbAAIA3CfIAAAIgAAWASIgXhKIAAAAIgZBKIAwAAg");
	this.shape_7.setTransform(29.075,21.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AqIDbQhaAAhBhAQhAhAAAhbQAAhZBAhBQBBhABaAAIURAAQBaAABBBAQBABAAABaQAABahABBQhBBAhaAAg");
	this.shape_8.setTransform(78.9821,21.925,0.8688,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_applynow, rect = new cjs.Rectangle(3.6,0,150.9,43.9), [rect]);


(lib.clicktag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A52EnIAApNMAztAAAIAAJNg");
	this.shape.setTransform(165.5,29.5);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = null;
p.frameBounds = [rect, rect, rect, new cjs.Rectangle(0,0,331,59)];


// stage content:
(lib._04626_S2_DigiInnovators_DigiAd_320x50 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* Click to Go to Web Page
		Clicking on the specified symbol instance loads the URL in a new browser window.
		
		Instructions:
		1. Replace http://www.adobe.com with the desired URL address.
		   Keep the quotation marks ("").
		*/
		
		this.clicktag.addEventListener("click", fl_ClickToGoToWebPage);
		
		function fl_ClickToGoToWebPage() {
			window.open(window.clicktag);
		}
	}
	this.frame_151 = function() {
		/* Click to Go to Web Page
		Clicking on the specified symbol instance loads the URL in a new browser window.
		
		Instructions:
		1. Replace http://www.adobe.com with the desired URL address.
		   Keep the quotation marks ("").
		*/
		
		this.clicktag.addEventListener("click", fl_ClickToGoToWebPage);
		
		function fl_ClickToGoToWebPage() {
			window.open(window.clicktag);
		}
	}
	this.frame_190 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(151).call(this.frame_151).wait(39).call(this.frame_190).wait(6));

	// clicktag
	this.clicktag = new lib.clicktag();
	this.clicktag.name = "clicktag";
	this.clicktag.parent = this;
	this.clicktag.setTransform(160.05,26.8,1,1,0,0,0,165.5,29.5);
	new cjs.ButtonHelper(this.clicktag, 0, 1, 2, false, new lib.clicktag(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clicktag).wait(196));

	// 3-ApplyNow
	this.mc_applynow = new lib.mc_applynow();
	this.mc_applynow.name = "mc_applynow";
	this.mc_applynow.parent = this;
	this.mc_applynow.setTransform(212.3,25.7,0.3677,0.3677,0,0,0,87,22.3);
	this.mc_applynow.alpha = 0;
	this.mc_applynow._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_applynow).wait(163).to({_off:false},0).to({regX:86.9,regY:22.2,scaleX:0.4766,scaleY:0.4766,y:25.65,alpha:1},10,cjs.Ease.get(1)).wait(23));

	// 3-CourseSpecific
	this.mc_course = new lib.mc_course();
	this.mc_course.name = "mc_course";
	this.mc_course.parent = this;
	this.mc_course.setTransform(104.25,25.8,0.5589,0.5589,0,0,0,175.7,28.4);
	this.mc_course.alpha = 0;
	this.mc_course._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_course).wait(157).to({_off:false},0).to({alpha:1},15,cjs.Ease.get(1)).wait(24));

	// 3-Logo
	this.mc_logo = new lib.mc_logo();
	this.mc_logo.name = "mc_logo";
	this.mc_logo.parent = this;
	this.mc_logo.setTransform(297.6,25.1,0.5589,0.5589,0,0,0,22.4,31.1);
	this.mc_logo.alpha = 0;
	this.mc_logo._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_logo).wait(152).to({_off:false},0).to({alpha:1},10,cjs.Ease.get(1)).wait(34));

	// 2-NowsTime
	this.mc_nowstime = new lib.mc_nowstime();
	this.mc_nowstime.name = "mc_nowstime";
	this.mc_nowstime.parent = this;
	this.mc_nowstime.setTransform(159.75,26.5,0.4291,0.4291,0,0,0,283.7,31.4);
	this.mc_nowstime.alpha = 0;
	this.mc_nowstime._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_nowstime).wait(111).to({_off:false},0).to({scaleX:0.4954,scaleY:0.4954,alpha:1},11,cjs.Ease.get(1)).wait(15).to({alpha:0},9,cjs.Ease.get(1)).to({_off:true},5).wait(45));

	// 2-D
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgCCkIAAgCIg4AAIAAAEIh6gEIACgiIAHgDIAOAAIAFgBIAbABIAAgDIgEAAIAAgwIACAAIAAggIgDAAIAAgiIADAAIAAgqIgDgCIAAgkIAIAAIAAgcIgHAAIAAgGIgFAAIgBgDIABgOIgOACIgBgCIgWADIgJgJIgCghIAaAAIAAACIAWAAIAAgDIAigBIAAgCIAWAAIADADIAuABIAAgBIARAAIAAgBIATAAIAAAFIAtACIAAATIALgXIA+AlIgDAGIAKAHIACgDIAMAHIgFAKIALAHIgCAFIAZALIgEACIAIAWIgQAIIAMAcIgHAEIAPAbIgPAHIADAHIACAAIAFADIgKAMIAGAMIgIAEIgQAwIADAFIgWALIgCAAIgNAGIAEAIIgPAIIgFgEIABAFIgfAJIgBgDIgBAAIAAAHIgkAAIgCgCIgBAHgAhAB0IAHAAIAAANIA3AAIAAgFIACgCIAcgBIACADIAAACIAPgBIgHgPIAdgOIgFgIIAagTIgMgWIAIgFIgRgaIACgCIgHgLIACgDIARgJIgMghIABgDIgHgTIgIADIAKgWIgSgJIACgFIgHgDIABgHIADgMIgKAAIAAAEIgRAAIAAgEIgfABIgBgFIgOAAIgCACIgTAAIgDAOIgIAAIAAAJIABAIIAAATIACAIIAAA7IgEAAIAAAvIgBABIAAAdIADAAIAAATIgGAAg");
	this.shape.setTransform(19.7329,25.4709,0.6621,0.6621);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4).to({_off:false},0).to({_off:true},6).wait(186));

	// 2-I
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AggCkIAAlHIBBAAIAAFHg");
	this.shape_1.setTransform(35.6394,25.3715,0.6621,0.6621);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(7).to({_off:false},0).wait(8).to({_off:true},1).wait(180));

	// 2-G
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAqDVIAAgSIhDAAIAAAEQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAgBAAIgFAAQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAIAAgQQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAIAFAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABIAAAEIBDAAIAAgKIgDgDIAAAAIABgCIACgCIAAgBIgDgDIAAgBIADgDIAAgBQgBAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAIAAgBIADgDIAAgBQgBAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAIAAgBIADgDIAAgBQgBAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAIABgCIACgCIAAgBQgBAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAIABgCIACgCIAAgBIgDgDIhygQQgYgHgLgNIgDgDQgNgRgBgdIgDi7QAAgNAHgPQAHgMALgJQADgDAIgFQALgFAKgCQAPgEARAFIABABIBXAZQAGACAEAFQAEAFAAAHIgCADQgGACgKACQgLACgFgCIgEgDIgBgBIhWgHQgKAAgEADQgGAEgCAGIgBAHIAADCQAAAKAHAJQAHAIAKACIBmAOIAAAAQAAgBAAAAQAAAAAAgBQAAAAABAAQAAgBAAAAIACgCIAAgCQgDgCAAgDIABgDIACgCIAAgCQgDgCAAgDQAAAAAAAAQAAgBAAAAQAAAAABgBQAAAAAAAAIACgDIAAgBIgBgBQgCgCAAgCIABgDIACgDIAAgBIgBAAQgCgDAAgCIAAgBIAAAAIADgEIAAgCQgDgCAAgDIACgEIABgBIAAgBQgDgDAAgCQAAgBAAAAQAAgBAAAAQABgBAAAAQABgBAAAAIAAgBIABgBIAAgBQgDgCAAgDIAAAAIACgEIABgBIgJABQgDABABgDIAAgPQAAgBAAAAQAAAAAAgBQAAAAABAAQAAgBAAAAQAGgBALAAQAMAAAGACQABAAAAAAQAAAAAAABQABAAAAAAQAAABAAAAIAAAQQgBAAAAABQAAAAAAAAQgBABAAAAQgBAAAAAAIgIgBIACAEIAAAAIgBADIgCADIACADIABADIgBADIgCADIACACIABADIAAABIgBACIgCADIACADIABADIgBADIgCADIACADIABADIgBADIgCADIACADIABACIgBADIgCADIACADIABADIgBADIgCADIACADIABADIAAAAIAIAAQAAAAABAAQABABAAAAQAAAAABABQAAAAAAABQAAABAAABQgBAAAAAAQAAABgBAAQgBAAAAAAIgCAAIAAAZIACAAQAAAAABAAQABAAAAAAQAAABABAAQAAABAAABQAAABAAAAQgBABAAAAQAAABgBAAQgBAAAAAAIgIAAIgBACIgCACIACACIABACIgBACIgCACIACACIABACQAAACgDACIADADIAAABQAAABAAAAQAAAAAAABQgBAAAAABQgBAAgBABIADADIAAABIAAAAQAAABAAAAQAAABAAAAQgBABAAAAQgBAAgBABIACACIABACIAAAAIAAAAQAAABAAAAQAAABAAAAQgBABAAAAQgBAAgBABIACACIABACIAAAAIgCADIAAAKIA+AAIAAgEQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAIAGAAQAAAAABAAQAAABABAAQAAAAAAABQAAAAAAABIAAAQQAAAAAAABQAAAAAAABQgBAAAAAAQgBAAAAAAIgGAAQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAIAAgEIg+AAIAAASgAhOjIQgKADgJAGQgJAIgHAKQAAABgBAAQAAABAAAAQAAAAABABQAAAAAAAAIABABIACgBQAHgLAJgGQAGgGALgEIACgBIAAgBIgCgCIgBABg");
	this.shape_2.setTransform(50.2382,28.1377,0.6621,0.6621);
	this.shape_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(12).to({_off:false},0).wait(7).to({_off:true},1).wait(176));

	// 2-I-2
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag4CkIAAgRIAbAAQAGAAAFgFQAEgFABgGIAAkEQgBgGgEgFQgFgFgGAAIgbAAIAAgRIBxAAIAAARIgbAAQgGAAgEAFQgGAFAAAGIAAEEQAAAGAGAFQAEAFAGAAIAbAAIAAARg");
	this.shape_3.setTransform(64.3135,25.568,0.662,0.662);
	this.shape_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(17).to({_off:false},0).wait(12).to({_off:true},1).wait(166));

	// 2-T
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgYCjQgLAAAAgJIAAkqIhLAAIAAAZIAiAAQAEAAADACQADADAAAEQAAAEgDADQgDACgEAAIgtAAQgDAAgEgCQgDgDAAgEIAAgrQAAgEADgDQAEgCADAAIBhAAQADAAAEACQADADAAAEIAAEqIAdAAIAAkqQAAgEAEgDQADgCAEAAIBfAAQAEAAAEACQADADAAAEIAAArQAAAEgDADQgEACgEAAIgsAAQgEAAgDgCQgDgDAAgEQAAgEADgDQADgCAEAAIAiAAIAAgZIhLAAIAAEqQAAAJgKAAg");
	this.shape_4.setTransform(78.9228,25.4874,0.6621,0.6621);
	this.shape_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(22).to({_off:false},0).wait(5).to({_off:true},1).wait(168));

	// 2-A
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AglAOIAKgbIBBAAIgJAbg");
	this.shape_5.setTransform(87.7302,35.547,0.662,0.662);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AglAOIAKgbIBBAAIgJAbg");
	this.shape_6.setTransform(88.5577,33.0647,0.662,0.662);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ah4AOIAJgbIDfAAIAJAbg");
	this.shape_7.setTransform(94.9125,30.5824,0.662,0.662);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AglAOIAKgbIBBAAIgKAbg");
	this.shape_8.setTransform(91.04,25.6177,0.662,0.662);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhsAOIAKgbIDGAAIAJAbg");
	this.shape_9.setTransform(94.9125,28.1,0.662,0.662);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgbAOIgKgbIBCAAIAJAbg");
	this.shape_10.setTransform(102.0947,35.547,0.662,0.662);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AglAOIAKgbIBBAAIgKAbg");
	this.shape_11.setTransform(91.8675,23.1354,0.662,0.662);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgbAOIgKgbIBCAAIAJAbg");
	this.shape_12.setTransform(101.2672,33.0647,0.662,0.662);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgbAOIgKgbIBCAAIAJAbg");
	this.shape_13.setTransform(98.7849,25.6177,0.662,0.662);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAFAOIgFgOIgEAOIhCAAIAJgbIB7AAIAJAbg");
	this.shape_14.setTransform(94.9125,20.6365,0.662,0.662);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgbAOIgKgbIBCAAIAJAbg");
	this.shape_15.setTransform(97.9575,23.1354,0.662,0.662);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ag6AOIAJgbIBjAAIAJAbg");
	this.shape_16.setTransform(94.9125,18.1541,0.662,0.662);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgtAOIAJgbIBJAAIAJAbg");
	this.shape_17.setTransform(94.9125,15.6718,0.662,0.662);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]},26).to({state:[]},9).wait(161));

	// 2-L
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AhZChIAagQIgIkjIgdgKIACgNIBmgBIADARIgbAJIgBEcIBVgTIgGgfIArgGIgCBJIi7AOg");
	this.shape_18.setTransform(110.7853,25.9509,0.6621,0.6621);
	this.shape_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(32).to({_off:false},0).wait(4).to({_off:true},1).wait(159));

	// 2-I-2_1
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ag3CjIAAgQIAaAAQAGAAAFgFQAEgGAAgFIAAkEQAAgFgEgGQgFgFgGAAIgaAAIAAgRIBvAAIAAARIgaAAQgGAAgFAFQgFAGAAAFIAAEEQAAAFAFAGQAFAFAGAAIAaAAIAAAQg");
	this.shape_19.setTransform(137.6586,25.6329,0.662,0.662);
	this.shape_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(38).to({_off:false},0).wait(12).to({_off:true},1).wait(145));

	// 2-N
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("ABBCjIAAkEIBCAAIAAEEgAiCCjIAAkEIBCAAIAAEEgAhAhhIAAhCICBAAIAABCgAhAhhg");
	this.shape_20.setTransform(154.3614,25.243,0.6621,0.6621);
	this.shape_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(42).to({_off:false},0).wait(7).to({_off:true},1).wait(146));

	// 2-N-2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("ABGCkIAAlHIAkAAIAAFHgAhpCkIAAlHIAkAAIAAFHgAgzhGIAAhYIBnDNIAABWg");
	this.shape_21.setTransform(174.29,25.2596,0.6621,0.6621);
	this.shape_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_21).wait(47).to({_off:false},0).wait(13).to({_off:true},1).wait(135));

	// 2-O
	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhOCjQgaAAgKgcIDlAAQgKAcgaAAgAh1B+IgBgcIDtAAIAAATIgBAJgAA7BZIAAgcIA8AAIAAAcgAh2BZIAAgcIA8AAIAAAcgAA7AzIAAgcIA8AAIAAAcgAh2AzIAAgcIA8AAIAAAcgAA7AOIAAgbIA8AAIAAAbgAh2AOIAAgbIA8AAIAAAbgAA7gWIAAgcIA8AAIAAAcgAh2gWIAAgcIA8AAIAAAcgAA7g8IAAgcIA8AAIAAAcgAh2g8IAAgcIA8AAIAAAcgAh2hhIABgcIDrAAIABAJIAAATgAhyiGQAKgcAaAAICdAAQAaAAAKAcg");
	this.shape_22.setTransform(193.8875,25.2596,0.6621,0.6621);
	this.shape_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_22).wait(52).to({_off:false},0).wait(4).to({_off:true},1).wait(139));

	// 2-V
	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgoCpIgCAFIgXggQgkANgMgEIAygQIAKAMIACgDQACgEAEgDIADggIAAgMIgZgGIgNAXIgGgCIgCABIgDgBIgHADIgMgXQgMAIgKADIgaAFIAqgUIAPgBIADgCIABgzIAFAuIAEACIAAgfIACgCIAAh2QAAAAAAgBQAAAAAAAAQABAAAAAAQAAgBAAAAQABAAAAABQAAAAABAAQAAAAAAAAQAAABAAAAIAAB0IAGgDIgEAJIABAjIARAAIAVAFIAAgFIgLgDIALABIAAhSQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAABSIAmACIADgMIgBgWIACgFIABABIAAgnQgJAAgDgBIAMgDIAAhMQAAAAAAgBQAAAAAAAAQABAAAAAAQAAgBAAAAQABAAAAABQAAAAABAAQAAAAAAAAQAAABAAAAIAABMIAKgDIANABIAFgqIAEAnIAAAAIAAgwIgBAAIABgGIAAgfIgEADIAEgFIAAgcQgLgCgKgDIAVgBIAAgSQAAgBABAAQAAAAAAgBQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAABAAAAQABAAAAABIAAASIAXgBIAAgkQAAAAABgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAABAAAAIAAAjIAEAAIADgEIgCgcIAFgHIADAAIABAcIABAAIAAgYQAAgBAAAAQAAAAABgBQAAAAAAAAQABAAAAAAIABAAIAAgLIAEAJQAEANgBAUIACACIADgCIA9gFIglAMIgNgCIgQAcIgLgEIgBgCIgCACIgKgOIgBAAIAAA1IAMABIAbguIABAEIgSAvIAJAAIgCASIgIgDIgGAKIgPgGIgQACIgBgCIgDAAIgEgLIgCgBIAAAxIAEAAIAHgYIABgEIADADIAOACIgLABIgFAaIAMAAIARAJIABAAIAGACIgdgEIgKAUIgKgEIgDADIgJABIgBgCIgCACIgIgYIgNABIAAApIABABIABAGIAIgVIADAFIADAoIAGACIAZgCIAcAAIgXAEIgRACIgFAAIgMAcIgDgBIgCABIgHgEIgKABIgJgTQgNgEgJAAIgLgCIAAAFIAOADQgEABgKgBIAAABIACAUIADABIAAAWIACACQAEAEABADIAKgIIA2gCQgKAFgKACQgRAEgQgBIgKALIgJARgAAwg9IgCgfIgEADIAAAbIAGABgAAzhfIAJAgIAFAAIAAg1IgXgBIAAAXIACgCIAEgBg");
	this.shape_23.setTransform(216.4811,24.8385,0.662,0.662);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AArBfIgOADIgFgWIgLADIAEgKIAFgBIAIAAIACgUIgNAAIAPgHIAEACIAEAZIAEgIIAFABIAAglIgOgEIgGAMIgOAAIAIgBIgIABIAAAAIgIABIgHgNIAFgGIgrAYIAfgeIAOgCIAGgyIADAyIAEABIAAg8IgGAAIgOAWIgFgFIAAAFIgHgHIgGACIgMgQIgvABIAlgKIAQADIADgDIgBgeIgEgCIADgBIAIAAIACABIACAbIAEAAIAAgfQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAAgIACAAIAJgkIADAEIgFAiIABAAIAPADIAAglQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAAmIAbAFIAAgYQAAgBAAAAQAAAAAAAAQABgBAAAAQAAAAAAAAQABAAAAAAQAAAAABABQAAAAAAAAQAAAAAAABIAAAZIAMACIgMAAIAABAIAWASIgWgGIAAAlIACAAIACADIAQgfIgMAoIACAAIAGAAIAGAEIgFAHIgFAAIgIARgAAggeIAAAmIAFAIIAMgHIACACIAAg+IgbgBIAAAlIACgSIANgBgAARAgg");
	this.shape_24.setTransform(205.4926,20.6517,0.662,0.662);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_24},{t:this.shape_23}]},57).to({state:[{t:this.shape_24},{t:this.shape_23}]},9).to({state:[]},1).wait(129));

	// 2-A-2
	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAAAAIAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIAAAAIgBABg");
	this.shape_25.setTransform(226.2449,33.2785,0.662,0.662);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgBABIAAAAIAAgBQAAAAABAAIABAAIABAAIgBABIgBAAg");
	this.shape_26.setTransform(226.3525,32.9089,0.662,0.662);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAAABIgBAAIABgBIAAABIACAAg");
	this.shape_27.setTransform(227.0558,30.9782,0.662,0.662);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAAABIAAgBIAAAAIABAAIAAAAIgBABg");
	this.shape_28.setTransform(237.3741,33.2868,0.662,0.662);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAAAAIACABIgCAAQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAABAAg");
	this.shape_29.setTransform(235.3435,27.7181,0.662,0.662);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AABABIgBgBIgBgBIACAAQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIAAACg");
	this.shape_30.setTransform(235.6329,27.9663,0.662,0.662);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAAAAIAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIABAAIAAABg");
	this.shape_31.setTransform(230.68,28.7937,0.662,0.662);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAAgBIAAAAIABABIAAAAIgBACg");
	this.shape_32.setTransform(234.4449,29.7867,0.662,0.662);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAAAAIABAAQAAAAABAAIgBABIgBAAg");
	this.shape_33.setTransform(231.8385,28.9923,0.662,0.662);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AAAABIAAgCIAAABQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAAAIgBABg");
	this.shape_34.setTransform(233.7878,29.1909,0.662,0.662);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AADABIgBAAIgCAAIgJgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAIABAAQAAgBABAAQAAAAAAAAQABAAAAAAQAAAAABABIADgBQAAAAAAAAQAAAAABAAQAAABAAAAQAAAAABAAIAJAAIADAAIAAABIgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAIgBAAIgBAAIgBgBg");
	this.shape_35.setTransform(232.9141,28.4669,0.662,0.662);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAAAAIABAAIAAAAIgBABIAAgBg");
	this.shape_36.setTransform(227.693,24.5407,0.662,0.662);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAAAAIABAAIgBAAg");
	this.shape_37.setTransform(228.2308,22.6541,0.662,0.662);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAAAAIABAAIAAABIgBgBg");
	this.shape_38.setTransform(227.8502,22.952,0.662,0.662);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgBACIAAgBIgBgDIABAAIAAAAIAAACIABACIADABg");
	this.shape_39.setTransform(228.0653,24.7558,0.662,0.662);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AAAACIgCgCQABAAAAAAQAAAAAAAAQAAAAAAAAQAAgBgBAAIABgBIABAAIAAACQAAAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABgBIAAABIgBAAIgBACIAAABg");
	this.shape_40.setTransform(227.3785,23.5146,0.662,0.662);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AABACIgBgBIAAABIgBgBIgBgBIABgBIABgBIAAABIABAAIABABIAAABIABgBIAAACQAAAAAAAAQAAAAgBABQAAAAAAAAQAAAAgBAAg");
	this.shape_41.setTransform(227.8502,21.5619,0.662,0.662);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgCACIACgCIgBAAIAAgBIAEAAIgBABIgCABIAAABIgBAAIgBAAg");
	this.shape_42.setTransform(234.8338,28.0077,0.662,0.662);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_43.setTransform(228.3797,26.9237,0.662,0.662);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_44.setTransform(234.8669,19.6256,0.662,0.662);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_45.setTransform(237.3162,23.3657,0.662,0.662);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIgBABg");
	this.shape_46.setTransform(224.9376,28.0904,0.662,0.662);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AAAABIAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAIgBABg");
	this.shape_47.setTransform(236.0915,30.068,0.662,0.662);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIAAABIgBgBg");
	this.shape_48.setTransform(235.9012,23.134,0.662,0.662);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgBAAIABAAIAAAAIABAAIABAAIgCABIgBgBg");
	this.shape_49.setTransform(226.609,18.4507,0.662,0.662);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AAAABIAAgBIABAAIAAABg");
	this.shape_50.setTransform(232.3846,15.3229,0.662,0.662);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AAAABIAAgBIAAAAIABAAQAAAAgBAAIAAAAIAAABg");
	this.shape_51.setTransform(240.9293,34.5693,0.662,0.662);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIAAAAIgBABg");
	this.shape_52.setTransform(229.3892,15.025,0.662,0.662);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAQAAABgBAAIAAAAIAAgBg");
	this.shape_53.setTransform(232.4563,14.939,0.662,0.662);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_54.setTransform(228.6776,17.375,0.662,0.662);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAAAAQAAAAABAAQAAAAAAAAQAAABAAAAQgBAAAAAAg");
	this.shape_55.setTransform(234.2712,19.2616,0.662,0.662);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAAAAIABAAIgBABg");
	this.shape_56.setTransform(227.8171,27.9828,0.662,0.662);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_57.setTransform(230.7297,21.1647,0.662,0.662);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AAAAAIABAAIABAAQgBAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAABQgBgBAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAg");
	this.shape_58.setTransform(236.7314,25.0206,0.662,0.662);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AAAABQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIABAAIgBABg");
	this.shape_59.setTransform(225.583,35.8601,0.662,0.662);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AAAABIAAgDIAAAAIAAABIAAADIAAABg");
	this.shape_60.setTransform(235.2227,31.0775,0.662,0.662);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AAAAAIABAAIAAAAIgBABIAAgBg");
	this.shape_61.setTransform(229.9353,15.0581,0.662,0.662);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AAAABIAAgBIAAAAIAAAAIAAABg");
	this.shape_62.setTransform(226.2863,35.4547,0.662,0.662);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_63.setTransform(225.8643,34.983,0.662,0.662);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AAAABIAAgBIAAAAIABAAIAAAAQAAAAAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAIAAAAg");
	this.shape_64.setTransform(225.7154,21.499,0.662,0.662);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgBABIABgBIABAAIABAAIAAAAIAAAAIgCABIgBAAg");
	this.shape_65.setTransform(228.3466,27.6519,0.662,0.662);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AAAAAQAAAAAAAAQAAgBAAAAQAAAAAAABQAAAAABAAIAAAAIgBACQAAgBAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAg");
	this.shape_66.setTransform(225.9415,34.7348,0.662,0.662);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAAAAIABABQgBAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAg");
	this.shape_67.setTransform(226.4506,21.6446,0.662,0.662);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AAAAAIAAAAQABAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAg");
	this.shape_68.setTransform(230.0313,17.5901,0.662,0.662);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAg");
	this.shape_69.setTransform(232.728,23.796,0.662,0.662);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAIAAABIgBAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAg");
	this.shape_70.setTransform(234.478,14.9754,0.662,0.662);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AAAABQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAAAIAAAAIABAAIgBABg");
	this.shape_71.setTransform(232.5699,16.018,0.662,0.662);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AAAABIgBgBIABAAIAAAAIAAAAIACABIgCAAg");
	this.shape_72.setTransform(234.9993,32.8317,0.662,0.662);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AAAABIgBgBIABAAIACAAIgCABIAAAAIAAAAg");
	this.shape_73.setTransform(235.5123,18.1776,0.662,0.662);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgBABIABgBIABAAIgBAAIAAAAIAAABIAAAAIAAAAIgBAAg");
	this.shape_74.setTransform(235.4461,17.8715,0.662,0.662);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AAAAAIAAAAQAAgBAAAAQABAAAAAAQAAAAAAAAQAAAAAAABIAAAAIgBACg");
	this.shape_75.setTransform(226.1539,35.7774,0.662,0.662);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgBABIABgBIABAAIABAAQAAAAAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAg");
	this.shape_76.setTransform(232.7983,14.9423,0.662,0.662);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AAAABIAAgBIAAAAIAAAAIACABIgBAAIgBAAIAAAAg");
	this.shape_77.setTransform(223.7957,27.9795,0.662,0.662);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AACABQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBAAIAAgBQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIACABg");
	this.shape_78.setTransform(227.8502,20.1174,0.662,0.662);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AAAABQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAIAAAAIABAAIAAAAIAAABg");
	this.shape_79.setTransform(220.7466,35.5953,0.662,0.662);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AAAACIAAgBIAAgBIAAgCQAAAAABAAQAAABAAAAQAAAAAAAAQAAABAAAAIgBADg");
	this.shape_80.setTransform(229.1286,26.9899,0.662,0.662);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AAAABIgBAAIABgCQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAABAAIgBABIgBABIAAgBg");
	this.shape_81.setTransform(220.3204,36.0311,0.662,0.662);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AAAABIAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIABgBIABACIgBABIgBgBg");
	this.shape_82.setTransform(225.8147,21.0654,0.662,0.662);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAAAAIAAgBQAAAAAAABQABAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIgBABIAAgCg");
	this.shape_83.setTransform(232.5666,22.5072,0.662,0.662);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AAAACIAAgCIAAgBIAAABIAAAAIABAAIAAgBIAAABIAAACg");
	this.shape_84.setTransform(241.6851,36.0091,0.662,0.662);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AAAABIAAAAIAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAIABAAIAAABIgBACg");
	this.shape_85.setTransform(229.1741,22.439,0.662,0.662);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AAAABIgBAAIgCgBQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAIACAAIgDAAIgBAAIAAABIAAAAg");
	this.shape_86.setTransform(234.1222,14.9291,0.662,0.662);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgBABIAAAAIABgBIABAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIAAAAIgDABg");
	this.shape_87.setTransform(229.7285,14.843,0.662,0.662);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AABABQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAAAIgCAAIADAAIABAAIAAAAIAAABIAAAAIgBAAg");
	this.shape_88.setTransform(225.8229,35.9511,0.662,0.662);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AACACQAAAAgBgBQAAAAgBAAQAAAAAAAAQgBgBgBAAIACgBQAAAAAAAAQAAAAAAAAQAAAAABABQAAAAAAAAIACACg");
	this.shape_89.setTransform(229.4058,17.8273,0.662,0.662);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AAAACIAAgFIAAgBIAAABIAAACQABABAAAAQAAAAAAAAQAAAAAAABQAAAAgBABIAAACg");
	this.shape_90.setTransform(232.7652,25.1364,0.662,0.662);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AAAABIgBgBIAAAAIABAAQAAgBAAAAQAAAAAAAAQAAAAAAAAQABAAAAABIABACg");
	this.shape_91.setTransform(241.2383,34.3294,0.662,0.662);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AABAEQAAAAAAAAQgBgBAAAAQAAAAAAAAQAAAAAAAAIAAgBIAAAAIAAgBIAAgBIgBgEIACAHIAAACg");
	this.shape_92.setTransform(241.7016,35.5126,0.662,0.662);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgBACIAAgCIABAAIAAAAIABgBIACABIgBAAIgCACg");
	this.shape_93.setTransform(229.9105,19.1954,0.662,0.662);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AABADQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIAAgCQgBgBAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIAAAAIAAACIABAAIABADIgBAAg");
	this.shape_94.setTransform(235.1813,33.626,0.662,0.662);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AAAADIgBgCIABgBIAAgBIAAgBIAAAAIABACIAAAAIABACIgCABg");
	this.shape_95.setTransform(239.8647,30.581,0.662,0.662);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AAAABIAAgBIgBgBIAAAAIABgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAABABQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAABAAAAIAAABIAAABIAAgCg");
	this.shape_96.setTransform(230.1416,19.7531,0.662,0.662);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgDABIgBgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIABAAQAAAAABABQAAAAAAAAQABAAAAAAQAAAAABgBIABgBQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAABgBIABAAIAAABIAAAAIgBAAIgCAAQAAABAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAg");
	this.shape_97.setTransform(231.7259,15.3395,0.662,0.662);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgBACIgBAAIgBgCIAAgBIABABIABAAIACgBQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAABQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAIgBABIAAABg");
	this.shape_98.setTransform(229.6871,20.0592,0.662,0.662);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AAAAEIgBAAIAAgCQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAIAAgBIABAAIgBgBIAAgCIAAgCIAAABIACAFIgBAAIAAACIAAABIgBgBg");
	this.shape_99.setTransform(241.4203,34.9216,0.662,0.662);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgFABIAAgBIACAAIAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIAFgBIABABIABAAIgCABIAAAAIgCgBQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAIgBAAIgCACIgCgBg");
	this.shape_100.setTransform(232.9141,15.2567,0.662,0.662);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgBABIAAABIgBgBIAAgBIAAAAIAAgBIABAAIABABIAAAAIAAAAIAAgBIABgBIACABIAAABIgCAAIgBABIAAACg");
	this.shape_101.setTransform(237.4734,23.989,0.662,0.662);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgBAFQAAAAAAAAQABAAAAgBQAAAAAAAAQAAgBAAgBIABgEIABgCIAAAEIAAACQAAABAAAAQAAAAAAAAQAAAAAAAAQgBABAAAAIgBABIgBAAg");
	this.shape_102.setTransform(226.4435,35.8932,0.662,0.662);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AAAADQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAIABgBIgBAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIAAAAIgBgDQAAAAABAAQAAAAAAABQAAAAAAAAQABABAAAAIABABIAAAAIAAADIgBABIAAAAIgBgBg");
	this.shape_103.setTransform(224.4411,26.7141,0.662,0.662);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgCACIAAgCIACAAIAAAAIAAgCIABABIACABIAAABQAAAAgBAAQAAAAAAABQgBAAAAgBQAAAAgBAAQAAABAAAAQAAAAAAAAQAAAAAAABQAAAAgBAAIAAAAIgBgBg");
	this.shape_104.setTransform(237.1176,23.7044,0.662,0.662);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgBACIAAgBIAAgBIAAgBQAAAAABgBQAAAAAAAAQAAAAAAAAQAAABAAAAIABABIACAAIgCACIgBAAIgBABIAAgBg");
	this.shape_105.setTransform(229.7864,20.511,0.662,0.662);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AABADQAAgBAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAIgCgBIAAAAIAAAAIACgCIgBAAIAAgBIABAAIABABIACABIAAACQAAAAAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAIgBAAg");
	this.shape_106.setTransform(230.3408,19.1788,0.662,0.662);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgFADIAAgBIABAAQABAAAAAAQABAAAAgBQABAAAAAAQAAAAAAgBIABAAIABAAIAAgBIAAgBIAAAAIABABIAAABIAAAAIABAAIACAAIABAAIgEABIAAABIgBABQAAgBgBAAQAAgBAAAAQAAAAgBABQAAAAgBAAIgCABg");
	this.shape_107.setTransform(227.8502,19.0299,0.662,0.662);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AAAAFIgBgCIgBAAIgCgDIABAAIABAAIABAAIgBABIAAACQABAAAAAAQAAAAABgBQAAAAAAAAQAAAAAAAAIAAgBIABAAIAAgBIgBAAIgBAAQAAAAABAAQAAgBAAAAQAAgBAAgBQAAAAAAgBIAAADIABAAQABAAAAAAQABAAAAAAQAAAAAAAAQAAgBABAAIABgBIAAABIgBABQgBAAAAABQAAAAgBAAQAAAAAAAAQAAAAAAABQAAABABgBIgBACIgBAAQAAAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAIAAABg");
	this.shape_108.setTransform(229.4885,21.8763,0.662,0.662);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AAAADQAAAAgBgBQAAAAAAgBQAAAAAAAAQAAgBAAAAIAAgCIABgBIAAABIACADIgBACIgBABIAAgBg");
	this.shape_109.setTransform(236.2107,33.6481,0.662,0.662);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AAAADIgBgCIABgDIAAAAQAAAAAAAAQABAAAAABQABAAAAAAQAAABAAAAIAAAAQAAABAAABQAAAAAAAAQAAABgBAAQAAAAgBAAIAAAAg");
	this.shape_110.setTransform(225.4731,21.3706,0.662,0.662);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgDABIACgBIACgBQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAIAAABIAAACIgBAAIgCAAIgCAAg");
	this.shape_111.setTransform(225.0534,26.692,0.662,0.662);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AAAADIAAgBIgCgBIABgBIAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIABAAIACACIABAAQAAABAAAAQAAAAgBABQAAAAAAAAQgBABAAAAg");
	this.shape_112.setTransform(225.2685,23.5643,0.662,0.662);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgBABIAAgBQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIAAgCIgBABIAAAAIAAgBIABgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIAAADIgBAAIABACIgCgBQABABAAAAQAAABAAAAQAAAAAAAAQAAABAAAAIgCgDg");
	this.shape_113.setTransform(226.1456,34.9996,0.662,0.662);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AAAADQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAgBAAAAIgBgCIABAAQAAAAAAAAIABgCIABAAIABACQABAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAg");
	this.shape_114.setTransform(221.1181,34.6272,0.662,0.662);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AAAACIgBgBQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIACgCIABAAIABABIAEgBIAAABIABABIgBAAIAAgBIgCAAIgCABIACAAQAAAAABAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgBACIgBABIAAgBg");
	this.shape_115.setTransform(233.5154,15.0548,0.662,0.662);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AAAAHQgCgGAAgDIABgEIABAAIAAAIQACgCABgDQAAABAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAIgDADIAAACIABADIgBAAg");
	this.shape_116.setTransform(236.6022,33.8246,0.662,0.662);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AAAAGIgBgCIAAABIAAABIAAgDIgBgCIAAgBIAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIAAgBIABgEIAAAAIAAAFIAAABIAAAAQABgBAAAAQABAAAAAAQAAgBAAAAQABgBAAAAIABAAIAAABIgBABIgDAGIAAAAg");
	this.shape_117.setTransform(236.828,30.6969,0.662,0.662);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgBADIgBgCIAAgCQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAIABAAIABACIgCADg");
	this.shape_118.setTransform(225.1113,36.0091,0.662,0.662);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AgCACIABgBIABgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQgBAAAAgBIAAgBIABABIAAACIABABQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAIABAFIgBAAIgBAAQgBAAAAAAQAAAAgBgBQAAAAgBgBQAAAAAAgBg");
	this.shape_119.setTransform(235.5951,33.5989,0.662,0.662);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AgDAEIAAgBQAAgBAAAAQAAAAAAgBQAAAAAAAAQABAAAAAAIgBAAIgBAAIgBgBQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAAAgBIgBgCIAAAAIABgBIACABIABABIABAAIAEABIACACIgBAAIgDgCIgCAAQAAAAAAAAQAAABAAAAQAAAAAAgBQAAAAgBAAIgBAAQAAAAABABQAAAAAAABQABAAAAAAQAAAAAAABIAAAAIgBABIABABIAAAAIAAAAIAAABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgCABg");
	this.shape_120.setTransform(230.1505,15.8359,0.662,0.662);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AAAADIAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAAAABAAQAAAAAAgBIACgCQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQABABAAAAQAAABABAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAABIgBAAIgBgBg");
	this.shape_121.setTransform(224.5294,35.7664,0.662,0.662);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AAGAFIgBgBIgDgEQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgEADQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgBIgBAAIAAABIABAAIAAABIgBAAIAAgBIAAgDIAAAAIAAgBIABAAIABABIABAAIABAAIgBgBIAAgBIgBgCQABAAAAAAQAAAAAAAAQABAAAAAAQAAABAAAAIABABIABABIAAgBIABAAIAAgBIABABIABABIABAAIABACQAAAAAAAAQAAABAAAAQABAAAAAAQAAAAAAAAIABACIAAABIgBAAg");
	this.shape_122.setTransform(229.7037,18.708,0.662,0.662);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AAAAIQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBgBAAAAIAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQgBAAAAAAIgBgBQAAAAgBABQAAAAAAAAQgBAAAAAAQAAABAAAAIgBgDIAAAAIABgCIAAAAQABAAAAgBQgBAAAAAAQAAgBAAAAQgBAAAAAAIAAgBIABgBQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIABgCIgBAFIAAACIABABIABgBIABAAIABgBIAAAAQABgBAAABIABAAIABgDIAAABIgBAGIAAACIABAAIABgCIAAgBIACgBQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAAAIgBACIgDACIgCACg");
	this.shape_123.setTransform(235.6158,30.4652,0.662,0.662);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AgFAGIgCgBIADABIAAgBIABABQAAAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABAAIAAAAIABgBIgDgFIAAgCQAAgBAAAAQAAgBAAAAQAAAAAAAAQAAAAABABIABgBIABgBIACgCIAFAIIAAACIAAACIgFABIgCABIgDABQAAgBAAAAQAAAAAAgBQgBAAAAAAQgBAAAAAAg");
	this.shape_124.setTransform(237.603,24.8055,0.662,0.662);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AgCAJIAAgBIABgBIgBgBIgCABIgCgBIABgCIACgFIAAgCQAAgBAAgBQAAAAAAgBQABAAAAgBQABAAAAAAIABgBIACABIAAABIABAAQAAAAAAAAQAAAAABAAQAAAAAAABQAAAAAAAAIAAACIgBACIgBABIAAABQAAAAAAABQgBAAAAAAQAAAAAAABQgBAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAIAAAAIAAABIgBABIABABIAEAAIgBAAQgBAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAABIgCABgAgCAEIAAABIABAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBAAIgBABgAgBAAQAAABAAAAQAAAAAAABQABAAAAAAQAAAAAAAAIAAABIAAgCIAAgBIAAAAg");
	this.shape_125.setTransform(225.3844,22.1742,0.662,0.662);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AADANIgBgEIgFgQIgBgEIgCADIAAAAIAAgDIACgDIACgBIACACQAAABAAAAQAAAAAAABQABAAAAAAQAAAAABAAQADgBgBADIAAABIgCABQAAAAgBAAQAAAAAAAAQAAAAAAABQAAAAAAAAIACAGQAAABAAAAQABABAAAAQAAAAAAAAQAAAAABAAIgBABIABABIAAABIABADIAAABIABAEIAAABIAAABIgCABQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBg");
	this.shape_126.setTransform(231.4854,21.2789,0.662,0.662);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("ABiCiIgGABIgUgBIgCgBIACAAIABgCIAAAAIgBAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgBQAAgBABAAQAAAAgBAAQAAgBAAAAQAAAAgBAAIAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAgBgBIAAgCIgBgBQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAgDIgBgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIABADIAAAEIABABIABABIgBACIACAGIgJgfIABABIACADIAAACQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIAAABQAAABAAAAQAAAAABAAQAAABAAAAQAAAAABAAIABAAIAAgBIgCgHIgBgBIgBgBIABgBIABAAIAEAKIABABIABAAIACABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAIgBACIABACIACAAQAAAAABAAQAAAAAAABQAAAAAAAAQgBAAAAAAIABACIACACIAAAAIAAABIABABQAAABAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIABAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIgBgBIAAAAIgBAAIAAgCIABAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIAAgCIAAgBQAAgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIADACIABACIAAABIABAAIABgDQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAIgBAAIAAAAIAAABIAAAAIgBAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAIAAABIgBAAIAAAAIAAgBIgBgBIAAgBIAAAAIABAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQgBAAgBAAIACgBIAAgBIgBAAIgBABIgBAAQAAAAgBgBQAAAAgBAAQAAAAAAABQgBAAAAAAQgBAAAAABQAAAAgBAAQAAAAAAgBQgBAAAAAAIAAgBQADgFAAgGQABgEgEgDQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAgBAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIgEgFIAAAAIAAgBIAAgBIgDgDIgDgCIABABIgDgDIAAgCIgBAAIgBgBIABgBIABABQAAAAAAAAQAAABAAAAQAAAAABAAQAAABAAAAIAFAEQAAABABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIACABIACABIAAAAQAAAAAAABQABAAAAAAQAAAAAAAAQABAAAAAAIgBABIgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIAAAAIgBgBIAAAAIAAABIACADIADADIACACIABAAIAAABIABABIACAEIABAEIABADIABAAQABADADACIADABIABAAIABAAQABAAAAAAQAAABAAAAQABAAAAAAQAAAAABAAIgBgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAABAAQAAgBAAAAQABAAAAAAIABAAIABAAIgBgBIgBgCIAAgBIgBgBIADADIAAgFIgDgEIgBACIgDgCIAAgBIABAAIAAABIACAAIABgBIAAgBIAAgBQAAgBAAAAQAAAAgBAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgBIABgBIgFgEQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAABIgBABIABgCIAAgBQAAgBAAAAQgBAAAAAAQAAgBgBAAQAAAAAAAAIgCgCIgBACIgCAFIgBAAIAAAAIAAgBIAAAAIABgCIAAgBIACgDIgBgCQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgBIgDgEIgDgDIgDgBIgBAAIgCgCIADABIABgBIgCgBIgBgBIAAgCIAEABIABgBQAAAAAAAAQABAAAAAAQAAAAAAAAQAAgBgBAAIABgBIgDACIADgEQAAAAAAABQAAAAAAAAQAAAAAAAAQAAABABAAIAAAAIgBABQABAAAAABQAAAAAAAAQAAAAAAAAQABgBAAAAIABgBIAAgEIAAACIAAACQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAgBABAAQAAgBAAAAIABgBQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAABAAIAAgEIgBABIAAgBIABgBIgBgCIgBgBIADAAIABgEQABAAgBABIAAADIAAABIABADQABAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIABADIgBgBIgBgBIgBAAIAAABIgBAAIgCADIACAAIAAgCIABABIAAABQABAAAAABQABAAAAAAQAAAAABAAQAAgBAAAAIABgCIAAgBIABAAIAAACIAAABIADAAIADgBQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAAAgBIADgIIABgBIAAgBIgBAAIgBAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAgBQgDgCgBgFIAAgBIgCABIgBABIACgDIAAgCQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIgCABIAAgBIgDgBIAAABIAAACIABACQAAABgBAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIgBAAIgBAAIAAgBIABgBIgBABIgBABIAAgBIgBAAQAAAAAAAAQAAAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQgBAAAAAAQAAgBAAAAIABgCIgCAAIABgBIABgBIABAAIgBgBIgDAAQAAgBAAABIAAACIAAABQABAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAIgBAAIgBgCIABgCIAAAAIgBgBIgDAAIgBABQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgBIgBgBIABgBIAGAAIAHADIACgBIAAgEIgCgBIgFgCQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgBABQAAAAAAABQAAAAgBAAQAAAAAAgBQAAAAAAAAIAAgBIgBABQAAABAAAAQAAAAAAAAQAAABAAAAQAAgBgBAAIgBABQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAgBAAAAIgBAAIgEAAIAAAAIgDgCIgBgBIgFgEQAAgBAAAAQgBAAAAAAQAAgBgBAAQAAABAAAAIgCAAIACABIABACQAAABAAAAQAAABABAAQAAABAAAAQAAAAABABIAEADIACABIABgBIABAAIAAABIAAABIAFADIACACQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBABIgDACIAAABIgDACIAAABIgBADIAAAEIgBACIAAAJIgBgCIAAgFQAAgBAAgBQAAAAAAAAQgBgBAAAAQgBAAgBABIgBAAIgBgBQgBAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQgCADABADQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgEIABAAIAAABIgDAFIgBAAIgBABIAAgCIAAgEIAAgCIAAgCIgBgBIAAgBIgBAAQAAgBgBAAQAAAAAAgBQgBAAAAAAQgBAAAAABIgBABIAAABQAAAAgBABQAAAAAAAAQAAABAAAAQAAABAAABIAAACIAAABIABgBIACgDIgBADIABACIABABQAAABABAAQAAAAAAABQAAAAAAAAQgBABAAAAIgDABIADAAIAEABQABAAAAAAQAAAAAAAAQABAAAAABQAAAAAAAAIAAACIgBgCQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAIgGAAIgKAAIgCAAIgNAAIABgBIgLAAIACAAIgEAAIgDABIgDgBQACgBAEABIgBgBIgEAAIgBAAIABgBIAYAAIgYgBIADgBIADAAIgEAAIgBgBIABAAIADAAIADgDIAAAAIgCgCIgBgBIgCgCIgBgCIgBACIACAAIAAACQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAIAAgCIgBAEIABACIgBADIAAAAIAAACIgBACIAAABIgJAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgCIAAgGIAAgBIgBAAQAAABgBAAQAAAAAAAAQAAABgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAABQABABAAABQAAAAAAAAQAAABgBAAQAAAAgBAAIgBACIgBAAIgcAAIgCgCIgEgEIABgCIAAgBIgDAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAIgBgBQAAAAABAAQAAAAAAAAQAAgBAAAAQgBAAAAAAIgCABQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAgBAAAAIAAAAIgBgBIAAABIgBACIAAgCIgBABIgFAMIAAAAIAAABIgDAIIgBADQAAAAAAAAQAAAAgBABQAAAAAAAAQAAABAAAAIABACIACAAIACgBIAAgBIAAgDIABAAIABABIgBABIABAAIABgBQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBABAAAAIABACQABAAAAAAQAAAAAAgBQABAAAAAAQgBAAAAgBIAAAAIACAAIAAgBIABAAIABAAIADAAIABgBIAAgCIAAgBIgCABIgBABIAAABQAAAAAAABQAAAAgBAAQAAAAAAAAQAAgBgBAAIAAAAIgBgBIABAAIABAAIAAAAIAAgCQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAIAAABIAAgCIgCAAQAAgBAAAAQAAAAABAAQAAgBAAAAQAAAAABAAIABgBIgCgCIACgDQAAAAAAABQABAAAAAAQAAABABAAQAAAAABABIAAgCIAAAAIgBgBIgCgBIAAgCIABAAIAAABIAAABIACgCIABABIAAgDIACgEIgEAAIAAgCIACgBIAAABIAAAAIAAABIABAAIADAAQAAAAABAAQAAAAAAAAQAAABAAAAQAAAAAAABIACgBIgBABQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAAAIgBACIABABIgBABQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAAAIABABIABAAIgCABIgBACIAAACIAEgBIACACIgBACIAAAAIgBACQABAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAIgBACQAAAAABAAQAAABgBAAQAAAAAAABQAAAAgBAAIgBABIABABIAAABQAAAAAAABQgBAAAAABQAAAAAAAAQgBAAAAAAIgBACIgDAKIABACIAAABIgCACIgBgBIAAgBIgDAAIgCAAIABABIAAABIABgBQAAAAAAAAQAAgBAAAAQABAAAAAAQAAAAAAABIAAABIgBABIABABIABABIABAAIABACIgBAFIABAAIgCACQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAIABAAIAAgBIgDAAIAAAAQAAAAgBAAQAAgBAAAAQAAAAAAgBQABAAAAAAIgDAAIgBgBIABgCIABABIgBACIADgBIADAAIAAAAIAAABIABgBQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIgBAAIAAgCIgDAAIgBAAIgDgBQAAAAAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAIgCABIACAGIAAACIAAAAIgBABIAAAAIAAABIgCAEIAAABIAAAAIACgCIADgBIACABIgBABIgDACQgBAAAAAAQAAAAAAABQgBAAAAAAQABABAAAAIAAACIgBgCIgBgBQAAAAAAAAQAAgBAAAAQgBAAAAABQAAAAAAAAIgBABIABACQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIgCABIgBAAIgBgDIgBgBIgBAAQgBAAAAAAQgBAAAAAAQgBgBABAAQAAgBAAAAIAAgBIgCgCIAAAAQABAAAAAAQAAAAABAAQAAAAAAgBQABAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAIAAAAIAAgBIADACIABAAIgBgBIgBgBIgBgDIgBgBIAAABIAAACIAAABIgCgDIABAAIgBgCIAAAAIgBAAIABACQAAAAAAABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgBAAIgBAAIAAAAIAAACIgCACQgDgBgCADIgCACIgEAAIACgBIABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAgBAAAAIAAgCIgBgBIAAABQAAAAAAAAQAAABgBAAQAAAAAAAAQAAABgBAAIgBAAIgBAAQAAABgBAAQAAAAAAAAQAAAAgBAAQAAAAgBAAIgBAAIABgCIABgBIAAgBIABgBQABAAAAgBQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAAAABQgBAAAAgBQAAAAgBgBQAAAAAAAAQgBAAAAAAQAAAAgBABIAAABIAAABIgBABIACAAIAAABIAAACIgBAAIgCgCIgCgBIgCgCIgBgDIgBABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABIAAAAQAAABABAAQAAAAAAAAQAAAAgBAAQAAAAAAAAIgBAAIgBgCIgBgBIgDADIgBABIgBAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAABIAAAAIgBgBIgCgBIABABIACAFIAAABIACgBIABgCIgBADIgCAEIAAgCIAAAAIgBAAIAAAAIgCABQgBAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAABIABAAIAFABIADgBIABgCIABgBIABABQAAAAAAABQABAAAAABQABAAAAAAQABAAABAAQAAAAABAAQAAAAABAAQAAgBAAAAQAAAAAAgBIgBABIgBAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAIAAgDQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAgBgBIgBgBIgBABIACgDIAAgBIAAAAIgCABIACgCIABAAIAAABIAAACQAAABAAgBQABAAAAAAQABAAAAAAQABgBAAAAQABAAAAgBQAAAAABgBQAAAAAAAAQABAAAAAAQABAAAAABIAAAAIAAABQAAAAgBgBQAAAAAAAAQgBAAAAAAQAAABgBAAIAAABIABAAIADABIADAAIACAAIABABIgCABIgBAAIABABQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAIAAAAQAAABABAAQAAAAAAAAQAAAAAAAAQABAAAAgBIAAAAIAAgBIABAAIAAADIAAABIgEAAIADABIABAAIAAABIgCABIABAAIAAABIgUgBIgBgBIgBAAIgBABIgCABIgBAAIgIABIgJAAQgFAAgEgCQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAABAAAAIABgFIABABIAFABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIABgDQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgHgEQgBAAAAAAQAAAAgBAAQAAAAAAgBQAAAAgBgBIABgBIABAAIAHgBIAMAAIABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgDAAQAAAAAAABQAAAAAAAAQgBAAAAgBQAAAAgBAAIAAgCIABAAIgBgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBABAAIABgCIgDACQAAAAgBAAQAAAAAAAAQAAAAAAAAQABgBAAAAIAAgCQAAgBABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABABIABgBIgCgBQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABAAIgBgBIAAgBIABgCQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIACgBIAAgBIgBgBIgBABIAAAAIAAAAIgBgCIABgBIACgBIABAAIABAAIgBAAIgCgBIAAgEIgCAAQAAAAAAAAQAAAAgBgBQAAAAAAAAQAAAAAAgBQAAAAAAgBQAAgBABAAQAAgBAAAAQAAAAABgBIAAgBIACAAIASAGIACAAIgBgBIgDgBIAAAAIgJgEIgDAAIgEgCIgBAAIgBAAIAAgBIABgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQABAAAAgBQAAAAAAAAQAAAAAAAAQAAgBgBAAIAAgBIAFgMIAAgBIACgEQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIABAAQAAAAAAgBQgBAAAAAAQAAAAAAgBQAAAAAAAAIABgCIACgBIACAAQABAAgBABIABAAIABAAIgBgBIgDgCIgBAAIAAgCQABAAAAgBQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIgCgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAABgBIAAgBIACAAIABAAIAAAAIgBgBQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIACgFIABAAIAAAAIAAgBIACAAIAAABIABABQAAAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABIgBACIABABIABgBIACgGQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQAAAAgBABIgBAAIACABQABAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABIgBABIgBAAIgBgBIgBAAIgBABIAAgCQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAABAAIAAgBIgBAAIADgIIACgBIABAAIACgBIABgBIABAAIACAAIAJADIADACQABAAAAAAQAAAAAAAAQABAAAAgBQAAAAAAAAQAAAAAAABQAAAAABAAQAAAAAAABQAAAAABAAIAAAAIACABIABgBQAAAAABABQAAAAAAAAQAAAAABABQAAAAABAAIADABQgBgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIABgCIgBgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABAAIACAAIABgBIAAAAIABABIAAAAQAAAAAAABQABAAAAAAQAAAAAAABQAAAAAAAAIgBAEQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAgBAAIALAEQAAAAABABQAAAAAAAAQAAAAAAAAQAAgBAAAAIABgBQAAAAAAAAQABgBAAAAQAAAAAAAAQABABAAAAIABACQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIAFACQAAAAAAAAQABAAAAAAQAAAAAAABQgBAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAABAAIAFACQABAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAgBIgBgCQAAgBgBAAQAAAAAAAAQgBAAAAAAQAAAAAAABIgBABIgDAAIgCgCIgBgBQgCgFgFgFIgBAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAABABQAAABgBAAQAAAAAAABQgBAAAAAAIgCABQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBgBIAAgBQABAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIAAgBIABgBQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAgBQABAAAAAAQAAgBAAAAQAAAAAAgBQAAAAgBAAIAAgBIgCAAIAAgBIgEAAIgDgBQgBAAAAAAQAAAAgBAAQAAAAgBABQAAAAAAAAIgBABQAAAAAAAAQAAAAgBgBQAAAAAAAAQAAAAAAgBQAAgBAAABIgCAAIgBABIgCgBIgEABIgDACIgBAAIAAgBIAAgBIgCgCQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAABAAIABgBIABAAIAEgCIABgBIABgBIABAAQADABADgBIgFAAIADgBIAAAAIABgBIgDAAIgDgBIADABIABgBIgBgBIgCgCIgBAAIgDAAIAFACIgCAAIgBAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABIAAAAIgCgCQABAAgBAAIgCgCIgBgBIACAAQAAAAABABQAAAAAAAAQAAAAAAAAQABgBAAAAIAAAAQAAAAABABQAAAAAAAAQAAAAAAAAQABgBAAAAIAAABIAAAAIABABIABgBIAAAAIADABIACAAQAAABABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIADgEQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIAAAAIABgDIABgCQAAAAAAgBQAAAAABAAQAAAAAAAAQAAAAABAAIAAgBIACgCIAAgGQAAAAAAgBQABAAAAAAQAAgBABAAQAAgBAAAAIACgCIABgCIABgCIAAAAIgBAAIAAAAQAAAAgBABQAAAAAAgBQAAAAAAAAQAAAAAAgBIABgEIACgBIABAAIABABQAAABAAAAQAAABABAAQAAAAAAAAQAAABABAAIAAAAQAAAAABAAQAAAAAAABQABAAAAAAQABAAABAAIADgBIgDgCQgDgBgFgEIgBAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIgCAAIgBAAIAAABQAAABAAAAQAAABAAAAQAAAAAAAAQABABAAAAIACABIgEAAIgDAHIABABIACABQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAgBIAAAAIABgBIAAAAQABAAAAABQAAAAAAAAQAAAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAAAgBAAIAAABIAAABIAAAAIgFgCQAAAAAAgBQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAAABQAFACABAFQgCgEgCAAIABACIABACIAAABIgDAEIABgCIgBgBIAAAAQgBAAAAgBQAAAAgBgBQAAAAAAAAQgBAAAAAAIAAgBIAAAAIgBgBIgDAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQABAAAAgBIABgBIgCABIgBACIgBAAIAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgEACIgCADQgCAEACAEIgCAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBgBQgBAAAAAAQAAgBAAAAQAAAAAAAAQAAAAABAAIABgDIAAgCIABABIACgDIADgCIgCgBIgBAAIgDAFIABgDIAAAAIAAgBQABAAAAgBQAAAAABAAQAAAAAAgBQAAAAAAgBIgCABIgBABIgFANIAAACIgBACIAAACIgBABIABACQAAAAAAABQABAAAAAAQAAAAABAAQAAAAAAAAIgBACIgBABIAAAAIAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIgBgCIgBADIAAAAQgBABAAAAQAAABgBAAQAAAAgBAAQAAAAgBAAIgBAAQAAAAAAAAQAAAAgBgBQAAAAAAAAQAAAAAAgBIACgGQABAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIAAgBIABgCIACgIIAAAAIACgFIAAgBIACgGIAAAAIABgCIABgCIAAAAIACgCIAHgXIAAgBQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIAEABIABABQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIAFACQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAIgBgKIABgEIACgCIAEgCIADgBIADgCIADgCIABgCQABAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAIgFABIgCAAIgBAAIgCAAIACgBIAHgBIADgCIABgDIgBgBQAAAAgBABQAAAAAAAAQAAAAAAgBQAAAAAAAAIABgBIABAAIABAAIAAgCIgBgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABAAIAAgBIAAgCIABgBIAEgCIAAgBQAAgBAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQABgBAAAAQABgBAAAAIAAgBIgBAAIAAAAIACgBQAAgBABAAIACABQAAgBABAAQABAAAAABQABAAAAAAQAAABABABIAAAAIABgBQAAAAAAAAQAAgBAAAAQABAAAAAAQAAAAAAAAIABAAIABABIAAABQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAABAAIAFgCIAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAIgCAAIgBAAIABgBIAEAAIAAAAIABAAIAAgBIgDgBIgFgBIgBAAIgDgCIAAAAQAAAAAAAAQABAAAAAAQAAgBABAAQAAAAAAgBIACABIACAAIABACIADACIAAgBIACgBIABAAQABgBgBAAIgBgBIABgDQABAAAAgBQAAAAAAgBQAAAAAAAAQgBgBAAAAIgDgBQABAAAAAAQAAAAABAAQAAAAABAAQAAABABAAIAAABQABABAAAAQAAAAABAAQAAAAAAAAQABAAAAgBIACgCIgEAJIAEAAIAAAAIgBACIgEACQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAABIAAAGIAAABIgBgCIAAAAIAAAAIAAADIABAAIAAABQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIAAABIABABIACgBIABgDIAAgGIABgBQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBgBAAIgCAAIAEgCIACACIAEABIgBAAIgCgBIgBABIAAABIgCgBIgBABIABAAIAEACIABgBIABADIgEgCIgBAAIgCAAIAAABIAAACIgBAFIABABIgCAAIgBACIAAgBIAAgBIgBABIAAAAIACADIABADIgBACQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAABABIAAAAIABABIAAACIAAABIgBgBQgBADACACIgBABIABABIACAAIAAAAQAAAAAAAAQABAAAAABQAAAAAAAAQABAAAAABIAAAAIAAACQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAIABgCIAAgBIABAAIAAgCIAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIACgEIAAgDIACgDIgBgCIAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgCgDQgCgEgBgBIgBgCIABgBIACACIAAACQAAABAAAAQABABAAAAQAAABABAAQAAAAABABIABAAQAAAAgBgBQAAAAAAAAQAAgBABAAQAAgBAAAAIADgCQABAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIAAgBIABABQAAABAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIgBgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAIgBAAIABgCQAAAAAAABQABAAAAAAQAAAAABAAQAAgBAAAAIABgBQAAAAAAgBQABAAAAAAQAAgBABAAQAAABAAAAIAEABIAAACQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAAADIgEALIAAACIABAAIAAgBIABgBIABABIAAABIABgBQAAAEgDAHIABgGIAAgBIgCgBIgBAAIgBADIgCAEIABACIABABIgBAAIgBgBIAAABIgCAGIAAABIgCAFQAAAAgBABQAAAAAAAAQAAAAABABQAAAAAAAAIAAABIAAAAIgBABIgEANIgBADIABAEQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABIgCACIAAACIABAAIgCABIgCALIAAAEIABABQAAAAAAAAQABAAAAAAQAAAAAAABQgBAAAAAAIAAABQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQABADgCACQABAAAAABIgBABIgBgBIAAgBIgBgBIgCACIgBABIgDgBIgCAAIAAgBIAAAAIADABIABAAIAAgCIABgBQABAAAAAAQAAAAABAAQAAAAAAAAQABgBAAAAIACgEIAAgBIAAgBQAAAAABgBQAAAAAAAAQAAgBAAAAQAAAAgBgBIgBgBIACAAQAAAAAAAAQABAAAAAAQAAgBAAAAQAAAAgBAAIAAgCIABgFIgBAAIgBAEIAAACIgBAAIgBAAIgBgBQABAAAAAAQAAgBAAAAQAAAAAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAABAAAAQAAAAAAABIgBABQgBAAAAAAQAAABAAAAQgBAAAAABQABAAAAAAIgCAGIAAgEIgBAAQAAAAAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAIgEgBIgBABIAAAAQAAAAABABQAAAAAAAAQAAABAAAAQAAAAAAABIAAABIgCAEIAAABIABADIACgEIADgDIgBABIAAACIAAAAIgBABIgDAEIgCAFIgCAFIAAABQAAAAABAAQAAAAAAgBQAAAAABAAQAAABAAAAIAEgCIACABIAAgBQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIABAAQAAgBAAAAQAAAAABAAQAAAAAAAAQABAAAAAAIAAgBIADgDIABgBIgCgBQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIABAAIgBgBIAAgBIABABIABAAIABgCIABAAIABABIgBABIAAACQAAAAAAABQABAAAAAAQAAABAAAAQABAAAAAAIABAAIABgBIABABIABgCIAAACQAAABABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAEgCAEACIABABIACAAIABgBQAEgDADADIAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAAAAABgBIgBAAIAEgBIAFAAIABABIgDAAIABABIABAAIADAAIACACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIAQgBIADgBIAAAAQAAAAABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIAAgBIAAAAIABAAIAAgBIAAgCIgHgXIAAgBIABgBIABAAQAAgBABAAQAAAAAAgBQAAAAABAAQAAAAABAAIAIgBQAAAAABAAQAAAAAAgBQABAAAAAAQAAgBAAAAIgDACIgCAAQgEgBgBgDIgBAAIgCgDQAAAAAAAAQAAgBABAAQAAAAAAgBQAAAAABAAIACgCIAAgBIgBgEQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAAAAAABIgCABQAAAAgBABQAAAAAAAAQAAAAAAAAQgBgBAAAAIABAAIADgCQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIgDABIgCACIgBAAQgBAAAAABQAAAAAAAAQgBAAAAgBQAAAAAAAAIABgCIABAAIADAAIACgBQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBgBIgDgKIgBgBQAAAAAAAAQAAgBgBAAQAAAAAAABQAAAAgBAAIAAABIABgCQAAAAAAAAQABAAAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAABAAIAAgCIAAAAIAAgBIACABIACADIAAAAIAAACIAEAKQAAABABgBIABgBIgBgBIgBgEIgCgEIgBgCQAAgBAAAAQAAAAAAgBQAAAAABAAQAAAAAAAAIAEgCIACAAIAAABQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAABAAIACgBQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAIgBAAIAAABIABABIACgCIABAAIAEgBIACgBIgBAAIgBgBQAAAAABAAQAAAAABAAQAAAAAAAAQABABAAAAIACABIgBgBIAGgBIACAAIABgBQAAAAAAgBQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAABAAQAAABABAAQAAAAAAAAQABgBAAAAIAEAAQABAAAAAAQABAAAAAAQABgBAAAAQAAAAAAgBQAAAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAIACgBQABAAAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIgDAAIgBABIgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAABIgEABIgDABIgFAAIgBABIgFAAIgHgCQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABIAAABIgDAAIABgCQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgDgCIgBABQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAABIgBAAQAAABAAAAQAAAAgBABQAAAAgBAAQAAAAgBABIABgCQABAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBIgBABIgDgCIAEgBIgGgEIgCACIgCgEIAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIABgBIgBAAIgCgBIABgBQAAAAAAgBQgBAAAAAAQAAAAAAgBQAAAAAAgBIgBgBQABAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgBIABAAQABABAAgBIABgIIADgCIABAAIABgCIADgDIgFAAIAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAABIgEACIAAABIgBAAIABgBIAAgBQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAAAgBABIgEAAIgBgBIACgBIgDgBIACAAIABAAIABgBIAAAAIgCgCIgBgBIACAAIACAAIgCgBIgEgEIAAgBIgDgEIgBADIgBABIABAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgCAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgDgDIgFgCIgBAAIgBAAIgDgCIABgCIABgBIABAAIAAgBIABgCIABgBIABgBIAAAAQAAgBAAAAQABAAAAAAQAAAAABAAQAAAAABAAIgCgBIgEAAIAAgBIAAgBIABAAIACAAQgCgCgEABIAAgBIgBAAIADgBQAAABAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAIgBgDIAAgBIAAAAIgBgBIgCAAIgBgBIgBAAIABACIAAACIgBACIAAAEIAAAAIgCACQAAgBAAAAQAAAAAAAAQAAgBAAAAQgBAAAAAAIAAgBIABAAIABgBIAAgBIAAAAQAAAAABgBQAAAAAAAAQAAgBAAAAQgBAAAAgBIAAAAIgCgBIAAAAIgBgBIgBgCIAAABIAAAAIgBAAIABgBIgFACQgBAAAAAAQAAAAAAAAQgBAAAAABQAAAAAAAAIgBABIgDAEIABACIAEABIABAAIAAAAIgCAAIgDABIABgBIgCgBIAAABQAAAAAAAAQAAABAAAAQAAAAABAAQAAABAAAAIACABIgBABIgBACIAAABIgBgBIgDgBIgBABIAAABIABAAIABABIAAABIABAAIgBAAIgHAAIgGAAQgNADgGAOIgBABQABAAAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAIgCgBIgCgEIgBgDIABgCIAGgJIADgBIABgCIAAAAIAFgDIABAAQAAgBgBAAQAAAAgBgBQAAAAAAAAQgBAAAAAAIgEABIAAABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIABABIgBABIgBAAIAAABIgCgBIABgEIgBgBIgCgCIAAgCIAAgBIABAAIAAABIABAAIAAgBIgBgBIAAgBIAAgBIABABIAAAAIAAgBIAAgDIAAgBIADADIgCgDIABAAIgBgBIABgBIAAgCIAAAAIABABIAAgCIABgBIADgDIABABIAAgDIABABIABABQABAAAAABIABgBIAAABIABAAIABAAIAAAAIgBACIABAAIABAAIABAAIAJAHQAAAAABAAQAAAAAAABQAAAAAAAAQAAAAAAABIgDAEIgCADQAAAAABAAQAAgBAAAAQABAAAAAAQAAABABAAIgCABIACAAIgDABIADAAIAFABIABAAIAAgCIAAgBIACgDQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAgBgBAAIABgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIAAgBQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAAAgBAAIAAgBIgCgCIACABIgBgBQAAgBAAAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgBAAIgBAAIAAABIgDAAIAAAAIgBAAQAAAAgBAAQAAAAgBAAQAAgBAAAAQAAgBAAAAIABgCIAAgBIAAgCIAAgBIgCAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgBIgBAAIgBgDIABABIABAAIAAgBIABAAIgBgCIgBAAIAAAAIAAABIgBgBIAAABIgBgCIAAgBIABABQABgBAAAAQAAAAABAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAgBABAAIABgBIABAAIgEgCIAEABIABAAQABAAAAgBQABAAAAAAQABAAAAAAQAAAAABAAIAAgCIABAAQAAAAAAgBQAAAAgBAAQAAAAgBgBQAAAAgBAAIgBABIgBAAIAAgBIAAgCIABgBIABABQABAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgDIgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIAAAAQABAAAAAAQABAAAAAAQABAAAAABQAAAAAAABIABAAIAFgBIAEAAIgCgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABIAAgDIACAEQAAAAABAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgBAAIAAABIAAAAIACAAIACAAIAFACIAAABIAAACIABABIAAgBIABACQAAAAAAAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAAEIgBgBIABACQAAAAAAAAQABAAAAAAQAAABABAAQAAABAAABIAAABIAAAAIgBAAIgBAAIAAAAIAAABIADAAIAAADQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAAAAAIAAACQAAAAABAAQAAAAABAAQAAAAAAgBQABAAAAgBIABgBIgCgBIAAgBIAFABIAAgBQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAAAAAIAEAAIgCACIACgBIABAAIABgBIgCAAIACgBQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAgBIACAAIgCgDIABAAIACAAIACAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIAAAAIABAAIgBgCIgBgCIgBAAIgBgBIgBAAIAAgCQABAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAIgBgCIgBAAIgCgCIAAAAIABAAIADABQAAAAAAABQABAAAAAAQAAABAAAAQAAAAAAABIAAABIABABIABgBIgBgDIgBgCIgDgBIgEgBIAMAAIgBACIgBgBIAAAAIAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAABABAAQAAAAAAABQAAAAAAAAQAAAAAAgBQAAAAAAAAIABgBIABgBIABABIgBACIAAABIABAAIABABIAAABIABABIAAAAIAAABIAAAAIABAEIABABQgBAAAAAAQAAAAAAgBQgBAAAAAAQAAAAAAgBIgBgCIAAAAIgBAAIAAABQgBAAAAABIABACIABACIAAgBIgCgCIgBAAQgBAAAAAAQAAABABAAIABAAQAAABAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIABACIABgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABgCIAAgBIABAAIAAABIABABIAAgBQAAgBABAAQAAAAAAAAQAAAAAAABQABAAAAAAIABABIACADIADADIACACIABgBIACAAIABgCIABgBIAFgEIABgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAABgBIABgBQAAAAAAAAQABAAAAAAQAAgBAAAAQgBAAAAAAIAAgDIABgBIACgBQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAIABABIABgBIAAgBIAAgBIABABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIAJgEQABAAAAAAQAAAAAAAAQABAAAAABQAAAAAAAAIABACIABABIAFAQIAAACIABABIABACIACAFIAAABQAAAAAAAAQAAABAAAAQAAAAgBAAQAAABAAAAIgRAGQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgBADIACADIgCAAIgDAAQAAgBAAAAQABAAAAAAQAAgBAAAAQAAgBAAAAIgCgCIAAAAIAAACIAAABIgBAAIgDgBIgBAAIgBAAIAAABIABABIgCAAIAAgBIgBAAIAAABIABACQgBgBAAAAQAAgBgBAAQAAgBAAAAQAAAAABgBIAAgCIgDgCQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAIgBgBIABADQAAABAAAAIABAAIgBABIAAABIABAAIAAAAIADgBIAAgBIAAABIAAABIgCACIgCAAIABABIAAAAIABAAIAAACQAAAAABABQAAAAAAAAQAAABAAAAQgBAAAAABIADAAIADABIABAAIABgDIABgCQABgBAAAAQAAAAABAAQAAAAAAAAQAAAAAAABIABABIAGAIQAAAAAAABQAAAAAAAAQABAAAAAAQAAAAABAAIgCgDQAAAAAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBIAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIABgBIgDgBIgDgCIAAAAIAEACIADABIADACIgBAAIgBgBIgCABIAAACIAAAAIABACIACABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQAAAAABAAIAAgBQABgBAAABIAAABIABgBIAAgBIgCgBIAAACIgEgFIAAgBIAAgBIABABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIAAgCIgBABQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAAAABAAIABAAIAAAAIgCABIABABIgBACIABAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAABAAAAQAAAAgBABQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAgBQAAAAAAAAQAAAAAAgBIABgBIAAAAIAAgBIAAAAIABAAQAAAAAAgBQAAAAgBAAQAAAAAAgBQAAAAAAAAIgCgCIAAgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABIACAAIAEABIABABIABgBIgCACQAAAAABgBQAAAAABAAQAAAAAAgBQABAAAAgBIAAAAIAAAAIAAABIgBADIAAACQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIAAAEIgCgCQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIAAABIgCAAIgCABIgBAAIACABIABgBQABAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAABQAAAAAAAAQAAAAAAABQAAAAABAAQAAAAAAAAIAGABIACAAIAEABIAAABIAAABIgCAAIgGgBIgBABIACABIAFABQABAAAAAAQAAAAAAAAQABAAAAABQAAAAAAAAIABACIAAABIgDAAIgDgCIgBAAIgBAAIgDABIgBAAIgDgBIgBAAIABAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAIgBAAIgCgCIgCAAIgBgBIgBAAIgCAAIgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBABgBAAIgBABIACAAIgBACQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAIgBgBQAAgBAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAIgEADQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAIgCgBIAAgBIgCgEQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgCAAIgCACIAAACQAAABABAAQAAAAAAABQAAAAAAAAQgBABAAAAIgBABIgCABIgBAAQgBABAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIADABIACABIACABIADABIABAAIADAAIABgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAgBAAAAIABAAIAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAABAAIADADIAAAAIABAAIAAgBIABAAQAAAAAAAAQAAABABAAQAAAAAAABQABAAAAAAQAEABACACQADACAEAAIABgBQAAAAABAAQAAAAABAAQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAAAAAAAQAAAAABAAIAAAAIAAgBQAAAAABABQAAAAAAAAQAAAAAAgBQABAAAAAAIABACQABABAAAAQAAAAAAAAQAAABAAAAQAAAAgBAAIAAABQAAAAAAABQAAAAAAAAQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAAAABQAAAAABAAQAAAAAAAAIAFAFIAFACQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIgBgCIgCAAIAAABIACAGQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAABQAAAAAAAAIABACIgCADIgBAAQAAABgBAAQAAAAgBABQAAAAAAABQAAAAABABIAAACIgBgBIgBAAIgBABIAAACIABAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAABAAIAAABIABABIACAAIACAAQAAAAABAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIAAgBIACACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIAAgBIAAgBIgBgDIgBAAQgBgGgCgCQABAAAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgBgBIAAgCIgBgBIgBgBIABgBIACAAQAAAAAAAAQABAAAAgBQAAAAAAAAQgBAAAAgBIAAgCIAAAAIgBgCIgBgCIgBgBQgBAAAAgBQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIAAgBIgBgBIgBABIAAADIgBAAQAAgBgBAAQAAAAgBgBQAAAAAAAAQgBAAAAAAIgCgBQABAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQABAAAAAAIADgBQAAgBAAABIABACQAAABAAAAQABAAAAAAQAAAAAAAAQABAAAAgBIAAAAIgCgCIAAgCIABgBIADACIADAFIABAEIgBABIAAAAIgBgBIgBgBIgBABIgBABIABABIACADIgBABIABACIACAEQAAAAAAABQAAAAAAAAQAAAAABAAQAAAAAAAAIADAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAABAAAAIgBABIgDAAIAAABQABAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgBABIACABQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAIACADIACADIAAABIAAAEIABACIABACIAAABIAAAAIgBgBQAAABAAABQAAAAAAABQABAAAAABQAAAAABAAIACAEIgCgDIgBAAIgBABIAAABIABAAIABACIgCAAQAAABAAAAQAAAAgBAAQAAAAAAgBQAAAAAAAAIABgBIAAgBIgBAAIgDACQAAABAAAAQgBAAAAABQAAAAAAAAQAAABAAAAIgBABIAAABIgDAAIABAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAAAIgBgBQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIgBAAQAAABgBAAQAAAAAAAAQAAAAAAAAQgBAAAAgBIgBAAQAAAAgBgBQAAAAAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAABAAAAIAAgCIgBAAQAAAAgBAAQAAAAAAAAQAAAAAAABQAAAAABAAIAAABIgBAAIgDgBIgCAAIgCACQAAAAgBAAQAAAAAAAAQAAABABAAQAAAAAAAAIADABIABAAIABgBIACABIAAACIABAAIABABIACACIAAACIACABQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAAAgBIgBgEIACABIABACIAAABQAAAAAAAAQAAAAAAAAQgBAAAAABQAAAAAAAAIAAABIAAAAQgBAAAAABQAAAAAAAAQAAABAAAAQABAAAAAAIAEACIAAABIAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAABAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIAAAAIgBACIAAAAIADABQAAAAABAAQAAAAABAAQAAAAAAgBQABAAAAAAIABgBIAAADIABABQAAgBABAAQAAAAAAAAQABAAAAABQAAAAABAAIAAABIACAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIABABIAAAAIACADQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABIAAAAIgBACIgCgBIgBgCIgCgBIABgBIAAgBIAAgBIgBAAIgBABIgBABIgCAAIAAAAIAAABIADACIAAABIgBAAIgCABIAAABIAAABIgCAAIAAgEIAAgCIAAAAIABgBIgCAAIgDADIgBACQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIAAgCIABAAQABAAgBgBIABAAIAAgCIABAAIACgBIAAgCIgCgBIgBgBIgCADIgBABIgBACIABgBIgBACIAAABIABACIAAACIAAABIABABIAIABIADgBQABAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIACABQAAAAAAABQABAAAAAAQAAAAAAAAQgBABAAAAIgBABQAAABgBAAIgBAAIABABIACgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABIADAGQABAAAAAAQAAAAABABQAAAAAAABQAAABABABIgBABIgCADIgBAAIAAABIACABIACADQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIABABQABAAAAABQAAAAAAABQAAAAAAABQAAAAgBABIAAAEIACABIABgBIgBgBIgBAAIAAgBIABAAIADAAQAAABAAAAQAAAAAAAAQABAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAIAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBIgDgEQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAAAAAIABAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAgBAAIgBAAIgCgCIgEgJQgBAAAAAAQAAgBAAAAQAAAAABAAQAAAAAAAAIACAAIACAAIABAAIAAAAIABACIACgBQAAAAAAAAQABAAAAAAQAAAAABAAQAAABAAAAIAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIABAAIAAAAIgEgHIgBgCQAAAAAAAAQAAgBABAAQAAAAAAAAQAAABAAAAIABAAIAAABIAAACIABABIAAgDIACAAIABACIACACIABAAIAEALIACAGIABAAIAIAXQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAgBAAIgBACQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAIAAgEIgCAAIAAAAIAAACIABACQABAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIgBAAIgBAAIgBABIgBACQAAAAAAgBQAAAAAAAAQAAAAgBgBQAAAAAAAAIAAAAIgBgBIgBAAIAAABIABAAIgEAAIACADIABADIACABIACAAIABAAQADgCADABQACACAAAEQgBAEgDAAIgDABIAAABIABADIABAGIAAABIADABIAEAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAEADABADIABABIACACQAAAAAAAAQABAAAAABQAAAAAAAAQAAAAAAAAIgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAEgFAEIgBAAIAAACIADAAIgBABIAAACQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIABAAQABAAAAAAQAAgBABAAQAAAAAAAAQAAgBABAAIACgDIAAAAIADABIADAIIACACIABABQAAAAABABQAAAAAAAAQAAAAAAABQAAAAAAAAIAAABIABADIgCgDIAAABIABADIABAAIAAABQAAAAgBAAQAAAAAAABQAAAAAAAAQABAAAAAAIABABIgBAAQAAABAAAAQABAAAAABQAAAAABABQAAAAABAAIgCAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAABIAAAAQgBAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAIACADIgBABQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAIAAAAIgFgCQgBAAAAABQAAAAABABQAAAAAAABQABAAAAAAQAAABABAAIABAAIADACIAAABIADADIAAACQAAAAAAABQAAAAgBAAQAAABAAAAQAAAAgBAAIAAABIABAAIADABIABAAIADAHIABAEIgBACIAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAAAAAIAAAAIABABIgzABgACTCcQgBAAAAAAQAAAAAAAAQgBABAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAABAAIgDAEIADAAIACgEQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAIAAAAgACFCgIAAAAIAAABIADgCgABjCdQAAAAAAAAQABAAAAAAQAAABAAAAQgBAAAAAAQAAABAAAAQAAABABAAQAAAAAAAAQABABAAAAIAAgDIABgCIgBgBIgBABIgBAAgABdCbIACACIAAACQAAAAAAAAQAAABAAAAQAAAAABAAQAAABAAAAIABgBIAAgBIgBgCIABAAIgCgCIgBAAIAAgBIAAAAIABAAIAAgBIgBAAIgBAAIgBgBIABgBIAAgBQABAAAAgBQAAAAAAAAQAAAAAAAAQAAAAgBAAIgBAAIgBACIgDAAIgCgBIAAABIAAAFIAAACIABACIACAAIABABIABAAIAAgBQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIACgDIABgBIAAAAgACNCeIgDABIgBAAIAAABIACAAIACAAQABAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIgBAAIgCAAgAByCdIAAACQAAABgBAAQAAAAAAAAQAAAAABAAQAAAAAAAAIADgCIAAgBIgBgBIgCABgABwCbIABAEIAAgCIABgCIAAAAIgBAAgAh1CYIAAABIABADIADAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIAAgCIgDACgACQCaIAAABQABAAAAABQABAAAAAAQABAAAAgBQAAAAABAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAIgBAAgABlCaIABABIABAAIAEgDIABgCQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAgBAAAAIAAAAIgBADIgCAAQgBAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAABgAhxCaIABABIABAAIABgBIgBgBIgBAAIgBAAgAiTCaIACABIABgBIgBgBIgCAAgAiPCYIAAABIABABQAAAAAAABQABAAAAAAQABAAAAAAQAAgBABAAIgBgBIgCgBIgBgDgACZCYQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAgBgBIAAgCIgBABgAiLCZIABABIACgBIgCgBgACDCZIABABIAAgBIACgDIgDACIABgBIABgBQAAAAABgBQAAAAAAAAQAAAAAAAAQgBgBAAAAIgBABIgBABIAAABIAAABgACSCYIAFAAIABgBIgBgCIgBAAQAAAAgBgBQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQAAAAAAAAQAAABABAAQAAAAAAAAIABAAIABAAIgBABIgCAAgACLCXIABABIABAAIAAAAQAAgBAAAAQAAAAAAAAQAAAAgBAAQAAAAAAAAgAh5CVIACACIABAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIAAgBIgBAAIgCAAgACHCUIABACIABgBIgBgBgABnCTIAAABIABAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABgBQAAAAAAAAQAAAAAAgBQgBAAAAAAIgBgFQAAgBAAAAQAAAAAAgBQgBAAAAAAQgBAAAAAAIgBAAIAAgBIAAgBQABAAAAAAQAAgBAAAAQAAAAAAAAQgBAAAAAAIgCgBIgBAAIgCACIgDABIgDADQAAABAAgBQABAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABIABABIACgCQAAAAAAAAQABAAAAAAQAAAAABAAQAAABAAAAIABgBIgCgCIABAAIACAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQABABAAAAIAAABIgBADIAAABIABABQAAAAAAABQAAAAAAAAQAAABAAAAQABAAAAAAIAAAAIABgCgABXCUIABAAIAAgBIgCgDIABAEgACKCUQAAAAABAAQAAAAAAgBQAAAAABAAQAAAAAAgBIgBgBQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAgACQCPQABAAAAABQABAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAQAAgBABAAQAAAAgBgBQAAAAAAgBIgDgEIgBAAIgEAAIgCABIgBABIABADQAAABAAAAQAAABABAAQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIABgBgAhwCLIgBABIgCABIAAABIABACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIAAgCIABAAQAAAAAAAAQABAAAAgBQAAAAAAAAQAAAAAAgBQAAAAABAAQAAAAAAAAQAAAAAAAAQgBgBAAAAIAAAAIgBAAgAhlCLQAAAAAAABQAAAAAAABQAAAAAAAAQgBABAAAAIAEgCIAAAAIAAgBIAAABIgCgBIgCgCgAhoCKIABABIAAABIgBABIABAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAgCIgBAAgAiDCKIAAABIAEACIgCgDIgBgBIAAABIgBAAIAAAAgAh+CLIABABIAAgBIgBgBgAh5CIIACACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIgBAAIAAAAIABgBIABgBIgBgDQAAAAAAgBQAAAAAAAAQgBgBAAAAQAAAAgBAAIAAACIgBACIgBgBIgDgBIAAAAIgBAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAABAAAAIgBACIAAgDIgCgFIAAgFIAAgCQgBAAAAgBQAAAAAAAAQABAAAAAAQAAAAABAAIACgBIABAAIAAgBIAAgBIACgBQAAAAABAAQAAAAABAAQAAAAAAAAQABABAAAAIAAAFIABADIAAADIgBgDIAAACIACAEIAFAEQABABAAAAQAAAAAAAAQABAAAAAAQAAAAABgBIACgEIABAAIgCAEIABABIACAAIAAgBQAAgBABAAQAAAAAAAAQAAAAAAgBQgBAAAAAAQgBAAABgBIgBgCIACABIAAgBIAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIAAgBQABAAAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAIgCABIAAAAIAAgCIABAAIACAAIAAgDIgCABIgBAAIAAgCIgBgBIAAABQAAAAgBAAQAAABAAAAQAAAAgBAAQAAgBAAAAIgBgCIAAABIgBAAIgBgBIAAgBIAAAAIgBAAIAAADIgBACIAAgCIgBABQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAQABAAAAgBIACgBIAAgBIAAgBIgBAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIACgBIAAgBIABgDIgDAEIAAABQAAAAgBgBQAAAAAAAAQAAAAAAgBQAAAAAAgBIADgFIAAgCIgBADQAAgBAAAAQgBAAAAAAQAAAAAAAAQAAAAAAABIgDAEQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBIAAAAQgBAAAAgBQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAgBgBAAQAAAAgBAAIgBABIgBACIgDABQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIABABIABAAIACAAIgBABQAAABAAAAQAAAAAAAAQAAABgBAAQAAAAAAAAIgCACIgBACIABABQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABIgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABIADACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABgDIAAgBIABAAQABAAAAABQAAAAAAAAQAAAAAAAAQAAABgBAAIgBACIABACIACABQABAAAAAAQAAABABAAQAAAAABAAQAAAAABAAIADgBgAhgCHIABAAIAAAAIgCgDIgBAAIgBAAIAAABIABAAIAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQABAAAAAAIABAAIAAAAgAhbCGIABABIABgBIgBAAIgBAAgAhpCHIABAAIACgBQAAAAAAgBQABAAAAAAQAAAAAAAAQgBAAAAgBIAAgBIACAAIABAAIgBgBIgBABIAAAAIAAgBIABgBIgCgBIAAgBQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABIABADIgBAAIgBAAIAAABIABABQAAABAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIgBAAIAAABgAh1CFIABACIABAAQAAgBAAAAQABAAAAAAQAAgBgBAAQAAAAAAAAIgBgBIAAAAIgBABgAiPCFIABAAIAAAAIACgDQABgBgBAAQgBABAAAAQgBAAAAABQAAAAgBABQAAAAAAABgACJCEIACABIABAAIgBgCIgBAAIgDgBIAAAAQAAAAgBABQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAgBgABbB4IABAEQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABIABAEIABABQACgCABgEQAAgBABAAQAAAAAAAAQAAgBAAAAQgBAAAAAAIgCgFIABABQABAAAAAAQAAAAAAAAQABAAAAAAQAAgBAAAAIABgBIABgBIABAAIACgBIAAgBIAAgBIgBgDIgBgBIABgBIAAAAIABABIADAAIABgBIAAgDIAAgCQABAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIgDgBIgCAAIgFgBQgBgBAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAIAAAAIgBACIABACIABAAIABgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIACADQABAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIgBAEIgBABIgBAAIgBAAIAAAAIAAABIAAABIgDgCIgBgCIgDABIAAACIABgBIABAAIgBACQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABAAIABACIgBAAIgBAAgAhfCBIAAABIABABIAAgBIABgCgAhFCBIAAAAIABABIABAAIAAgCIgBAAgAhIB/IAAABQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAABAAIABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBAAIAAAAgAhWB+IAEACIAAAAIgEgCIAAAAgAhnB8IABABIACADIAAgCIgBgCIAAgBIgCgBgAhhB/IABAAIABAAIAAgBIgBgBQAAAAgBAAQAAAAAAABQAAAAAAAAQAAAAAAABgAhSB5IAAACQAAAAAAAAQAAABABAAQAAAAAAAAQAAABABAAIgBABIABAAQABAAABgBQAAAAAAAAQABgBAAAAQAAgBAAgBIgBgBIgHgCIgBAAIgBABQAAABAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIABAAIACAAgAhdB7QAAAAAAABQABAAAAAAQAAAAABAAQAAAAAAAAIACAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIAAgBIACABQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAgBgBAAIgCAAIgEgCIABAAIAEABQAAAAABABQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAAAIgDgCQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAIgBgCIgDABIAFACIgBADIgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAABQAAAAAAAAQAAABABAAQAAAAAAAAIABAAIgBABIAAABIABAAIADgBIgBgBQAAAAABAAQAAAAABAAQAAAAAAAAQABABAAAAgAg/B5QABAAAAAAQABAAAAAAQAAAAABAAQAAAAAAgBIACgGIAAgBIgBgCQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAABAAAAIgCAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAIAAABIABACIABAAIgCABIgBABIAAADIACgBIgBABIAAABIAAAAIABAAIgBABgAhJB2IABABIABABQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABAAIgCgCQABAAAAAAQAAAAAAAAQABAAAAgBQAAAAAAgBIABABIAAAAIABgBIgBgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQABAAAAAAIABAAIAAgEIgBgBQgCAAgDgCIgBAAIgCADIgBAEIgCAGIAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABAAIAAgBIABABgAhuBzIAAAAQAAABgBAAQAAAAAAABQAAAAABABQAAAAAAAAIABABIAAgBIAAgBIACgEQgBAAAAAAQgBAAAAABQAAAAAAAAQgBAAAAABgAhnBrIgDAJIgBABIABABIABgBIABgCIAAgDQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIACgEIAAgBgAhyByIgCAAIABACIABABQABAAAAAAQAAAAAAAAQABAAAAAAQAAgBAAAAIAAgBIgBgCgAhTBoIAAACIABAGIAAABIABAAIAAAAIAAgOQAAgBAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgDABIgBACIgBAJIABABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBQABgEAAgCIAAAAIABgBgAiGBwIgCABIAGgBIAAgBQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAgBAAAAIgFAAIgBAAIABABIABgBIACACgAh+BsIABABQABAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABIABABIABgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgDgBIAAAAIgBAAgABgBqQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAIgBABIAAAAIABAAIACAAIABgCIAAgEIgBAAQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAAAgAg/BrIABABIABACIACAAIAAgBIABgDIgDABIAAAAIgCAAgABuBkIAAACQAAAEAEABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCQAAAAABgBQAAAAAAAAQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAAAAAgBQAAAAAAAAQABAAAAAAIABAAIACABQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIAAgBIAAAAIgHgBIgCAAIgDAAgAg8BmIgCABIAAAAIAAABQABAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAAABIADAAIABgBIAAgDgAg4BoIABAAIABAAIgBgCgAh+BmIABACIABgBIgBgBgABrBjIAAAAIACABIABAAIAAgBIAAAAIgDgBgABpBjIABAAIgBgCIgBgFIAAgBIAAAAQAAgBAAABIgDAEQAAABAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAIAAAAIgCACIACABIAFAAIAAAAIAAgBgAhVBeIAAABIgBADQAAAAAAAAQAAABABAAQAAAAAAAAQAAAAABAAIABgBIABgBIAAgBIgBABIAAAAIgBAAQAAAAAAgBQgBAAAAAAQAAgBABAAQAAAAAAAAIACAAIgBgBIgBAAIgBAAgABvBeQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIABACQABABAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIgCgEgACBBSIgBABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAQADAGgDAGIgCADIADgBIACgBQAAAAABAAQAAAAAAgBQABAAAAAAQAAAAAAgBQACgEgBgEQgCgEgCgBIgBAAIAAAAgABuBhIgBABIAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIgBgBIAAABgAhzBiIABAAIABgBIABgBIgBAAIgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAIgBABIAAAAgAB5BdQAAABAAAAQAAABAAAAQAAAAAAAAQABABAAAAIACABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAgBABAAQAAAAAAAAQAAgBABAAQAAAAAAgBIABgGIgBgEQgBgBAAAAQgBgBAAAAQgBAAgBAAQAAAAgBABQAAAAgBAAQAAABAAAAQAAAAAAABQABAAAAAAIABACIgBABIgBAAIAAgDIgBAAIAAAAQgBABAAAAQAAABAAAAQgBABAAAAQAAABAAABIAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAgBQAAAAAAAAQAAAAABAAQAAgBAAAAQAAAAABAAgABsBfIgBABQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIABgCIgBgBIgBABgAg5BgQAAABAAAAIADAAIgBgEQAAAAgBAAQAAABgBAAQAAAAAAABQAAABAAAAgABrBTIgBABQgCAGABACIABAEIACgCQAAgBAAAAQAAAAAAgBQAAAAAAAAQgBgBAAAAIAAgBIABABIAAgCIgBgEIABgCIgBAAIAAAAgAg1BeQAAAAgBAAQAAAAAAAAQAAAAAAAAQABABAAAAIAAAAQABABAAAAQABAAAAAAQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAgABjBUQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQACACgCADIAAABIACAAQACgCABgEQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAIAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAIgCAAgAg7BdQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAIABAAIABgBIgBgBIAAgBgAhTBcIAAABIABACIACgBIABgBIAAgBIgCAAIgBAAIgBAAgABvBUIAAACIgBAEIAAACIABABQAAAAAAgBIACgIQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAgBAAIgBABgAh5BbIABABIACgCQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAABIABAAIAAABIgBAAgAiJBaIABACIABgBQAAgBAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAIgBABgACGBVIAAABIABAEIAAABIAAgGIgBAAgAhZBZQAAABgBAAQAAAAABABQAAAAAAAAQAAAAABAAIADAAIAAAAIAAgBIgCgBIgCgBgAg4BSIgBABIAAADIAAABIAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIgBgCIABgEIABgBIgBgBIAAAAgABcBTQAAAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIADABQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAgBIAAgBQAAAAABAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIgBgBIAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAIgBgBIgBgBIgBABgAh7BVIAAABIABgCIABABIABgBIgCAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAgAhhBVIABAAIACgBIgBgBIgBAAIgBACgAgGBKIgBAEIAAAFIAAABIABAAIABAAIACAAIABgBQAAgBAAAAQAAAAAAgBQAAAAAAAAQABAAAAAAIABgCQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgCIAAgBIgCgCQAAAAAAAAQABAAAAgBQAAAAAAgBQAAAAAAgBgAhfBRIgBABIABABIAAAAQABAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIgBgBIgBAAgAAfBJIgBACIAAABQACAEAEAAIABgBQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAIABgBIAAgFQABgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBgBIgEAIQAAAAAAAAQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgBgEIAAgBIAAgBgAiFBOQAAABAAAAQAAAAAAAAQAAABABAAQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBgBQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAAAAAgAh5A9IgBACIgCANIAAABIACABIAAgEIACgNIAAAAIgBAAgAAiBJIgBACIAAACIACAAIACgDQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIAAAAIgCAAIAAAAgAg6BIIABAAIAAACIACgBIACAAIAAgDQgBAAgBAAQAAAAgBABQAAAAgBAAQAAAAAAABIAAgCIgBgBIgDADIABABIAAAAIABgBIABgBIAAABgAAzBJQAAAAAAAAQAAABABAAQAAAAAAgBQAAAAAAAAQABgBAAAAQABgBAAAAQAAgBABAAQAAgBAAAAIAAgBQABABAAgBIABgCIAAgCIgCABIAAABIgDABIACgEIAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAgBAAIgJgIIgBgBIgDgFIAAAAIACAAIgBgBIgBgBIAAAAIAAgCIABAAIABgBIAAgBIgDgDIgBAAIAAACIgDAAIgGgBIgOgBQgBAAABAAIgBAAIAAABQAAABAAAAQAAABgBAAQAAAAAAAAQAAABgBAAIAAgCIAAgBIAAgBIgCAAIAAgCIgBABQAAAAAAABQAAAAAAAAQAAAAgBABQAAAAAAAAQgCACgDAAIgBAAQgBAAgBgBQAAAAAAAAQAAAAAAAAQgBABAAAAIAAAAQgFAAAAADIgCAGQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIACAAIgDAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAIAAgCIgBAAIgBAAIAAACIAAAAIgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAABAAAAIAAACIAAABIgBgBIABAAIgBgBIAAABIAAACIgBADIAAACIABAAIABgBIACgFIABAAIABgEIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAAAAAQABABAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAgBIABAAIgBABQgBAAAAABQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAAAIABgGIAAgBIgCgCQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAAAIABAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABgDIABgBIABAAIACgBIAFgBIAAAAIABABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAgBAAIgBABIgBAEQAAABAAAAQAAAAAAAAQAAAAAAAAQAAABABAAIABAAIgCABIAAACIABABIAAAAQAAAAABABQAAAAAAAAQAAAAAAAAQgBABAAAAIgBAAIgBABIABABIAAAAQAAAAgBABQAAAAAAAAQgBAAAAABQAAAAAAAAIABACIAAABIABAAIACgDIADgHIAAgBIgBgBQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAgBIACgEIAAAAIAAABIABAAQABAAAAABQAAAAABAAQAAABAAAAQAAABAAAAIABABIAAgCQABAAAAAAQAAgBAAAAQABAAAAAAQAAAAAAAAIADAAIACAAIAFAAIADAAIAAABIAAAAIgBAAIgDAAIABABQAAAAABABQAAABAAAAQAAABAAAAQAAABAAAAIgBACIAAACIACgDIABgBIAAABQAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAABIAAAAIABABIAAgBIACgEIABgBIAAABIgBADIgBADQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAgBIAAAAIAAgCIACAAIAAgBIAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAgBIABgBIAAAAIgBACIABABIABACIAAABIACgCIACgBIgCACIACgBIAAADIABgCIgBAIIABAAIAAgBIABABgAhZBJIABgBIgEgBgAgBBFQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAgCIgBABIAAAAIAAABgAg4BGIAEgCIgCgCQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAABAAAAIgBAAIAAgCIAAgBQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIAAABIACgBIABgBIgCAAIgCgBIAAgBIgBABIgCAFIgBABIAAACIABAAIACgCQAAAAAAABQABAAAAAAQAAAAAAABQgBAAAAABgAAYBEIACABIACgFQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABgBIAAAAIABgEIAAAAIAAgBIgDgBQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAABAAAAIgBAGIABgGIgBgBIgDAGIACgEIgBgBIgBAAIAAgBIABgBIgBgBQgBAAAAAAQAAAAAAABQgBAAAAAAQAAAAAAABIgBADQgBAFABABIgCACIAAABIABABIABgBIACgCIgBACIAAABIADAAIABAAQAAgBAAgBQAAAAAAgBQgBAAAAAAQAAgBAAAAIAAAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABAAIACgBIAAABIABABIAAABIgBgBQAAABAAAAQAAAAAAABQAAAAAAAAQAAABABAAIgBAAIAAABIAAABIAAAAgAAHBEQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIACgBIABgBIAAgDIAAAAIgCABIgCADIAAAAgAAqBDIAAABIABAAIABgCIAAAAIgCABgAh0BDIAAAAIACABIgBgCIAAAAIgBABgAgBBAIgBADQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIACgBIAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAAAAAAAIgBAAgAAPA4IgCACIgBACIAAABIgBAFQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIABgCIACgDIgDAGIABAAIABgBIACgHIgBABQACgDgCgCIgBAAIAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABgAgPBAIgCABIAAABQAAAAAAABQABAAAAAAQAAAAAAAAQAAgBABAAIABgCIgBgBIAAABgAhnA9IADABIABABIADACIAAABIAAgBIAAgFIACgDIACgBIgBgCIgBgBIgCABIAAABIgDgBIgBgBIAAgCIgBAAQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAAAIgBABIAAABQABABAAAAQAAAAAAAAQABAAAAAAQAAAAABAAIAAAAIACAAIABACQAAAAAAAAQAAABAAAAQAAAAgBAAQAAABAAAAIgBAAIABAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAABAAAAIAAACIgBABIgCgBIAAgDIgBgBIAAACQAAABgBgBIgDgBIAAACIAAABIAAgBIABAAIABAAgAhWA9QABABAAAAQAAAAAAABQAAAAAAABQAAAAAAAAIABABIABgBIABgCIgBgCIABgBQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAIAAgBIAAgBIgBAAIAAABIgDAGIABABIAAgBIADgBIgDABgAADA/IACACQAAgBAAgBQAAAAgBgBQAAAAgBgBQAAAAgBAAgAAeBAIACAAIABAAIAAgBQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBIgCADIAAABIgBAAIAAABgAguA9IAAAAIACACIABABIAJAAIAAAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAgBIAAAAIgDgEIgBgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAgBAAIgBAAgAgTA8IACADIABABIAAgCIgCgCIgBgBgAArAxIABACIACADIAKAHIAAABQABAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAIAAgBIgBgBIgNgLIgBgBgAgcA8IAAABIACAAIAAAAQABgCAEAAIABAAIgBgCIgCAAIgBgBIAAgBIgBgBIAAAAgAgCA8IACgCIABAAIAAgCIAAgCIABAAIgBgBIAAABIgBABIAAABQAAAAABAAQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQAAgBAAAAIgBgBgAhDA8IgCgCIABgBIgCAAIAAgBQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAgBAAAAIAAAAIgBABIgBgBIgBAAIgBgBIgBAAIAAACIABABIABABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAgBIACABIABABIADABgABnA3IgBABIAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAAAAAQAAAAAAgBIgBgDgAAEA4IABACIABgBIAAgEIAAAAIgDgBQAAgBgBAAQAAAAAAAAQgBAAAAAAQgBAAAAABIAAAAIABABQABAAAAAAQAAAAABAAQAAABAAAAQAAAAgBABIAAAAIAAABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIABgBgAgRAzIAAABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABABAAQAAAAAAAAQAAAAABgBQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAgBAAIgBgCIAAgBQABAAAAAAQAAAAAAAAQAAAAAAgBQAAAAgBAAIAAAAIgBABgAgVA0IgBABIgBABIABABQABAAAAABQAAAAAAAAQAAAAAAAAQABgBAAAAIABgBQAAAAABAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIgCgBIAAgBIAAAAIgBABgABRA2IABABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABgBIgBAAIgBAAIAAgBIAAAAIADAAIABABQAAABABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIAAAAQABgBAAAAQAAAAABAAQAAgBAAAAQAAAAAAgBIgBgBIgCAAIAAABIAAAAIgEAAIgBAAQAAAAgBAAQAAAAAAABQgBAAAAAAQAAAAAAABgAg+AmIgBADIAAACIADADQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgDADIAAABIACABQABABAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIACgCIAAgCIAAgBIgBgFIAAgBIABgBIADgBIAAgBIgBAAIgFgCgABgA0QAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIABAAQAAABABAAQAAAAABAAQAAAAAAAAQABAAAAgBIAAAAIgBAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIgCAAgAgOA0QAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAABAAIAAgBIgBgBgAgYAxQAAAAAAABQAAAAAAABQAAAAAAAAQAAABABAAIgBABIAEgDIAAgBIgCgBIgBAAgAgSAvIgCADQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIACABIABgBIgBgBQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIABAAQgBgBABAAIABAAIAAgEIAAAAIgBABIAAABIAAAAIgBgBQAAAAABAAQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAIgBABIACACIAAAAIABgBIACABgAgjAyIgBABIABAAIABABQAAAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIAAAAIgBAAgAg4AzIACABIADgBIABgBIgBgCIgEABIAAAAQgBAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAgAgQAwQAAAAAAABQAAAAABAAQAAABAAAAQAAAAABAAIACABQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIgBgBIABAAIgDgBgABUAxIgBABIABABIABgBIAAgBIgBAAgAAGAxIgBABIgBABIACAAIABgCIAAgBIgBgCIgDABIgBAAIgBAAQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIAAAAIACgCIgBgBQABAAAAABQAAAAAAAAQAAAAAAAAQAAABAAAAIABAAIABAAgAhAAyIAAABIABgCIgBAAIAAABgAgbAvIgBACIAAAAIACABIABAAIABgEIgBgBgAgNAuIAAABIABAAIACABQAAAAAAAAQABAAAAAAQAAAAAAAAQgBABAAAAIABAAQAAABAAgBIABgEIAAgBIgCAAIgBABIgBAAIgBgCIgCAAIAAACIACAAIABABIgBAAgAgeAtQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAgBAAIAAAAQABAAAAABQAAAAAAAAQAAAAAAAAQAAABgBAAQABAAAAAAQABgBAAAAQABAAAAgBQABAAAAgBIgBgBIgBgBIAAAAIgBABgABVAvIADAAIACAAIABABQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAgBAAIgBgDIgBgCIAAgBQgBAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIgBAAQAAAAgBABQAAAAAAAAQAAAAAAAAQAAAAgBAAIgCgDIAAAAIAAgCQAAgBgBAAQAAAAAAAAQAAAAAAAAQABgBAAAAIgBAAIgOgDIgCAAIgBgBQAAAAgBgBQAAAAAAAAQAAAAAAABQgBAAAAAAIAAACIABAFQAAAAAAAAQAAAAAAABQAAAAAAAAQAAABABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIACgBIACABIAAABIABAAIAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQABgBAAAAIAAABIAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIABAAIAAABIgBAAIADABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIABgBIACgCIAAACIACABIACAAIgBACIgBgBIgCAAQgBAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIgBAAQAAAAAAAAQgBABAAAAQAAAAABAAQAAABAAAAIADAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABACgAgiAvIAAAAIACgBIAAgBIAAAAIgDgBIgCACIABAAIABAAIABABgABgAtIAAABIAAAAIABgCQAAgBgBAAIgBAAIAAAAIgBAAIAAABQAAABAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQABABAAgBIAAgBgAA/ArIABABIACABQAAAAAAAAQAAgBABAAQAAAAAAAAQAAgBAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIAAgBIgCgBIgCgBQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAQAAAAAAABIACAAQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAAAIAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIgDAAIAGADIABgBIACAAgABwAqIABAAIgBgBIgBgBgAgcAlIgBAEIAAABIACgBIAAgCIAAgCIgBgBIAAABgAghApIABAAIAAgDIAAgBQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABIAAABIAAABIABgBIAAgCIABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIAAgBIAAABQAAAAgBABQAAAAAAAAQgBAAAAAAQAAAAgBAAIAAAAIgBAAIgCABIAAABQAAABAAAAQAAABAAAAQABAAAAAAQAAAAABAAgABbAkIAAACQgBAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIABAAIACgEQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAAAgBIgCgCIgDgBIADADQAAAAAAAAQABAAAAABQAAAAAAAAQABAAAAABIgBgBIgCABgAA5AoIABAAQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBIABgBIABAAIgBgBIgBAAIAAAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQAAAAAAABIACAAIgBgBIgDgDQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAABgBAAIAAABIAAABIgBAAIgCABQAAABgBAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIABgCIABAAIAAgBQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAABIgCAAIAAAAIAAgBIACgBIAAgCIAAgCQAAAAABAAQAAAAAAgBQAAAAgBAAQAAAAAAAAIgCABIgCABIABgCIAAAAIAEgDIAAAAIAAgBIAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAgBAAIgBAAIgDAAQAAgBgBAAQgBAAAAAAQgBAAAAAAQAAAAgBABIgDAAIgBABQAAAAgBAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAADIABAEIAAABIAAACIABACIgBABIgBAAIgCgBQAAABAAAAQAAABAAAAQABAAAAAAQABAAAAAAIACABIACADIABAAIAAgBQABAAgBAAIgCgDIACgBQAAACADACIABgBIADgFIABgBQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIABADQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIABAAIAAABQgBAAAAABIABAAQAAABAAAAQAAAAAAAAQABABAAAAQAAAAABAAIABgBIAAAAIABABgAhFAjQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIABABIABACIABAAQABAAAAAAQABAAAAgBQAAAAAAAAQABgBAAAAIgBgCIgEgBIgBAAgAAAAlIgBAAQAAABAAAAQABAAAAABQAAAAAAAAQAAAAABAAIADgBQgBAAAAgBQAAAAgBAAQAAgBgBAAQAAAAAAAAIgBABgABvAlIgBABIABABIABgBIAAAAIgBgBIAAgBgAAAAiIAAABIAEAAIgCgBIgBAAIAAAAIgBAAgAhUAZIgCABIAAABIADADIAAgDIAAgBIgBgBIAAAAgABmAcIABABIAAgBIAAgBgABaASIAAABIABABQABABAAAAQAAAAAAABQABAAAAABQAAABAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAIACAEQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAAAIgBgCIgCgEIADADIAAgDQAAgBgBAAQAAAAAAgBQgBAAAAAAQgBAAAAgBIAAACIgBgBIgBgBIAAAAgABJAWIAAABIAAABIAAADQAAABAAAAQAAAAABAAQAAABAAAAQAAgBAAAAIAFAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAgBgBIABgBIAAgBIAAgEIAAgBIgBAAQAAAAgBAAQAAAAAAABQAAAAAAAAQAAAAAAABgABPAaIABABIAAAAIABAAIAAAAIAAgCgAhdAZIACABIAAgBIAAgBIgDAAgAA5AJQgCADABAEIACADIAEADQADACAEgCIABgBIgBAAIgDgBIgBAAIgBAAIgCgBIABAAIAAgCIAAgCIABAAIgBgCQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAIgBAAIAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIgBgBgAgyAXIABgBIABAAIAAgBIgBAAIgBACgABOATIAAAAIABAAIAAgBIgCAAIABABgABFAOIAAABIgBAAIgBABIACAAQAAABAAAAQAAABAAAAQABAAAAAAQABABAAAAIABgBQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIgBgCIgDgCIACABIABgBIAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAAAgBAAIgGAAIADABQAAAAgBABQAAAAAAAAQAAAAAAAAQAAgBgBAAIgCAAIgBAAIACACIABAAIACgBIAAgBIABgBgAhNAKIgCABQAAABAAAAQAAAAAAAAQAAABAAAAQgBAAAAAAIAAABIAAACQAAgBABgBQAAAAABAAQAAgBAAAAQABAAAAAAIADACQAAgDgBgCIgBAAIgBAAgABHAJQAAAAAAAAQABAAAAAAQAAABAAAAQAAAAAAABIABABIABABIAAABIABABIAAgBIAAgDQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAIgBAAgAhJAOIABAAIAAgBIAAgBIgBgBQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAABABgABCALQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIADAAIABAAIAAgBIgBgCIgBgBQAAgBAAAAQAAAAAAgBQAAAAAAAAQgBAAAAAAIgBgBIgDAAIACABQAAABgBAAQAAABAAAAQAAAAAAAAQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQgBAAAAAAIgBAAQAAAAgBAAQgBAAAAAAQgBABAAAAQAAABgBAAIAAABIADADIABAAIADAAIAAAAIABAAgABRAKIABgBIACABIAAAAIgEgEIgDgBQAAAEAEABgAhOAIQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAIAAgBIgBgBgAg4AEQAAAAAAABQAAABAAAAQAAABABAAQAAABABAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIABgBIACAAIAAgBQAAAAgBAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAABgBAAIgCgBIgBAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAgAAxAAIAAAAIABAHIABABQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIABgCIAAgBQAAAAABAAQAAgBAAAAQAAAAABAAQAAAAAAAAIABABQAAAAABgBQAAAAAAAAQAAgBABAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBAAAAAAIgBgBIgBAAIgDAAIAAgBIAAgBIABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgBgBIgCgBIAAgBIABAAIABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIAFAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAFACQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIgBABIAFAAIgBgBIABgBIgBgDIgBgCIgBAAIgBABQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIgCAAIABAAIACgCIABAAIAAgDIgBgCIgCgBIAAACQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAAAAAABQgEABgDgCIgCAAIgCAAIgBAAIAAABQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAgBAAIAAABIgCABQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAgBIgBgCQAAgBAAAAQAAgBAAAAQAAAAAAAAQAAgBABAAIAAAAIgBAAIgCgBIAAAAIgBABIADAGQAAABAAAAQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQAAAAAAABIACADIgBAGIAAABIAEAAQABAAAAAAQABAAABABQAAAAAAAAQABAAAAAAIAAABIgBAAIAAgBIgBAAgAhFgBIAGAEIAEACIAAAAIABAAIAAgBIgDgBIABgBIACABIABABQAAgBAAAAQABAAAAAAQAAgBgBAAQAAAAAAAAIgBgCIAAAAIAAgBIgBABIAAAAIAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBAAAAAAIgFAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAgAhlgDIAAACIgBADIABABQAAABAAgBIABgBIABAAIAAgCIAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIAAAAQABgBAAAAQAAAAAAgBQAAAAgBAAQAAAAgBAAIAAAAgAgnACQABABAAAAQABAAAAAAQAAAAAAAAQABgBAAAAIAAgBQgBAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBAAIAAAAIgBACgAhUAAIADABQABABAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABgCIgBAAIgCgBQAAAAAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAIgCAAgAg7gNQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABABAAABQAAAAAAABQAAAAAAABIAEACIABAAIAAACIAAABIACABIABAAIAAAAIgBgBIACAAIgBgBQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBIABABIACABQAAAAAAABQABAAAAAAQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAABAAAAIAEACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABAAIABgBIABgFIACgCIACgBIAAgCQABAAAAgBQAAAAAAAAQAAAAAAAAQAAgBgBAAIABgBQAAAAAAABQAAAAABAAQAAAAAAgBQAAAAAAAAIgBgBIgBgBQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAAAABAAIACgCIACgCIACgGIgBgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQABgBAAAAIAAgBIAAAAIAAgBIgBgBIABgBIABgBIgBgBIgBABIgBADIgCACIAAAAIAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgBABIgEADIgBACIACAEIAAABIABAAIAAABQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIAAgBIABgBIABgCIAAgBIACgCIADgDIAAABIgBABIgGANIAAABIABAEIAAABIgBgBIgBAEIgEABIACgBIABgBIgBgBQAAAAAAgBIABAAQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAIAAgDIgBABIgBABIABgCQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAAAAAIgCgDIADACIgBgDIgBgEIgBgBIgCABQAAAEACABIgCABIgBABIgBgBIAAgBIABAAQABgDgBgCIgCACIABgEIABgCIABgFIAAgCQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIABgBQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIAAgBQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIABABIAAABIAAAAQAAAAgBgBQAAAAAAAAQAAAAAAABQAAAAAAAAIgBAEQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAABIABgBIAAgBIAAgCIAAAAQADgCAAgDIABgBQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAAAgBAAIgCgBIgBAAIAAAAIAAgBIABABIACAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIgBgHIgBAAIAAAAIAAABIgBACIAAADIgBAAIAAgBQABAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAIAAgBIAAgDIAAgBIgGgCIABAAIADAAIABABIABAAIAAgBIgBgCQAAgBgBAAQAAgBAAAAQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAgBAAAAIADABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIgBgBIAAgCIABgFIAAAAIgBgBIgBAAIgBABIAAgBIAAgBIgBABIgBACIgCACIgCACQAAABgBAAQAAAAAAABQAAAAAAABQAAAAAAABIABADIgEAAIgBABQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIABgBIABABIABgBIgBgDIgCACIgBACIAAACIABAAIABABIgBAEQAAABAAAAQABABAAAAQAAAAABABQABAAAAAAIADAAQgBABAAAAQAAAAgBAAQAAABgBAAQAAAAgBAAIAAACIAAABIgBgBIgBgCQgBgEgCgBIgBAAIAAgCIAAgCIACAAIgBAAQAAgBAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgCAAIgBAAIAAABIAAABIgBACQgBAAAAABQAAAAgBAAQAAABAAABQAAAAABABIAAACQAAABAAABQAAAAAAABQAAAAABABQAAAAAAAAIABACIAAABIABAAIAAACIgBABIAAABIgBARIABABIABgCIAAABIABABIAAACIAAgCQAAgBABABIACAAIAAAGIAAgEQAAAAABAAQAAgBAAAAQAAAAABAAQAAAAAAAAIABABIgBAGIAAAAIgBAAIgCgBgAhVgEIABABIABAAIAAgDIAAAAIAAAAgAhYgXIgBAFIgCAFIgCAGIgBACIAHACIABAAIAAgBIgBAAIgCgBQgCgCABgDQAAAAABgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABABQABAAAAAAQABABAAAAQAAABAAABIABABIABgCIAAgBQAAAAAAAAQABAAAAgBQAAAAAAAAQgBAAAAgBIABgBIABAAIAAgBQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAABAAAAIgCABIgBgBQgDAAgBgEQAAgDADgBIABAAIgDgBIgBgBQAAAAgBABQAAAAAAAAQAAAAAAAAQAAAAAAABgAA2gEIABgBIABgCIgCABIgCABIAAAAIAAABIAAAAIABgBIABABgABAgOQAAABABAAQAAABAAAAQAAAAAAABQAAAAAAAAIAAACQAAABAAABQABAAAAABQAAAAABAAQAAABABAAIAAAAIABAAIABgBIAAgBIgCgBQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAgBIgBgCIABAAIABgBIABgCIgGACgAhcgZIgBACQgBAAAAAAQgBABAAAAQAAAAAAABQAAAAAAABIgBAEIgBABQAAAAAAAAQgBABAAAAQAAAAABAAQAAABABAAIgBABIAAACIAAACIgBABIABABIABAAIACgGIgBgCIgBgBIABgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAgBAAIAAgBIABgBQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAIgBgBIABAAQAAAAABAAQAAAAAAgBQABAAAAAAQAAAAAAgBIACgDIgBAAIgCABgAhEgPIgBABIACACIABgBIAAgBQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAgBAAgAA+gTIAAABIABACIABABIAHgCIABgBIgDAAIgDABIAAgBIABgCgAhJgZIABAAIAEADIABADIAAABIAAABIAAAAIAAAAIABgCIgBgDIAAgBIgEgDIgBAAgAhLgSIABAAIACABIAAAAIABAAIAAgBIgDgBgAhLgVIAAABIABABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAgBIgCgBgAhIggIgBABIAAACIAAABIABAAIACABIABAAIAAgBIgBgBIAAAAIgCgBIAAgBIABgCIAAgBIABAAIABAAQAAAAAAgBQgBgBAAAAQgBAAAAgBQgBAAgBAAIgBAAIAAABIABABQAAAAABAAQAAAAAAABQAAAAAAAAQAAAAAAABIgBgBIgBABIABABIABAAIAAAAgAgogfIgBACIACABIACgBIABgDIAEAAIgCgBIABAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAIgDgBIgBAAQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAgAAogiIABAFIABAAIgBgDIACgBIADgDQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgDABIAAADIgCgBgAhOggIAAABIACAAIABgBIgCgBgABBghIABAAIABgBIAAAAIgBgBIgBACgAhFgiIACABIAAgBIgBgCQgBgDgEgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBgBAAIgBADIAAABQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAAAAAIgCACIABABQAAAAABAAQAAAAABgBQAAAAAAAAQAAAAAAgBIABAAIAAAAIAAACIABgBQgBgDADABQADABACACIAAABIgBAAgABTgrIgBABIgBAAIAAABQAAABAAAAQABABAAAAQAAAAABABQABAAAAAAIACgBIAAgCIgCgCIAAAAIgBAAgAhDgnIABAAIABgBIgBgBIgCgBgAgdgrIgBABQAAABAAAAQAAAAABABQAAAAAAAAQAAAAABAAIABgBIgBgCIgBAAgAArg3IgCABIAAACIAAAAIADgBIAAAAIAAgBIABABIgCgCgAgRg/IAAACIABAAQAAAAAAABQAAAAAAAAQABAAAAAAQAAgBAAAAQAAAAgBAAIAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAAAAAgAg8g+IAAABIACAAIABAAIgBgBIgBgBgAAbhCIgBABQAAABAAAAQAAAAAAAAQAAAAAAAAQABABAAAAIAAABQABAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIABgBIAAgEIgBgBIgCACIABgCIABgBIgBAAIgCAAIAAABIgBACIgBAAIgBACIAAACIgBABIABAAgAgQhBIACACIAAgBIAAAAQgBAAAAAAQAAgBAAAAQgBAAAAAAQAAgBAAAAQAAAAgBAAQAAAAAAAAQAAABAAAAQAAAAABAAgAAXhKIgCAAIAAAGIACABQAAAAAAABQAAAAABAAQAAAAAAgBQAAAAAAAAIAAgBIABgBIgBgBIAAgEIAAgBIgBAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAgAAmhEIABAAIgBgCQAAABAAAAQgBAAAAAAQAAABAAAAQAAAAABAAgAAphOIAAACIABgBQAAAAABAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBABIgBgBIAAABgAAIhfQAAAAAAAAQgBAAAAAAQAAABAAAAQABAAAAAAIABABIAAgCIAAAAgAA8hkIABABIADAAIgDgCgAA1hlIACABQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIACAAIABgBIgBAAIgCAAIgDgBIgBABgAAghnIABABIACAAIABAAIgBgBIgCgBgAAchtIACACQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAgBQAAAAAAgBQAAgBAAAAQgBAAAAgBQgBAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAAAQAAABAAAAgAgwhwQgBAAAAABQAAAAAAAAQAAAAABAAQAAAAAAAAIACAAIgCABIADABIACABIABAAIgBgBIABgBIAAgBIgFgBIAAAAIgBAAgAg4hwIABADQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAQgBAAAAgBQAAAAAAgBQgBAAAAAAQAAAAgBAAIgCgBgAgDhxIACABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAgBAAAAIgBgCIgBABIAAAAIgBAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAgAg4h0IABACIAAAAIAFACIAAAAIAAgBIAAgBQABAAAAABQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAgBQgCgBgDAAIgCAAgAgDh4QAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIABACIgBABIACAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIABgBIAAgBIAAgBIAAABIAAAAIgBgBIAAgBIgBgBIgDgCIADgBIAAgCIgCgBIgCgEQgBgEgEABIgBAAIgCgBIAEAAIAAAAIAAgBIgBAAQgBABAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAIAAAAIgBAAIABACIgCABQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgCAAIAAABIABABQAAAAABABQAAAAAAAAQAAAAAAAAQABAAAAAAIAAAAIADABIgBgDIAAgBIABAAIABACIAAACIAAACIACAEIABABIACgBIAAACIAAAAIAFACgAgGhzIADAAIAAgBIgBgBIAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCAAIABABgAguh2IABABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIACgDIgBgCIgBgBIgFgDQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIgBABIgBACIgBACIAFAEIABAAIAAgCgAgLh6IABACQABAAAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAgBAAgAASh5IACgBIgCAAIAAABgAgBh8QAAABAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABgBIgBgBIABgBIAAAAIABgBIAAgBQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgCIAAgBIAAgBQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAAAAAIAAAFIABABQAAABgBgBIAAABgAgEiEIgBABIABABIABABIABgBIAAgBIgCgBIAAAAgAApiDIACABQAAAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAIAAgBIgBgBIACAAIACgBIAAgBQAAgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIABAAIACgBQAAAAAAgBQABAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAAAAAAAIgFABIgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAABAAAAIAAABIgCAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAABAAIAAgBIgBAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAgBgBIgBAAIAAABIACACQAAABAAAAQAAAAAAAAQAAABABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAABIACABQABAAAAAAQAAAAAAAAQABAAAAAAQAAABAAAAIgBgBQAAAAAAAAQAAAAgBABQAAAAAAAAQAAAAAAABgAgEiGIABABIABgBIgBgBQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAAAgAABiMIAAgCIAAgCIgBgBIABAFgAgDiOIABAAIABAAIAAgBQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAAAgBAAgAgUiQIABABIABAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAAAAAAAgAAwiWIgBACIAAABIABAAIACgBIAAgBIAAgBIgCgBgAgmiZIABABIAAABIAAAAQABAAAAAAQAAgBAAAAQAAgBAAAAQAAAAgBgBIAAAAgAgpibIABABIABAAIAAgBIgBAAIAAgBgAhcCLIAAAAgAAEBIgAg4BDIAAAAgAAZA9IAAAAgAh9A2gAhoAMgAAHiSIAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAIgBACIgBgCg");
	this.shape_127.setTransform(231.0607,25.5832,0.662,0.662);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("ABiCiIgGABIgUgBIgCgBIACAAIABgCIAAAAIgBAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgBQAAgBABAAQAAAAgBAAQAAgBAAAAQAAAAgBAAIAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAgBgBIAAgCIgBgBQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAgDIgBgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIABADIAAAEIABABIABABIgBACIACAGIgJgfIABABIACADIAAACQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIAAABQAAABAAAAQAAAAABAAQAAABAAAAQAAAAABAAIABAAIAAgBIgCgHIgBgBIgBgBIABgBIABAAIAEAKIABABIABAAIACABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAIgBACIABACIACAAQAAAAABAAQAAAAAAABQAAAAAAAAQgBAAAAAAIABACIACACIAAAAIAAABIABABQAAABAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIABAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIgBgBIAAAAIgBAAIAAgCIABAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIAAgCIAAgBQAAgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIADACIABACIAAABIABAAIABgDQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAIgBAAIAAAAIAAABIAAAAIgBAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAIAAABIgBAAIAAAAIAAgBIgBgBIAAgBIAAAAIABAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQgBAAgBAAIACgBIAAgBIgBAAIgBABIgBAAQAAAAgBgBQAAAAgBAAQAAAAAAABQgBAAAAAAQgBAAAAABQAAAAgBAAQAAAAAAgBQgBAAAAAAIAAgBQADgFAAgGQABgEgEgDQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAgBAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIgEgFIAAAAIAAgBIAAgBIgDgDIgDgCIABABIgDgDIAAgCIgBAAIgBgBIABgBIABABQAAAAAAAAQAAABAAAAQAAAAABAAQAAABAAAAIAFAEQAAABABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIACABIACABIAAAAQAAAAAAABQABAAAAAAQAAAAAAAAQABAAAAAAIgBABIgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIAAAAIgBgBIAAAAIAAABIACADIADADIACACIABAAIAAABIABABIACAEIABAEIABADIABAAQABADADACIADABIABAAIABAAQABAAAAAAQAAABAAAAQABAAAAAAQAAAAABAAIgBgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAABAAQAAgBAAAAQABAAAAAAIABAAIABAAIgBgBIgBgCIAAgBIgBgBIADADIAAgFIgDgEIgBACIgDgCIAAgBIABAAIAAABIACAAIABgBIAAgBIAAgBQAAgBAAAAQAAAAgBAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgBIABgBIgFgEQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAABIgBABIABgCIAAgBQAAgBAAAAQgBAAAAAAQAAgBgBAAQAAAAAAAAIgCgCIgBACIgCAFIgBAAIAAAAIAAgBIAAAAIABgCIAAgBIACgDIgBgCQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgBIgDgEIgDgDIgDgBIgBAAIgCgCIADABIABgBIgCgBIgBgBIAAgCIAEABIABgBQAAAAAAAAQABAAAAAAQAAAAAAAAQAAgBgBAAIABgBIgDACIADgEQAAAAAAABQAAAAAAAAQAAAAAAAAQAAABABAAIAAAAIgBABQABAAAAABQAAAAAAAAQAAAAAAAAQABgBAAAAIABgBIAAgEIAAACIAAACQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAgBABAAQAAgBAAAAIABgBQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAABAAIAAgEIgBABIAAgBIABgBIgBgCIgBgBIADAAIABgEQABAAgBABIAAADIAAABIABADQABAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIABADIgBgBIgBgBIgBAAIAAABIgBAAIgCADIACAAIAAgCIABABIAAABQABAAAAABQABAAAAAAQAAAAABAAQAAgBAAAAIABgCIAAgBIABAAIAAACIAAABIADAAIADgBQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAAAgBIADgIIABgBIAAgBIgBAAIgBAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAgBQgDgCgBgFIAAgBIgCABIgBABIACgDIAAgCQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIgCABIAAgBIgDgBIAAABIAAACIABACQAAABgBAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIgBAAIgBAAIAAgBIABgBIgBABIgBABIAAgBIgBAAQAAAAAAAAQAAAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQgBAAAAAAQAAgBAAAAIABgCIgCAAIABgBIABgBIABAAIgBgBIgDAAQAAgBAAABIAAACIAAABQABAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAIgBAAIgBgCIABgCIAAAAIgBgBIgDAAIgBABQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgBIgBgBIABgBIAGAAIAHADIACgBIAAgEIgCgBIgFgCQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgBABQAAAAAAABQAAAAgBAAQAAAAAAgBQAAAAAAAAIAAgBIgBABQAAABAAAAQAAAAAAAAQAAABAAAAQAAgBgBAAIgBABQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAgBAAAAIgBAAIgEAAIAAAAIgDgCIgBgBIgFgEQAAgBAAAAQgBAAAAAAQAAgBgBAAQAAABAAAAIgCAAIACABIABACQAAABAAAAQAAABABAAQAAABAAAAQAAAAABABIAEADIACABIABgBIABAAIAAABIAAABIAFADIACACQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBABIgDACIAAABIgDACIAAABIgBADIAAAEIgBACIAAAJIgBgCIAAgFQAAgBAAgBQAAAAAAAAQgBgBAAAAQgBAAgBABIgBAAIgBgBQgBAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQgCADABADQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgEIABAAIAAABIgDAFIgBAAIgBABIAAgCIAAgEIAAgCIAAgCIgBgBIAAgBIgBAAQAAgBgBAAQAAAAAAgBQgBAAAAAAQgBAAAAABIgBABIAAABQAAAAgBABQAAAAAAAAQAAABAAAAQAAABAAABIAAACIAAABIABgBIACgDIgBADIABACIABABQAAABABAAQAAAAAAABQAAAAAAAAQgBABAAAAIgDABIADAAIAEABQABAAAAAAQAAAAAAAAQABAAAAABQAAAAAAAAIAAACIgBgCQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAIgGAAIgKAAIgCAAIgNAAIABgBIgLAAIACAAIgEAAIgDABIgDgBQACgBAEABIgBgBIgEAAIgBAAIABgBIAYAAIgYgBIADgBIADAAIgEAAIgBgBIABAAIADAAIADgDIAAAAIgCgCIgBgBIgCgCIgBgCIgBACIACAAIAAACQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAIAAgCIgBAEIABACIgBADIAAAAIAAACIgBACIAAABIgJAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgCIAAgGIAAgBIgBAAQAAABgBAAQAAAAAAAAQAAABgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAABQABABAAABQAAAAAAAAQAAABgBAAQAAAAgBAAIgBACIgBAAIgcAAIgCgCIgEgEIABgCIAAgBIgDAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAIgBgBQAAAAABAAQAAAAAAAAQAAgBAAAAQgBAAAAAAIgCABQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAgBAAAAIAAAAIgBgBIAAABIgBACIAAgCIgBABIgFAMIAAAAIAAABIgDAIIgBADQAAAAAAAAQAAAAgBABQAAAAAAAAQAAABAAAAIABACIACAAIACgBIAAgBIAAgDIABAAIABABIgBABIABAAIABgBQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBABAAAAIABACQABAAAAAAQAAAAAAgBQABAAAAAAQgBAAAAgBIAAAAIACAAIAAgBIABAAIABAAIADAAIABgBIAAgCIAAgBIgCABIgBABIAAABQAAAAAAABQAAAAgBAAQAAAAAAAAQAAgBgBAAIAAAAIgBgBIABAAIABAAIAAAAIAAgCQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAIAAABIAAgCIgCAAQAAgBAAAAQAAAAABAAQAAgBAAAAQAAAAABAAIABgBIgCgCIACgDQAAAAAAABQABAAAAAAQAAABABAAQAAAAABABIAAgCIAAAAIgBgBIgCgBIAAgCIABAAIAAABIAAABIACgCIABABIAAgDIACgEIgEAAIAAgCIACgBIAAABIAAAAIAAABIABAAIADAAQAAAAABAAQAAAAAAAAQAAABAAAAQAAAAAAABIACgBIgBABQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAAAIgBACIABABIgBABQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAAAIABABIABAAIgCABIgBACIAAACIAEgBIACACIgBACIAAAAIgBACQABAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAIgBACQAAAAABAAQAAABgBAAQAAAAAAABQAAAAgBAAIgBABIABABIAAABQAAAAAAABQgBAAAAABQAAAAAAAAQgBAAAAAAIgBACIgDAKIABACIAAABIgCACIgBgBIAAgBIgDAAIgCAAIABABIAAABIABgBQAAAAAAAAQAAgBAAAAQABAAAAAAQAAAAAAABIAAABIgBABIABABIABABIABAAIABACIgBAFIABAAIgCACQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAIABAAIAAgBIgDAAIAAAAQAAAAgBAAQAAgBAAAAQAAAAAAgBQABAAAAAAIgDAAIgBgBIABgCIABABIgBACIADgBIADAAIAAAAIAAABIABgBQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIgBAAIAAgCIgDAAIgBAAIgDgBQAAAAAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAIgCABIACAGIAAACIAAAAIgBABIAAAAIAAABIgCAEIAAABIAAAAIACgCIADgBIACABIgBABIgDACQgBAAAAAAQAAAAAAABQgBAAAAAAQABABAAAAIAAACIgBgCIgBgBQAAAAAAAAQAAgBAAAAQgBAAAAABQAAAAAAAAIgBABIABACQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIgCABIgBAAIgBgDIgBgBIgBAAQgBAAAAAAQgBAAAAAAQgBgBABAAQAAgBAAAAIAAgBIgCgCIAAAAQABAAAAAAQAAAAABAAQAAAAAAgBQABAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAIAAAAIAAgBIADACIABAAIgBgBIgBgBIgBgDIgBgBIAAABIAAACIAAABIgCgDIABAAIgBgCIAAAAIgBAAIABACQAAAAAAABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgBAAIgBAAIAAAAIAAACIgCACQgDgBgCADIgCACIgEAAIACgBIABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAgBAAAAIAAgCIgBgBIAAABQAAAAAAAAQAAABgBAAQAAAAAAAAQAAABgBAAIgBAAIgBAAQAAABgBAAQAAAAAAAAQAAAAgBAAQAAAAgBAAIgBAAIABgCIABgBIAAgBIABgBQABAAAAgBQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAAAABQgBAAAAgBQAAAAgBgBQAAAAAAAAQgBAAAAAAQAAAAgBABIAAABIAAABIgBABIACAAIAAABIAAACIgBAAIgCgCIgCgBIgCgCIgBgDIgBABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABIAAAAQAAABABAAQAAAAAAAAQAAAAgBAAQAAAAAAAAIgBAAIgBgCIgBgBIgDADIgBABIgBAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAABIAAAAIgBgBIgCgBIABABIACAFIAAABIACgBIABgCIgBADIgCAEIAAgCIAAAAIgBAAIAAAAIgCABQgBAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAABIABAAIAFABIADgBIABgCIABgBIABABQAAAAAAABQABAAAAABQABAAAAAAQABAAABAAQAAAAABAAQAAAAABAAQAAgBAAAAQAAAAAAgBIgBABIgBAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAIAAgDQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAgBgBIgBgBIgBABIACgDIAAgBIAAAAIgCABIACgCIABAAIAAABIAAACQAAABAAgBQABAAAAAAQABAAAAAAQABgBAAAAQABAAAAgBQAAAAABgBQAAAAAAAAQABAAAAAAQABAAAAABIAAAAIAAABQAAAAgBgBQAAAAAAAAQgBAAAAAAQAAABgBAAIAAABIABAAIADABIADAAIACAAIABABIgCABIgBAAIABABQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAIAAAAQAAABABAAQAAAAAAAAQAAAAAAAAQABAAAAgBIAAAAIAAgBIABAAIAAADIAAABIgEAAIADABIABAAIAAABIgCABIABAAIAAABIgUgBIgBgBIgBAAIgBABIgCABIgBAAIgIABIgJAAQgFAAgEgCQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAABAAAAIABgFIABABIAFABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIABgDQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgHgEQgBAAAAAAQAAAAgBAAQAAAAAAgBQAAAAgBgBIABgBIABAAIAHgBIAMAAIABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgDAAQAAAAAAABQAAAAAAAAQgBAAAAgBQAAAAgBAAIAAgCIABAAIgBgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBABAAIABgCIgDACQAAAAgBAAQAAAAAAAAQAAAAAAAAQABgBAAAAIAAgCQAAgBABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABABIABgBIgCgBQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABAAIgBgBIAAgBIABgCQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIACgBIAAgBIgBgBIgBABIAAAAIAAAAIgBgCIABgBIACgBIABAAIABAAIgBAAIgCgBIAAgEIgCAAQAAAAAAAAQAAAAgBgBQAAAAAAAAQAAAAAAgBQAAAAAAgBQAAgBABAAQAAgBAAAAQAAAAABgBIAAgBIACAAIASAGIACAAIgBgBIgDgBIAAAAIgJgEIgDAAIgEgCIgBAAIgBAAIAAgBIABgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQABAAAAgBQAAAAAAAAQAAAAAAAAQAAgBgBAAIAAgBIAFgMIAAgBIACgEQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIABAAQAAAAAAgBQgBAAAAAAQAAAAAAgBQAAAAAAAAIABgCIACgBIACAAQABAAgBABIABAAIABAAIgBgBIgDgCIgBAAIAAgCQABAAAAgBQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIgCgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAABgBIAAgBIACAAIABAAIAAAAIgBgBQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIACgFIABAAIAAAAIAAgBIACAAIAAABIABABQAAAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABIgBACIABABIABgBIACgGQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQAAAAgBABIgBAAIACABQABAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABIgBABIgBAAIgBgBIgBAAIgBABIAAgCQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAABAAIAAgBIgBAAIADgIIACgBIABAAIACgBIABgBIABAAIACAAIAJADIADACQABAAAAAAQAAAAAAAAQABAAAAgBQAAAAAAAAQAAAAAAABQAAAAABAAQAAAAAAABQAAAAABAAIAAAAIACABIABgBQAAAAABABQAAAAAAAAQAAAAABABQAAAAABAAIADABQgBgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIABgCIgBgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABAAIACAAIABgBIAAAAIABABIAAAAQAAAAAAABQABAAAAAAQAAAAAAABQAAAAAAAAIgBAEQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAgBAAIALAEQAAAAABABQAAAAAAAAQAAAAAAAAQAAgBAAAAIABgBQAAAAAAAAQABgBAAAAQAAAAAAAAQABABAAAAIABACQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIAFACQAAAAAAAAQABAAAAAAQAAAAAAABQgBAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAABAAIAFACQABAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAgBIgBgCQAAgBgBAAQAAAAAAAAQgBAAAAAAQAAAAAAABIgBABIgDAAIgCgCIgBgBQgCgFgFgFIgBAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAABABQAAABgBAAQAAAAAAABQgBAAAAAAIgCABQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBgBIAAgBQABAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIAAgBIABgBQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAgBQABAAAAAAQAAgBAAAAQAAAAAAgBQAAAAgBAAIAAgBIgCAAIAAgBIgEAAIgDgBQgBAAAAAAQAAAAgBAAQAAAAgBABQAAAAAAAAIgBABQAAAAAAAAQAAAAgBgBQAAAAAAAAQAAAAAAgBQAAgBAAABIgCAAIgBABIgCgBIgEABIgDACIgBAAIAAgBIAAgBIgCgCQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAABAAIABgBIABAAIAEgCIABgBIABgBIABAAQADABADgBIgFAAIADgBIAAAAIABgBIgDAAIgDgBIADABIABgBIgBgBIgCgCIgBAAIgDAAIAFACIgCAAIgBAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABIAAAAIgCgCQABAAgBAAIgCgCIgBgBIACAAQAAAAABABQAAAAAAAAQAAAAAAAAQABgBAAAAIAAAAQAAAAABABQAAAAAAAAQAAAAAAAAQABgBAAAAIAAABIAAAAIABABIABgBIAAAAIADABIACAAQAAABABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIADgEQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIAAAAIABgDIABgCQAAAAAAgBQAAAAABAAQAAAAAAAAQAAAAABAAIAAgBIACgCIAAgGQAAAAAAgBQABAAAAAAQAAgBABAAQAAgBAAAAIACgCIABgCIABgCIAAAAIgBAAIAAAAQAAAAgBABQAAAAAAgBQAAAAAAAAQAAAAAAgBIABgEIACgBIABAAIABABQAAABAAAAQAAABABAAQAAAAAAAAQAAABABAAIAAAAQAAAAABAAQAAAAAAABQABAAAAAAQABAAABAAIADgBIgDgCQgDgBgFgEIgBAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIgCAAIgBAAIAAABQAAABAAAAQAAABAAAAQAAAAAAAAQABABAAAAIACABIgEAAIgDAHIABABIACABQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAgBIAAAAIABgBIAAAAQABAAAAABQAAAAAAAAQAAAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAAAgBAAIAAABIAAABIAAAAIgFgCQAAAAAAgBQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAAABQAFACABAFQgCgEgCAAIABACIABACIAAABIgDAEIABgCIgBgBIAAAAQgBAAAAgBQAAAAgBgBQAAAAAAAAQgBAAAAAAIAAgBIAAAAIgBgBIgDAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQABAAAAgBIABgBIgCABIgBACIgBAAIAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgEACIgCADQgCAEACAEIgCAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBgBQgBAAAAAAQAAgBAAAAQAAAAAAAAQAAAAABAAIABgDIAAgCIABgDIAAAAIAAgBQABAAAAgBQAAAAABAAQAAAAAAgBQAAAAAAgBIgCABIgBABIgFANIAAACIgBACIAAACIgBABIABACQAAAAAAABQABAAAAAAQAAAAABAAQAAAAAAAAIgBACIgBABIAAAAIAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIgBgCIgBADIAAAAQgBABAAAAQAAABgBAAQAAAAgBAAQAAAAgBAAIgBAAQAAAAAAAAQAAAAgBgBQAAAAAAAAQAAAAAAgBIACgGQABAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIAAgBIABgCIACgIIAAAAIACgFIAAgBIACgGIAAAAIABgCIABgCIAAAAIACgCIAHgXIAAgBQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIAEABIABABQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIAFACQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAIgBgKIABgEIACgCIAEgCIADgBIADgCIADgCIABgCQABAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAIgFABIgCAAIgBAAIgCAAIACgBIAHgBIADgCIABgDIgBgBQAAAAgBABQAAAAAAAAQAAAAAAgBQAAAAAAAAIABgBIABAAIABAAIAAgCIgBgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABAAIAAgBIAAgCIABgBIAEgCIAAgBQAAgBAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQABgBAAAAQABgBAAAAIAAgBIgBAAIAAAAIACgBQAAgBABAAIACABQAAgBABAAQABAAAAABQABAAAAAAQAAABABABIAAAAIABgBQAAAAAAAAQAAgBAAAAQABAAAAAAQAAAAAAAAIABAAIABABIAAABQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAABAAIAFgCIAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAIgCAAIgBAAIABgBIAEAAIAAAAIABAAIAAgBIgDgBIgFgBIgBAAIgDgCIAAAAQAAAAAAAAQABAAAAAAQAAgBABAAQAAAAAAgBIACABIACAAIABACIADACIAAgBIACgBIABAAQABgBgBAAIgBgBIABgDQABAAAAgBQAAAAAAgBQAAAAAAAAQgBgBAAAAIgDgBQABAAAAAAQAAAAABAAQAAAAABAAQAAABABAAIAAABQABABAAAAQAAAAABAAQAAAAAAAAQABAAAAgBIACgCIgEAJIAEAAIAAAAIgBACIgEACQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAABIAAAGIAAABIgBgCIAAAAIAAAAIAAADIABAAIAAABQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIAAABIABABIACgBIABgDIAAgGIABgBQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBgBAAIgCAAIAEgCIACACIAEABIgBAAIgCgBIgBABIAAABIgCgBIgBABIABAAIAEACIABgBIABADIgEgCIgBAAIgCAAIAAABIAAACIgBAFIABABIgCAAIgBACIAAgBIAAgBIgBABIAAAAIACADIABADIgBACQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAABABIAAAAIABABIAAACIAAABIgBgBQgBADACACIgBABIABABIACAAIAAAAQAAAAAAAAQABAAAAABQAAAAAAAAQABAAAAABIAAAAIAAACQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAIABgCIAAgBIABAAIAAgCIAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIACgEIAAgDIACgDIgBgCIAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgCgDQgCgEgBgBIgBgCIABgBIACACIAAACQAAABAAAAQABABAAAAQAAABABAAQAAAAABABIABAAQAAAAgBgBQAAAAAAAAQAAgBABAAQAAgBAAAAIADgCQABAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIAAgBIABABQAAABAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIgBgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAIgBAAIABgCQAAAAAAABQABAAAAAAQAAAAABAAQAAgBAAAAIABgBQAAAAAAgBQABAAAAAAQAAgBABAAQAAABAAAAIAEABIAAACQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAAADIgEALIAAACIABAAIAAgBIABgBIABABIAAABIABgBQAAAEgDAHIABgGIAAgBIgCgBIgBAAIgBADIgCAEIABACIABABIgBAAIgBgBIAAABIgCAGIAAABIgCAFQAAAAgBABQAAAAAAAAQAAAAABABQAAAAAAAAIAAABIAAAAIgBABIgEANIgBADIABAEQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABIgCACIAAACIABAAIgCABIgCALIAAAEIABABQAAAAAAAAQABAAAAAAQAAAAAAABQgBAAAAAAIAAABQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQABADgCACQABAAAAABIgBABIgBgBIAAgBIgBgBIgCACIgBABIgDgBIgCAAIAAgBIAAAAIADABIABAAIAAgCIABgBQABAAAAAAQAAAAABAAQAAAAAAAAQABgBAAAAIACgEIAAgBIAAgBQAAAAABgBQAAAAAAAAQAAgBAAAAQAAAAgBgBIgBgBIACAAQAAAAAAAAQABAAAAAAQAAgBAAAAQAAAAgBAAIAAgCIABgFIgBAAIgBAEIAAACIgBAAIgBAAIgBgBQABAAAAAAQAAgBAAAAQAAAAAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAABAAAAQAAAAAAABIgBABQgBAAAAAAQAAABAAAAQgBAAAAABQABAAAAAAIgCAGIAAgEIgBAAQAAAAAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAIgEgBIgBABIAAAAQAAAAABABQAAAAAAAAQAAABAAAAQAAAAAAABIAAABIgCAEIAAABIABADIACgEIADgDIgBABIAAACIAAAAIgBABIgDAEIgCAFIgCAFIAAABQAAAAABAAQAAAAAAgBQAAAAABAAQAAABAAAAIAEgCIACABIAAgBQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIABAAQAAgBAAAAQAAAAABAAQAAAAAAAAQABAAAAAAIAAgBIADgDIABgBIgCgBQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIABAAIgBgBIAAgBIABABIABAAIABgCIABAAIABABIgBABIAAACQAAAAAAABQABAAAAAAQAAABAAAAQABAAAAAAIABAAIABgBIABABIABgCIAAACQAAABABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAEgCAEACIABABIACAAIABgBQAEgDADADIAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAAAAABgBIgBAAIAEgBIAFAAIABABIgDAAIABABIABAAIADAAIACACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIAQgBIADgBIAAAAQAAAAABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIAAgBIAAAAIABAAIAAgBIAAgCIgHgXIAAgBIABgBIABAAQAAgBABAAQAAAAAAgBQAAAAABAAQAAAAABAAIAIgBQAAAAABAAQAAAAAAgBQABAAAAAAQAAgBAAAAIgDACIgCAAQgEgBgBgDIgBAAIgCgDQAAAAAAAAQAAgBABAAQAAAAAAgBQAAAAABAAIACgCIAAgBIgBgEQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAAAAAABIgCABQAAAAgBABQAAAAAAAAQAAAAAAAAQgBgBAAAAIABAAIADgCQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIgDABIgCACIgBAAQgBAAAAABQAAAAAAAAQgBAAAAgBQAAAAAAAAIABgCIABAAIADAAIACgBQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBgBIgDgKIgBgBQAAAAAAAAQAAgBgBAAQAAAAAAABQAAAAgBAAIAAABIABgCQAAAAAAAAQABAAAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAABAAIAAgCIAAAAIAAgBIACABIACADIAAAAIAAACIAEAKQAAABABgBIABgBIgBgBIgBgEIgCgEIgBgCQAAgBAAAAQAAAAAAgBQAAAAABAAQAAAAAAAAIAEgCIACAAIAAABQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAABAAIACgBQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAIgBAAIAAABIABABIACgCIABAAIAEgBIACgBIgBAAIgBgBQAAAAABAAQAAAAABAAQAAAAAAAAQABABAAAAIACABIgBgBIAGgBIACAAIABgBQAAAAAAgBQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAABAAQAAABABAAQAAAAAAAAQABgBAAAAIAEAAQABAAAAAAQABAAAAAAQABgBAAAAQAAAAAAgBQAAAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAIACgBQABAAAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIgDAAIgBABIgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAABIgEABIgDABIgFAAIgBABIgFAAIgHgCQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABIAAABIgDAAIABgCQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgDgCIgBABQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAABIgBAAQAAABAAAAQAAAAgBABQAAAAgBAAQAAAAgBABIABgCQABAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBIgBABIgDgCIAEgBIgGgEIgCACIgCgEIAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIABgBIgBAAIgCgBIABgBQAAAAAAgBQgBAAAAAAQAAAAAAgBQAAAAAAgBIgBgBQABAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgBIABAAQABABAAgBIABgIIADgCIABAAIABgCIADgDIgFAAIAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAABIgEACIAAABIgBAAIABgBIAAgBQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAAAgBABIgEAAIgBgBIACgBIgDgBIACAAIABAAIABgBIAAAAIgCgCIgBgBIACAAIACAAIgCgBIgEgEIAAgBIgDgEIgBADIgBABIABAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgCAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgDgDIgFgCIgBAAIgBAAIgDgCIABgCIABgBIABAAIAAgBIABgCIABgBIABgBIAAAAQAAgBAAAAQABAAAAAAQAAAAABAAQAAAAABAAIgCgBIgEAAIAAgBIAAgBIABAAIACAAQgCgCgEABIAAgBIgBAAIADgBQAAABAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAIgBgDIAAgBIAAAAIgBgBIgCAAIgBgBIgBAAIABACIAAACIgBACIAAAEIAAAAIgCACQAAgBAAAAQAAAAAAAAQAAgBAAAAQgBAAAAAAIAAgBIABAAIABgBIAAgBIAAAAQAAAAABgBQAAAAAAAAQAAgBAAAAQgBAAAAgBIAAAAIgCgBIAAAAIgBgBIgBgCIAAABIAAAAIgBAAIABgBIgFACQgBAAAAAAQAAAAAAAAQgBAAAAABQAAAAAAAAIgBABIgDAEIABACIAEABIABAAIAAAAIgCAAIgDABIABgBIgCgBIAAABQAAAAAAAAQAAABAAAAQAAAAABAAQAAABAAAAIACABIgBABIgBACIAAABIgBgBIgDgBIgBABIAAABIABAAIABABIAAABIABAAIgBAAIgHAAIgGAAQgNADgGAOIgBABQABAAAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAIgCgBIgCgEIgBgDIABgCIAGgJIADgBIABgCIAAAAIAFgDIABAAQAAgBgBAAQAAAAgBgBQAAAAAAAAQgBAAAAAAIgEABIAAABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIABABIgBABIgBAAIAAABIgCgBIABgEIgBgBIgCgCIAAgCIAAgBIABAAIAAABIABAAIAAgBIgBgBIAAgBIAAgBIABABIAAAAIAAgBIAAgDIAAgBIADADIgCgDIABAAIgBgBIABgBIAAgCIAAAAIABABIAAgCIABgBIADgDIABABIAAgDIABABIABABQABAAAAABIABgBIAAABIABAAIABAAIAAAAIgBACIABAAIABAAIABAAIAJAHQAAAAABAAQAAAAAAABQAAAAAAAAQAAAAAAABIgDAEIgCADQAAAAABAAQAAgBAAAAQABAAAAAAQAAABABAAIgCABIACAAIgDABIADAAIAFABIABAAIAAgCIAAgBIACgDQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAgBgBAAIABgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIAAgBQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAAAgBAAIAAgBIgCgCIACABIgBgBQAAgBAAAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgBAAIgBAAIAAABIgDAAIAAAAIgBAAQAAAAgBAAQAAAAgBAAQAAgBAAAAQAAgBAAAAIABgCIAAgBIAAgCIAAgBIgCAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgBIgBAAIgBgDIABABIABAAIAAgBIABAAIgBgCIgBAAIAAAAIAAABIgBgBIAAABIgBgCIAAgBIABABQABgBAAAAQAAAAABAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAgBABAAIABgBIABAAIgEgCIAEABIABAAQABAAAAgBQABAAAAAAQABAAAAAAQAAAAABAAIAAgCIABAAQAAAAAAgBQAAAAgBAAQAAAAgBgBQAAAAgBAAIgBABIgBAAIAAgBIAAgCIABgBIABABQABAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgDIgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIAAAAQABAAAAAAQABAAAAAAQABAAAAABQAAAAAAABIABAAIAFgBIAEAAIgCgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABIAAgDIACAEQAAAAABAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgBAAIAAABIAAAAIACAAIACAAIAFACIAAABIAAACIABABIAAgBIABACQAAAAAAAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAAEIgBgBIABACQAAAAAAAAQABAAAAAAQAAABABAAQAAABAAABIAAABIAAAAIgBAAIgBAAIAAAAIAAABIADAAIAAADQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAAAAAIAAACQAAAAABAAQAAAAABAAQAAAAAAgBQABAAAAgBIABgBIgCgBIAAgBIAFABIAAgBQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAAAAAIAEAAIgCACIACgBIABAAIABgBIgCAAIACgBQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAgBIACAAIgCgDIABAAIACAAIACAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIAAAAIABAAIgBgCIgBgCIgBAAIgBgBIgBAAIAAgCQABAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAIgBgCIgBAAIgCgCIAAAAIABAAIADABQAAAAAAABQABAAAAAAQAAABAAAAQAAAAAAABIAAABIABABIABgBIgBgDIgBgCIgDgBIgEgBIAMAAIgBACIgBgBIAAAAIAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAABABAAQAAAAAAABQAAAAAAAAQAAAAAAgBQAAAAAAAAIABgBIABgBIABABIgBACIAAABIABAAIABABIAAABIABABIAAAAIAAABIAAAAIABAEIABABQgBAAAAAAQAAAAAAgBQgBAAAAAAQAAAAAAgBIgBgCIAAAAIgBAAIAAABQgBAAAAABIABACIABACIAAgBIgCgCIgBAAQgBAAAAAAQAAABABAAIABAAQAAABAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIABACIABgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABgCIAAgBIABAAIAAABIABABIAAgBQAAgBABAAQAAAAAAAAQAAAAAAABQABAAAAAAIABABIACADIADADIACACIABgBIACAAIABgCIABgBIAFgEIABgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAABgBIABgBQAAAAAAAAQABAAAAAAQAAgBAAAAQgBAAAAAAIAAgDIABgBIACgBQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAIABABIABgBIAAgBIAAgBIABABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIAJgEQABAAAAAAQAAAAAAAAQABAAAAABQAAAAAAAAIABACIABABIAFAQIAAACIABABIABACIACAFIAAABQAAAAAAAAQAAABAAAAQAAAAgBAAQAAABAAAAIgRAGQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgBADIACADIgCAAIgDAAQAAgBAAAAQABAAAAAAQAAgBAAAAQAAgBAAAAIgCgCIAAAAIAAACIAAABIgBAAIgDgBIgBAAIgBAAIAAABIABABIgCAAIAAgBIgBAAIAAABIABACQgBgBAAAAQAAgBgBAAQAAgBAAAAQAAAAABgBIAAgCIgDgCQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAIgBgBIABADQAAABAAAAIABAAIgBABIAAABIABAAIAAAAIADgBIAAgBIAAABIAAABIgCACIgCAAIABABIAAAAIABAAIAAACQAAAAABABQAAAAAAAAQAAABAAAAQgBAAAAABIADAAIADABIABAAIABgDIABgCQABgBAAAAQAAAAABAAQAAAAAAAAQAAAAAAABIABABIAGAIQAAAAAAABQAAAAAAAAQABAAAAAAQAAAAABAAIgCgDQAAAAAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBIAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIABgBIgDgBIgDgCIAAAAIAEACIADABIADACIgBAAIgBgBIgCABIAAACIAAAAIABACIACABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQAAAAABAAIAAgBQABgBAAABIAAABIABgBIAAgBIgCgBIAAACIgEgFIAAgBIAAgBIABABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIAAgCIgBABQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAAAABAAIABAAIAAAAIgCABIABABIgBACIABAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAABAAAAQAAAAgBABQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAgBQAAAAAAAAQAAAAAAgBIABgBIAAAAIAAgBIAAAAIABAAQAAAAAAgBQAAAAgBAAQAAAAAAgBQAAAAAAAAIgCgCIAAgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABIACAAIAEABIABABIABgBIgCACQAAAAABgBQAAAAABAAQAAAAAAgBQABAAAAgBIAAAAIAAAAIAAABIgBADIAAACQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIAAAEIgCgCQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIAAABIgCAAIgCABIgBAAIACABIABgBQABAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAABQAAAAAAAAQAAAAAAABQAAAAABAAQAAAAAAAAIAGABIACAAIAEABIAAABIAAABIgCAAIgGgBIgBABIACABIAFABQABAAAAAAQAAAAAAAAQABAAAAABQAAAAAAAAIABACIAAABIgDAAIgDgCIgBAAIgBAAIgDABIgBAAIgDgBIgBAAIABAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAIgBAAIgCgCIgCAAIgBgBIgBAAIgCAAIgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBABgBAAIgBABIACAAIgBACQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAIgBgBQAAgBAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAIgEADQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAIgCgBIAAgBIgCgEQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgCAAIgCACIAAACQAAABABAAQAAAAAAABQAAAAAAAAQgBABAAAAIgBABIgCABIgBAAQgBABAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIADABIACABIACABIADABIABAAIADAAIABgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAgBAAAAIABAAIAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAABAAIADADIAAAAIABAAIAAgBIABAAQAAAAAAAAQAAABABAAQAAAAAAABQABAAAAAAQAEABACACQADACAEAAIABgBQAAAAABAAQAAAAABAAQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAAAAAAAQAAAAABAAIAAAAIAAgBQAAAAABABQAAAAAAAAQAAAAAAgBQABAAAAAAIABACQABABAAAAQAAAAAAAAQAAABAAAAQAAAAgBAAIAAABQAAAAAAABQAAAAAAAAQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAAAABQAAAAABAAQAAAAAAAAIAFAFIAFACQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIgBgCIgCAAIAAABIACAGQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAABQAAAAAAAAIABACIgCADIgBAAQAAABgBAAQAAAAgBABQAAAAAAABQAAAAABABIAAACIgBgBIgBAAIgBABIAAACIABAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAABAAIAAABIABABIACAAIACAAQAAAAABAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIAAgBIACACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIAAgBIAAgBIgBgDIgBAAQgBgGgCgCQABAAAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgBgBIAAgCIgBgBIgBgBIABgBIACAAQAAAAAAAAQABAAAAgBQAAAAAAAAQgBAAAAgBIAAgCIAAAAIgBgCIgBgCIgBgBQgBAAAAgBQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIAAgBIgBgBIgBABIAAADIgBAAQAAgBgBAAQAAAAgBgBQAAAAAAAAQgBAAAAAAIgCgBQABAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQABAAAAAAIADgBQAAgBAAABIABACQAAABAAAAQABAAAAAAQAAAAAAAAQABAAAAgBIAAAAIgCgCIAAgCIABgBIADACIADAFIABAEIgBABIAAAAIgBgBIgBgBIgBABIgBABIABABIACADIgBABIABACIACAEQAAAAAAABQAAAAAAAAQAAAAABAAQAAAAAAAAIADAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAABAAAAIgBABIgDAAIAAABQABAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgBABIACABQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAIACADIACADIAAABIAAAEIABACIABACIAAABIAAAAIgBgBQAAABAAABQAAAAAAABQABAAAAABQAAAAABAAIACAEIgCgDIgBAAIgBABIAAABIABAAIABACIgCAAQAAABAAAAQAAAAgBAAQAAAAAAgBQAAAAAAAAIABgBIAAgBIgBAAIgDACQAAABAAAAQgBAAAAABQAAAAAAAAQAAABAAAAIgBABIAAABIgDAAIABAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAAAIgBgBQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIgBAAQAAABgBAAQAAAAAAAAQAAAAAAAAQgBAAAAgBIgBAAQAAAAgBgBQAAAAAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAABAAAAIAAgCIgBAAQAAAAgBAAQAAAAAAAAQAAAAAAABQAAAAABAAIAAABIgBAAIgDgBIgCAAIgCACQAAAAgBAAQAAAAAAAAQAAABABAAQAAAAAAAAIADABIABAAIABgBIACABIAAACIABAAIABABIACACIAAACIACABQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAAAgBIgBgEIACABIABACIAAABQAAAAAAAAQAAAAAAAAQgBAAAAABQAAAAAAAAIAAABIAAAAQgBAAAAABQAAAAAAAAQAAABAAAAQABAAAAAAIAEACIAAABIAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAABAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIAAAAIgBACIAAAAIADABQAAAAABAAQAAAAABAAQAAAAAAgBQABAAAAAAIABgBIAAADIABABQAAgBABAAQAAAAAAAAQABAAAAABQAAAAABAAIAAABIACAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIABABIAAAAIACADQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABIAAAAIgBACIgCgBIgBgCIgCgBIABgBIAAgBIAAgBIgBAAIgBABIgBABIgCAAIAAAAIAAABIADACIAAABIgBAAIgCABIAAABIAAABIgCAAIAAgEIAAgCIAAAAIABgBIgCAAIgDADIgBACQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIAAgCIABAAQABAAgBgBIABAAIAAgCIABAAIACgBIAAgCIgCgBIgBgBIgCADIgBABIgBACIABgBIgBACIAAABIABACIAAACIAAABIABABIAIABIADgBQABAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIACABQAAAAAAABQABAAAAAAQAAAAAAAAQgBABAAAAIgBABQAAABgBAAIgBAAIABABIACgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABIADAGQABAAAAAAQAAAAABABQAAAAAAABQAAABABABIgBABIgCADIgBAAIAAABIACABIACADQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIABABQABAAAAABQAAAAAAABQAAAAAAABQAAAAgBABIAAAEIACABIABgBIgBgBIgBAAIAAgBIABAAIADAAQAAABAAAAQAAAAAAAAQABAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAIAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBIgDgEQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAAAAAIABAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAgBAAIgBAAIgCgCIgEgJQgBAAAAAAQAAgBAAAAQAAAAABAAQAAAAAAAAIACAAIACAAIABAAIAAAAIABACIACgBQAAAAAAAAQABAAAAAAQAAAAABAAQAAABAAAAIAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIABAAIAAAAIgEgHIgBgCQAAAAAAAAQAAgBABAAQAAAAAAAAQAAABAAAAIABAAIAAABIAAACIABABIAAgDIACAAIABACIACACIABAAIAEALIACAGIABAAIAIAXQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAgBAAIgBACQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAIAAgEIgCAAIAAAAIAAACIABACQABAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIgBAAIgBAAIgBABIgBACQAAAAAAgBQAAAAAAAAQAAAAgBgBQAAAAAAAAIAAAAIgBgBIgBAAIAAABIABAAIgEAAIACADIABADIACABIACAAIABAAQADgCADABQACACAAAEQgBAEgDAAIgDABIAAABIABADIABAGIAAABIADABIAEAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAEADABADIABABIACACQAAAAAAAAQABAAAAABQAAAAAAAAQAAAAAAAAIgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAEgFAEIgBAAIAAACIADAAIgBABIAAACQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIABAAQABAAAAAAQAAgBABAAQAAAAAAAAQAAgBABAAIACgDIAAAAIADABIADAIIACACIABABQAAAAABABQAAAAAAAAQAAAAAAABQAAAAAAAAIAAABIABADIgCgDIAAABIABADIABAAIAAABQAAAAgBAAQAAAAAAABQAAAAAAAAQABAAAAAAIABABIgBAAQAAABAAAAQABAAAAABQAAAAABABQAAAAABAAIgCAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAABIAAAAQgBAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAIACADIgBABQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAIAAAAIgFgCQgBAAAAABQAAAAABABQAAAAAAABQABAAAAAAQAAABABAAIABAAIADACIAAABIADADIAAACQAAAAAAABQAAAAgBAAQAAABAAAAQAAAAgBAAIAAABIABAAIADABIABAAIADAHIABAEIgBACIAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAAAAAIAAAAIABABIgzABgACTCcQgBAAAAAAQAAAAAAAAQgBABAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAABAAIgDAEIADAAIACgEQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAIAAAAgACFCgIAAAAIAAABIADgCgABjCdQAAAAAAAAQABAAAAAAQAAABAAAAQgBAAAAAAQAAABAAAAQAAABABAAQAAAAAAAAQABABAAAAIAAgDIABgCIgBgBIgBABIgBAAgABdCbIACACIAAACQAAAAAAAAQAAABAAAAQAAAAABAAQAAABAAAAIABgBIAAgBIgBgCIABAAIgCgCIgBAAIAAgBIAAAAIABAAIAAgBIgBAAIgBAAIgBgBIABgBIAAgBQABAAAAgBQAAAAAAAAQAAAAAAAAQAAAAgBAAIgBAAIgBACIgDAAIgCgBIAAABIAAAFIAAACIABACIACAAIABABIABAAIAAgBQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIACgDIABgBIAAAAgACNCeIgDABIgBAAIAAABIACAAIACAAQABAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIgBAAIgCAAgAByCdIAAACQAAABgBAAQAAAAAAAAQAAAAABAAQAAAAAAAAIADgCIAAgBIgBgBIgCABgABwCbIABAEIAAgCIABgCIAAAAIgBAAgAh1CYIAAABIABADIADAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIAAgCIgDACgACQCaIAAABQABAAAAABQABAAAAAAQABAAAAgBQAAAAABAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAIgBAAgABlCaIABABIABAAIAEgDIABgCQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAgBAAAAIAAAAIgBADIgCAAQgBAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAABgAhxCaIABABIABAAIABgBIgBgBIgBAAIgBAAgAiTCaIACABIABgBIgBgBIgCAAgAiPCYIAAABIABABQAAAAAAABQABAAAAAAQABAAAAAAQAAgBABAAIgBgBIgCgBIgBgDgACZCYQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAgBgBIAAgCIgBABgAiLCZIABABIACgBIgCgBgACECVIgBABIAAABIAAABIAAABIABABIAAgBIACgDIgDACIABgBIABgBQAAAAABgBQAAAAAAAAQAAAAAAAAQgBgBAAAAgACSCYIAFAAIABgBIgBgCIgBAAQAAAAgBgBQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQAAAAAAAAQAAABABAAQAAAAAAAAIABAAIABAAIgBABIgCAAgACLCXIABABIABAAIAAAAQAAgBAAAAQAAAAAAAAQAAAAgBAAQAAAAAAAAgAh5CVIACACIABAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIAAgBIgBAAIgCAAgACHCUIABACIABgBIgBgBgABnCTIAAABIABAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABgBQAAAAAAAAQAAAAAAgBQgBAAAAAAIgBgFQAAgBAAAAQAAAAAAgBQgBAAAAAAQgBAAAAAAIgBAAIAAgBIAAgBQABAAAAAAQAAgBAAAAQAAAAAAAAQgBAAAAAAIgCgBIgBAAIgCACIgDABIgDADQAAABAAgBQABAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABIABABIACgCQAAAAAAAAQABAAAAAAQAAAAABAAQAAABAAAAIABgBIgCgCIABAAIACAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQABABAAAAIAAABIgBADIAAABIABABQAAAAAAABQAAAAAAAAQAAABAAAAQABAAAAAAIAAAAIABgCgABXCUIABAAIAAgBIgCgDIABAEgACKCUQAAAAABAAQAAAAAAgBQAAAAABAAQAAAAAAgBIgBgBQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAgACQCPQABAAAAABQABAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAQAAgBABAAQAAAAgBgBQAAAAAAgBIgDgEIgBAAIgEAAIgCABIgBABIABADQAAABAAAAQAAABABAAQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIABgBgAhwCLIgBABIgCABIAAABIABACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIAAgCIABAAQAAAAAAAAQABAAAAgBQAAAAAAAAQAAAAAAgBQAAAAABAAQAAAAAAAAQAAAAAAAAQgBgBAAAAIAAAAIgBAAgAhlCLQAAAAAAABQAAAAAAABQAAAAAAAAQgBABAAAAIAEgCIAAAAIAAgBIAAABIgCgBIgCgCgAhoCKIABABIAAABIgBABIABAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAgCIgBAAgAiDCKIAAABIAEACIgCgDIgBgBIAAABIgBAAIAAAAgAh+CLIABABIAAgBIgBgBgAh5CIIACACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIgBAAIAAAAIABgBIABgBIgBgDQAAAAAAgBQAAAAAAAAQgBgBAAAAQAAAAgBAAIAAACIgBACIgBgBIgDgBIAAAAIgBAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAABAAAAIgBACIAAgDIgCgFIAAgFIAAgCQgBAAAAgBQAAAAAAAAQABAAAAAAQAAAAABAAIACgBIABAAIAAgBIAAgBIACgBQAAAAABAAQAAAAABAAQAAAAAAAAQABABAAAAIAAAFIABADIAAADIgBgDIAAACIACAEIAFAEQABABAAAAQAAAAAAAAQABAAAAAAQAAAAABgBIACgEIABAAIgCAEIABABIACAAIAAgBQAAgBABAAQAAAAAAAAQAAAAAAgBQgBAAAAAAQgBAAABgBIgBgCIACABIAAgBIAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIAAgBQABAAAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAIgCABIAAAAIAAgCIABAAIACAAIAAgDIgCABIgBAAIAAgCIgBgBIAAABQAAAAgBAAQAAABAAAAQAAAAgBAAQAAgBAAAAIgBgCIAAABIgBAAIgBgBIAAgBIAAAAIgBAAIAAADIgBACIAAgCIgBABQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAQABAAAAgBIACgBIAAgBIAAgBIgBAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIACgBIAAgBIABgDIgDAEIAAABQAAAAgBgBQAAAAAAAAQAAAAAAgBQAAAAAAgBIADgFIAAgCIgBADQAAgBAAAAQgBAAAAAAQAAAAAAAAQAAAAAAABIgDAEQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBIAAAAQgBAAAAgBQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAgBgBAAQAAAAgBAAIgBABIgBACIgDABQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIABABIABAAIACAAIgBABQAAABAAAAQAAAAAAAAQAAABgBAAQAAAAAAAAIgCACIgBACIABABQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABIgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABIADACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABgDIAAgBIABAAQABAAAAABQAAAAAAAAQAAAAAAAAQAAABgBAAIgBACIABACIACABQABAAAAAAQAAABABAAQAAAAABAAQAAAAABAAIADgBgAhgCHIABAAIAAAAIgCgDIgBAAIgBAAIAAABIABAAIAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQABAAAAAAIABAAIAAAAgAhbCGIABABIABgBIgBAAIgBAAgAhpCHIABAAIACgBQAAAAAAgBQABAAAAAAQAAAAAAAAQgBAAAAgBIAAgBIACAAIABAAIgBgBIgBABIAAAAIAAgBIABgBIgCgBIAAgBQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABIABADIgBAAIgBAAIAAABIABABQAAABAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIgBAAIAAABgAh1CFIABACIABAAQAAgBAAAAQABAAAAAAQAAgBgBAAQAAAAAAAAIgBgBIAAAAIgBABgAiPCFIABAAIAAAAIACgDQABgBgBAAQgBABAAAAQgBAAAAABQAAAAgBABQAAAAAAABgACJCEIACABIABAAIgBgCIgBAAIgDgBIAAAAQAAAAgBABQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAgBgABbB4IABAEQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABIABAEIABABQACgCABgEQAAgBABAAQAAAAAAAAQAAgBAAAAQgBAAAAAAIgCgFIABABQABAAAAAAQAAAAAAAAQABAAAAAAQAAgBAAAAIABgBIABgBIABAAIACgBIAAgBIAAgBIgBgDIgBgBIABgBIAAAAIABABIADAAIABgBIAAgDIAAgCQABAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIgDgBIgCAAIgFgBQgBgBAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAIAAAAIgBACIABACIABAAIABgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIACADQABAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIgBAEIgBABIgBAAIgBAAIAAAAIAAABIAAABIgDgCIgBgCIgDABIAAACIABgBIABAAIgBACQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABAAIABACIgBAAIgBAAgAhfCBIAAABIABABIAAgBIABgCgAhFCBIAAAAIABABIABAAIAAgCIgBAAgAhIB/IAAABQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAABAAIABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBAAIAAAAgAhWB+IAEACIAAAAIgEgCIAAAAgAhnB8IABABIACADIAAgCIgBgCIAAgBIgCgBgAhhB/IABAAIABAAIAAgBIgBgBQAAAAgBAAQAAAAAAABQAAAAAAAAQAAAAAAABgAhSB5IAAACQAAAAAAAAQAAABABAAQAAAAAAAAQAAABABAAIgBABIABAAQABAAABgBQAAAAAAAAQABgBAAAAQAAgBAAgBIgBgBIgHgCIgBAAIgBABQAAABAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIABAAIACAAgAhdB7QAAAAAAABQABAAAAAAQAAAAABAAQAAAAAAAAIACAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIAAgBIACABQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAgBgBAAIgCAAIgEgCIABAAIAEABQAAAAABABQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAAAIgDgCQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAIgBgCIgDABIAFACIgBADIgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAABQAAAAAAAAQAAABABAAQAAAAAAAAIABAAIgBABIAAABIABAAIADgBIgBgBQAAAAABAAQAAAAABAAQAAAAAAAAQABABAAAAgAg/B5QABAAAAAAQABAAAAAAQAAAAABAAQAAAAAAgBIACgGIAAgBIgBgCQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAABAAAAIgCAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAIAAABIABACIABAAIgCABIgBABIAAADIACgBIgBABIAAABIAAAAIABAAIgBABgAhJB2IABABIABABQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABAAIgCgCQABAAAAAAQAAAAAAAAQABAAAAgBQAAAAAAgBIABABIAAAAIABgBIgBgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQABAAAAAAIABAAIAAgEIgBgBQgCAAgDgCIgBAAIgCADIgBAEIgCAGIAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABAAIAAgBIABABgAhuBzIAAAAQAAABgBAAQAAAAAAABQAAAAABABQAAAAAAAAIABABIAAgBIAAgBIACgEQgBAAAAAAQgBAAAAABQAAAAAAAAQgBAAAAABgAhnBrIgDAJIgBABIABABIABgBIABgCIAAgDQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIACgEIAAgBgAhyByIgCAAIABACIABABQABAAAAAAQAAAAAAAAQABAAAAAAQAAgBAAAAIAAgBIgBgCgAhTBoIAAACIABAGIAAABIABAAIAAAAIAAgOQAAgBAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgDABIgBACIgBAJIABABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBQABgEAAgCIAAAAIABgBgAiGBwIgCABIAGgBIAAgBQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAgBAAAAIgFAAIgBAAIABABIABgBIACACgAh+BsIABABQABAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABIABABIABgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgDgBIAAAAIgBAAgABgBqQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAIgBABIAAAAIABAAIACAAIABgCIAAgEIgBAAQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAAAgAg/BrIABABIABACIACAAIAAgBIABgDIgDABIAAAAIgCAAgABuBkIAAACQAAAEAEABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCQAAAAABgBQAAAAAAAAQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAAAAAgBQAAAAAAAAQABAAAAAAIABAAIACABQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIAAgBIAAAAIgHgBIgCAAIgDAAgAg8BmIgCABIAAAAIAAABQABAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAAABIADAAIABgBIAAgDgAg4BoIABAAIABAAIgBgCgAh+BmIABACIABgBIgBgBgABrBjIAAAAIACABIABAAIAAgBIAAAAIgDgBgABpBjIABAAIgBgCIgBgFIAAgBIAAAAQAAgBAAABIgDAEQAAABAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAIAAAAIgCACIACABIAFAAIAAAAIAAgBgAhVBeIAAABIgBADQAAAAAAAAQAAABABAAQAAAAAAAAQAAAAABAAIABgBIABgBIAAgBIgBABIAAAAIgBAAQAAAAAAgBQgBAAAAAAQAAgBABAAQAAAAAAAAIACAAIgBgBIgBAAIgBAAgABvBeQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIABACQABABAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIgCgEgACBBSIgBABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAQADAGgDAGIgCADIADgBIACgBQAAAAABAAQAAAAAAgBQABAAAAAAQAAAAAAgBQACgEgBgEQgCgEgCgBIgBAAIAAAAgABuBhIgBABIAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIgBgBIAAABgAhzBiIABAAIABgBIABgBIgBAAIgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAIgBABIAAAAgAB5BdQAAABAAAAQAAABAAAAQAAAAAAAAQABABAAAAIACABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAgBABAAQAAAAAAAAQAAgBABAAQAAAAAAgBIABgGIgBgEQgBgBAAAAQgBgBAAAAQgBAAgBAAQAAAAgBABQAAAAgBAAQAAABAAAAQAAAAAAABQABAAAAAAIABACIgBABIgBAAIAAgDIgBAAIAAAAQgBABAAAAQAAABAAAAQgBABAAAAQAAABAAABIAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAgBQAAAAAAAAQAAAAABAAQAAgBAAAAQAAAAABAAgABsBfIgBABQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIABgCIgBgBIgBABgAg5BgQAAABAAAAIADAAIgBgEQAAAAgBAAQAAABgBAAQAAAAAAABQAAABAAAAgABrBTIgBABQgCAGABACIABAEIACgCQAAgBAAAAQAAAAAAgBQAAAAAAAAQgBgBAAAAIAAgBIABABIAAgCIgBgEIABgCIgBAAIAAAAgAg1BeQAAAAgBAAQAAAAAAAAQAAAAAAAAQABABAAAAIAAAAQABABAAAAQABAAAAAAQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAgABjBUQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQACACgCADIAAABIACAAQACgCABgEQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAIAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAIgCAAgAg7BdQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAIABAAIABgBIgBgBIAAgBgAhTBcIAAABIABACIACgBIABgBIAAgBIgCAAIgBAAIgBAAgABvBUIAAACIgBAEIAAACIABABQAAAAAAgBIACgIQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAgBAAIgBABgAh5BbIABABIACgCQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAABIABAAIAAABIgBAAgAiJBaIABACIABgBQAAgBAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAIgBABgACGBVIAAABIABAEIAAABIAAgGIgBAAgAhZBZQAAABgBAAQAAAAABABQAAAAAAAAQAAAAABAAIADAAIAAAAIAAgBIgCgBIgCgBgAg4BSIgBABIAAADIAAABIAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIgBgCIABgEIABgBIgBgBIAAAAgABcBTQAAAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIADABQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAgBIAAgBQAAAAABAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIgBgBIAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAIgBgBIgBgBIgBABgAh7BVIAAABIABgCIABABIABgBIgCAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAgAhhBVIABAAIACgBIgBgBIgBAAIgBACgAgGBKIgBAEIAAAFIAAABIABAAIABAAIACAAIABgBQAAgBAAAAQAAAAAAgBQAAAAAAAAQABAAAAAAIABgCQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgCIAAgBIgCgCQAAAAAAAAQABAAAAgBQAAAAAAgBQAAAAAAgBgAhfBRIgBABIABABIAAAAQABAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIgBgBIgBAAgAAfBJIgBACIAAABQACAEAEAAIABgBQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAIABgBIAAgFQABgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBgBIgEAIQAAAAAAAAQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgBgEIAAgBIAAgBgAiFBOQAAABAAAAQAAAAAAAAQAAABABAAQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBgBQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAAAAAgAh5A9IgBACIgCANIAAABIACABIAAgEIACgNIAAAAIgBAAgAAiBJIgBACIAAACIACAAIACgDQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIAAAAIgCAAIAAAAgAg6BIIABAAIAAACIACgBIACAAIAAgDQgBAAgBAAQAAAAgBABQAAAAgBAAQAAAAAAABIAAgCIgBgBIgDADIABABIAAAAIABgBIABgBIAAABgAAzBJQAAAAAAAAQAAABABAAQAAAAAAgBQAAAAAAAAQABgBAAAAQABgBAAAAQAAgBABAAQAAgBAAAAIAAgBQABABAAgBIABgCIAAgCIgCABIAAABIgDABIACgEIAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAgBAAIgJgIIgBgBIgDgFIAAAAIACAAIgBgBIgBgBIAAAAIAAgCIABAAIABgBIAAgBIgDgDIgBAAIAAACIgDAAIgGgBIgOgBQgBAAABAAIgBAAIAAABQAAABAAAAQAAABgBAAQAAAAAAAAQAAABgBAAIAAgCIAAgBIAAgBIgCAAIAAgCIgBABQAAAAAAABQAAAAAAAAQAAAAgBABQAAAAAAAAQgCACgDAAIgBAAQgBAAgBgBQAAAAAAAAQAAAAAAAAQgBABAAAAIAAAAQgFAAAAADIgCAGQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIACAAIgDAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAIAAgCIgBAAIgBAAIAAACIAAAAIgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAABAAAAIAAACIAAABIgBgBIABAAIgBgBIAAABIAAACIgBADIAAACIABAAIABgBIACgFIABAAIABgEIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAAAAAQABABAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAgBIABAAIgBABQgBAAAAABQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAAAIABgGIAAgBIgCgCQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAAAIABAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABgDIABgBIABAAIACgBIAFgBIAAAAIABABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAgBAAIgBABIgBAEQAAABAAAAQAAAAAAAAQAAAAAAAAQAAABABAAIABAAIgCABIAAACIABABIAAAAQAAAAABABQAAAAAAAAQAAAAAAAAQgBABAAAAIgBAAIgBABIABABIAAAAQAAAAgBABQAAAAAAAAQgBAAAAABQAAAAAAAAIABACIAAABIABAAIACgDIADgHIAAgBIgBgBQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAgBIACgEIAAAAIAAABIABAAQABAAAAABQAAAAABAAQAAABAAAAQAAABAAAAIABABIAAgCQABAAAAAAQAAgBAAAAQABAAAAAAQAAAAAAAAIADAAIACAAIAFAAIADAAIAAABIAAAAIgBAAIgDAAIABABQAAAAABABQAAABAAAAQAAABAAAAQAAABAAAAIgBACIAAACIACgDIABgBIAAABQAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAABIAAAAIABABIAAgBIACgEIABgBIAAABIgBADIgBADQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAgBIAAAAIAAgCIACAAIAAgBIAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAgBIABgBIAAAAIgBACIABABIABACIAAABIACgCIACgBIgCACIACgBIAAADIABgCIgBAIIABAAIAAgBIABABgAhZBJIABgBIgEgBgAgBBFQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAgCIgBABIAAAAIAAABgAg4BGIAEgCIgCgCQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAABAAAAIgBAAIAAgCIAAgBQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIAAABIACgBIABgBIgCAAIgCgBIAAgBIgBABIgCAFIgBABIAAACIABAAIACgCQAAAAAAABQABAAAAAAQAAAAAAABQgBAAAAABgAAYBEIACABIACgFQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABgBIAAAAIABgEIAAAAIAAgBIgDgBQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAABAAAAIgBAGIABgGIgBgBIgDAGIACgEIgBgBIgBAAIAAgBIABgBIgBgBQgBAAAAAAQAAAAAAABQgBAAAAAAQAAAAAAABIgBADQgBAFABABIgCACIAAABIABABIABgBIACgCIgBACIAAABIADAAIABAAQAAgBAAgBQAAAAAAgBQgBAAAAAAQAAgBAAAAIAAAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABAAIACgBIAAABIABABIAAABIgBgBQAAABAAAAQAAAAAAABQAAAAAAAAQAAABABAAIgBAAIAAABIAAABIAAAAgAAHBEQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIACgBIABgBIAAgDIAAAAIgCABIgCADIAAAAgAAqBDIAAABIABAAIABgCIAAAAIgCABgAh0BDIAAAAIACABIgBgCIAAAAIgBABgAgBBAIgBADQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIACgBIAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAAAAAAAIgBAAgAAPA4IgCACIgBACIAAABIgBAFQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIABgCIACgDIgDAGIABAAIABgBIACgHIgBABQACgDgCgCIgBAAIAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABgAgPBAIgCABIAAABQAAAAAAABQABAAAAAAQAAAAAAAAQAAgBABAAIABgCIgBgBIAAABgAhnA9IADABIABABIADACIAAABIAAgBIAAgFIACgDIACgBIgBgCIgBgBIgCABIAAABIgDgBIgBgBIAAgCIgBAAQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAAAIgBABIAAABQABABAAAAQAAAAAAAAQABAAAAAAQAAAAABAAIAAAAIACAAIABACQAAAAAAAAQAAABAAAAQAAAAgBAAQAAABAAAAIgBAAIABAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAABAAAAIAAACIgBABIgCgBIAAgDIgBgBIAAACQAAABgBgBIgDgBIAAACIAAABIAAgBIABAAIABAAgAhWA9QABABAAAAQAAAAAAABQAAAAAAABQAAAAAAAAIABABIABgBIABgCIgBgCIABgBQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAIAAgBIAAgBIgBAAIAAABIgDAGIABABIAAgBIADgBIgDABgAADA/IACACQAAgBAAgBQAAAAgBgBQAAAAgBgBQAAAAgBAAgAAeBAIACAAIABAAIAAgBQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBIgCADIAAABIgBAAIAAABgAguA9IAAAAIACACIABABIAJAAIAAAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAgBIAAAAIgDgEIgBgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAgBAAIgBAAgAgTA8IACADIABABIAAgCIgCgCIgBgBgAArAxIABACIACADIAKAHIAAABQABAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAIAAgBIgBgBIgNgLIgBgBgAgcA8IAAABIACAAIAAAAQABgCAEAAIABAAIgBgCIgCAAIgBgBIAAgBIgBgBIAAAAgAgCA8IACgCIABAAIAAgCIAAgCIABAAIgBgBIAAABIgBABIAAABQAAAAABAAQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQAAgBAAAAIgBgBgAhDA8IgCgCIABgBIgCAAIAAgBQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAgBAAAAIAAAAIgBABIgBgBIgBAAIgBgBIgBAAIAAACIABABIABABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAgBIACABIABABIADABgABnA3IgBABIAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAAAAAQAAAAAAgBIgBgDgAAEA4IABACIABgBIAAgEIAAAAIgDgBQAAgBgBAAQAAAAAAAAQgBAAAAAAQgBAAAAABIAAAAIABABQABAAAAAAQAAAAABAAQAAABAAAAQAAAAgBABIAAAAIAAABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIABgBgAgRAzIAAABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABABAAQAAAAAAAAQAAAAABgBQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAgBAAIgBgCIAAgBQABAAAAAAQAAAAAAAAQAAAAAAgBQAAAAgBAAIAAAAIgBABgAgVA0IgBABIgBABIABABQABAAAAABQAAAAAAAAQAAAAAAAAQABgBAAAAIABgBQAAAAABAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIgCgBIAAgBIAAAAIgBABgABRA2IABABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABgBIgBAAIgBAAIAAgBIAAAAIADAAIABABQAAABABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIAAAAQABgBAAAAQAAAAABAAQAAgBAAAAQAAAAAAgBIgBgBIgCAAIAAABIAAAAIgEAAIgBAAQAAAAgBAAQAAAAAAABQgBAAAAAAQAAAAAAABgAg+AmIgBADIAAACIADADQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgDADIAAABIACABQABABAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIACgCIAAgCIAAgBIgBgFIAAgBIABgBIADgBIAAgBIgBAAIgFgCgABgA0QAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIABAAQAAABABAAQAAAAABAAQAAAAAAAAQABAAAAgBIAAAAIgBAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIgCAAgAgOA0QAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAABAAIAAgBIgBgBgAgYAxQAAAAAAABQAAAAAAABQAAAAAAAAQAAABABAAIgBABIAEgDIAAgBIgCgBIgBAAgAgSAvIgCADQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIACABIABgBIgBgBQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIABAAQgBgBABAAIABAAIAAgEIAAAAIgBABIAAABIAAAAIgBgBQAAAAABAAQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAIgBABIACACIAAAAIABgBIACABgAgjAyIgBABIABAAIABABQAAAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIAAAAIgBAAgAg4AzIACABIADgBIABgBIgBgCIgEABIAAAAQgBAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAgAgQAwQAAAAAAABQAAAAABAAQAAABAAAAQAAAAABAAIACABQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIgBgBIABAAIgDgBgABUAxIgBABIABABIABgBIAAgBIgBAAgAAGAxIgBABIgBABIACAAIABgCIAAgBIgBgCIgDABIgBAAIgBAAQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIAAAAIACgCIgBgBQABAAAAABQAAAAAAAAQAAAAAAAAQAAABAAAAIABAAIABAAgAhAAyIAAABIABgCIgBAAIAAABgAgbAvIgBACIAAAAIACABIABAAIABgEIgBgBgAgNAuIAAABIABAAIACABQAAAAAAAAQABAAAAAAQAAAAAAAAQgBABAAAAIABAAQAAABAAgBIABgEIAAgBIgCAAIgBABIgBAAIgBgCIgCAAIAAACIACAAIABABIgBAAgAgeAtQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAgBAAIAAAAQABAAAAABQAAAAAAAAQAAAAAAAAQAAABgBAAQABAAAAAAQABgBAAAAQABAAAAgBQABAAAAgBIgBgBIgBgBIAAAAIgBABgABVAvIADAAIACAAIABABQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAgBAAIgBgDIgBgCIAAgBQgBAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIgBAAQAAAAgBABQAAAAAAAAQAAAAAAAAQAAAAgBAAIgCgDIAAAAIAAgCQAAgBgBAAQAAAAAAAAQAAAAAAAAQABgBAAAAIgBAAIgOgDIgCAAIgBgBQAAAAgBgBQAAAAAAAAQAAAAAAABQgBAAAAAAIAAACIABAFQAAAAAAAAQAAAAAAABQAAAAAAAAQAAABABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIACgBIACABIAAABIABAAIAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQABgBAAAAIAAABIAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIABAAIAAABIgBAAIADABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIABgBIACgCIAAACIACABIACAAIgBACIgBgBIgCAAQgBAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIgBAAQAAAAAAAAQgBABAAAAQAAAAABAAQAAABAAAAIADAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABACgAgiAvIAAAAIACgBIAAgBIAAAAIgDgBIgCACIABAAIABAAIABABgABgAtIAAABIAAAAIABgCQAAgBgBAAIgBAAIAAAAIgBAAIAAABQAAABAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQABABAAgBIAAgBgAA/ArIABABIACABQAAAAAAAAQAAgBABAAQAAAAAAAAQAAgBAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIAAgBIgCgBIgCgBQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAQAAAAAAABIACAAQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAAAIAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIgDAAIAGADIABgBIACAAgABwAqIABAAIgBgBIgBgBgAgcAlIgBAEIAAABIACgBIAAgCIAAgCIgBgBIAAABgAghApIABAAIAAgDIAAgBQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABIAAABIAAABIABgBIAAgCIABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIAAgBIAAABQAAAAgBABQAAAAAAAAQgBAAAAAAQAAAAgBAAIAAAAIgBAAIgCABIAAABQAAABAAAAQAAABAAAAQABAAAAAAQAAAAABAAgABbAkIAAACQgBAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIABAAIACgEQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAAAgBIgCgCIgDgBIADADQAAAAAAAAQABAAAAABQAAAAAAAAQABAAAAABIgBgBIgCABgAA5AoIABAAQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBIABgBIABAAIgBgBIgBAAIAAAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQAAAAAAABIACAAIgBgBIgDgDQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAABgBAAIAAABIAAABIgBAAIgCABQAAABgBAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIABgCIABAAIAAgBQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAABIgCAAIAAAAIAAgBIACgBIAAgCIAAgCQAAAAABAAQAAAAAAgBQAAAAgBAAQAAAAAAAAIgCABIgCABIABgCIAAAAIAEgDIAAAAIAAgBIAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAgBAAIgBAAIgDAAQAAgBgBAAQgBAAAAAAQgBAAAAAAQAAAAgBABIgDAAIgBABQAAAAgBAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAADIABAEIAAABIAAACIABACIgBABIgBAAIgCgBQAAABAAAAQAAABAAAAQABAAAAAAQABAAAAAAIACABIACADIABAAIAAgBQABAAgBAAIgCgDIACgBQAAACADACIABgBIADgFIABgBQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIABADQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIABAAIAAABQgBAAAAABIABAAQAAABAAAAQAAAAAAAAQABABAAAAQAAAAABAAIABgBIAAAAIABABgAhFAjQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIABABIABACIABAAQABAAAAAAQABAAAAgBQAAAAAAAAQABgBAAAAIgBgCIgEgBIgBAAgAAAAlIgBAAQAAABAAAAQABAAAAABQAAAAAAAAQAAAAABAAIADgBQgBAAAAgBQAAAAgBAAQAAgBgBAAQAAAAAAAAIgBABgABvAlIgBABIABABIABgBIAAAAIgBgBIAAgBgAAAAiIAAABIAEAAIgCgBIgBAAIAAAAIgBAAgAhUAZIgCABIAAABIADADIAAgDIAAgBIgBgBIAAAAgABmAcIABABIAAgBIAAgBgABaASIAAABIABABQABABAAAAQAAAAAAABQABAAAAABQAAABAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAIACAEQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAAAIgBgCIgCgEIADADIAAgDQAAgBgBAAQAAAAAAgBQgBAAAAAAQgBAAAAgBIAAACIgBgBIgBgBIAAAAgABJAWIAAABIAAABIAAADQAAABAAAAQAAAAABAAQAAABAAAAQAAgBAAAAIAFAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAgBgBIABgBIAAgBIAAgEIAAgBIgBAAQAAAAgBAAQAAAAAAABQAAAAAAAAQAAAAAAABgABPAaIABABIAAAAIABAAIAAAAIAAgCgAhdAZIACABIAAgBIAAgBIgDAAgAA5AJQgCADABAEIACADIAEADQADACAEgCIABgBIgBAAIgDgBIgBAAIgBAAIgCgBIABAAIAAgCIAAgCIABAAIgBgCQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAIgBAAIAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIgBgBgAgyAXIABgBIABAAIAAgBIgBAAIgBACgABOATIAAAAIABAAIAAgBIgCAAIABABgABFAOIAAABIgBAAIgBABIACAAQAAABAAAAQAAABAAAAQABAAAAAAQABABAAAAIABgBQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIgBgCIgDgCIACABIABgBIAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAAAgBAAIgGAAIADABQAAAAgBABQAAAAAAAAQAAAAAAAAQAAgBgBAAIgCAAIgBAAIACACIABAAIACgBIAAgBIABgBgAhNAKIgCABQAAABAAAAQAAAAAAAAQAAABAAAAQgBAAAAAAIAAABIAAACQAAgBABgBQAAAAABAAQAAgBAAAAQABAAAAAAIADACQAAgDgBgCIgBAAIgBAAgABHAJQAAAAAAAAQABAAAAAAQAAABAAAAQAAAAAAABIABABIABABIAAABIABABIAAgBIAAgDQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAIgBAAgAhJAOIABAAIAAgBIAAgBIgBgBQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAABABgAhoAMIABABIACgDIADgCIgCgBIgBAAgABCALQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIADAAIABAAIAAgBIgBgCIgBgBQAAgBAAAAQAAAAAAgBQAAAAAAAAQgBAAAAAAIgBgBIgDAAIACABQAAABgBAAQAAABAAAAQAAAAAAAAQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQgBAAAAAAIgBAAQAAAAgBAAQgBAAAAAAQgBABAAAAQAAABgBAAIAAABIADADIABAAIADAAIAAAAIABAAgABRAKIABgBIACABIAAAAIgEgEIgDgBQAAAEAEABgAhOAIQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAIAAgBIgBgBgAg4AEQAAAAAAABQAAABAAAAQAAABABAAQAAABABAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIABgBIACAAIAAgBQAAAAgBAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAABgBAAIgCgBIgBAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAgAAxAAIAAAAIABAHIABABQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIABgCIAAgBQAAAAABAAQAAgBAAAAQAAAAABAAQAAAAAAAAIABABQAAAAABgBQAAAAAAAAQAAgBABAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBAAAAAAIgBgBIgBAAIgDAAIAAgBIAAgBIABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgBgBIgCgBIAAgBIABAAIABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIAFAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAFACQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIgBABIAFAAIgBgBIABgBIgBgDIgBgCIgBAAIgBABQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIgCAAIABAAIACgCIABAAIAAgDIgBgCIgCgBIAAACQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAAAAAABQgEABgDgCIgCAAIgCAAIgBAAIAAABQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAgBAAIAAABIgCABQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAgBIgBgCQAAgBAAAAQAAgBAAAAQAAAAAAAAQAAgBABAAIAAAAIgBAAIgCgBIAAAAIgBABIADAGQAAABAAAAQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQAAAAAAABIACADIgBAGIAAABIAEAAQABAAAAAAQABAAABABQAAAAAAAAQABAAAAAAIAAABIgBAAIAAgBIgBAAgAhFgBIAGAEIAEACIAAAAIABAAIAAgBIgDgBIABgBIACABIABABQAAgBAAAAQABAAAAAAQAAgBgBAAQAAAAAAAAIgBgCIAAAAIAAgBIgBABIAAAAIAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBAAAAAAIgFAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAgAhlgDIAAACIgBADIABABQAAABAAgBIABgBIABAAIAAgCIAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIAAAAQABgBAAAAQAAAAAAgBQAAAAgBAAQAAAAgBAAIAAAAgAgnACQABABAAAAQABAAAAAAQAAAAAAAAQABgBAAAAIAAgBQgBAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBAAIAAAAIgBACgAhUAAIADABQABABAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABgCIgBAAIgCgBQAAAAAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAIgCAAgAg7gNQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABABAAABQAAAAAAABQAAAAAAABIAEACIABAAIAAACIAAABIACABIABAAIAAAAIgBgBIACAAIgBgBQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBIABABIACABQAAAAAAABQABAAAAAAQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAABAAAAIAEACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABAAIABgBIABgFIACgCIACgBIAAgCQABAAAAgBQAAAAAAAAQAAAAAAAAQAAgBgBAAIABgBQAAAAAAABQAAAAABAAQAAAAAAgBQAAAAAAAAIgBgBIgBgBQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAAAABAAIACgCIACgCIACgGIgBgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQABgBAAAAIAAgBIAAAAIAAgBIgBgBIABgBIABgBIgBgBIgBABIgBADIgCACIAAAAIAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgBABIgEADIgBACIACAEIAAABIABAAIAAABQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIAAgBIABgBIABgCIAAgBIACgCIADgDIAAABIgBABIgGANIAAABIABAEIAAABIgBgBIgBAEIgEABIACgBIABgBIgBgBQAAAAAAgBIABAAQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAIAAgDIgBABIgBABIABgCQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAAAAAIgCgDIADACIgBgDIgBgEIgBgBIgCABQAAAEACABIgCABIgBABIgBgBIAAgBIABAAQABgDgBgCIgCACIABgEIABgCIABgFIAAgCQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIABgBQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIAAgBQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIABABIAAABIAAAAQAAAAgBgBQAAAAAAAAQAAAAAAABQAAAAAAAAIgBAEQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAABIABgBIAAgBIAAgCIAAAAQADgCAAgDIABgBQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAAAgBAAIgCgBIgBAAIAAAAIAAgBIABABIACAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIgBgHIgBAAIAAAAIAAABIgBACIAAADIgBAAIAAgBQABAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAIAAgBIAAgDIAAgBIgGgCIABAAIADAAIABABIABAAIAAgBIgBgCQAAgBgBAAQAAgBAAAAQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAgBAAAAIADABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIgBgBIAAgCIABgFIAAAAIgBgBIgBAAIgBABIAAgBIAAgBIgBABIgBACIgCACIgCACQAAABgBAAQAAAAAAABQAAAAAAABQAAAAAAABIABADIgEAAIgBABQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIABgBIABABIABgBIgBgDIgCACIgBACIAAACIABAAIABABIgBAEQAAABAAAAQABABAAAAQAAAAABABQABAAAAAAIADAAQgBABAAAAQAAAAgBAAQAAABgBAAQAAAAgBAAIAAACIAAABIgBgBIgBgCQgBgEgCgBIgBAAIAAgCIAAgCIACAAIgBAAQAAgBAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgCAAIgBAAIAAABIAAABIgBACQgBAAAAABQAAAAgBAAQAAABAAABQAAAAABABIAAACQAAABAAABQAAAAAAABQAAAAABABQAAAAAAAAIABACIAAABIABAAIAAACIgBABIAAABIgBARIABABIABgCIAAABIABABIAAACIAAgCQAAgBABABIACAAIAAAGIAAgEQAAAAABAAQAAgBAAAAQAAAAABAAQAAAAAAAAIABABIgBAGIAAAAIgBAAIgCgBgAhVgEIABABIABAAIAAgDIAAAAIAAAAgAhYgXIgBAFIgCAFIgCAGIgBACIAHACIABAAIAAgBIgBAAIgCgBQgCgCABgDQAAAAABgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABABQABAAAAAAQABABAAAAQAAABAAABIABABIABgCIAAgBQAAAAAAAAQABAAAAgBQAAAAAAAAQgBAAAAgBIABgBIABAAIAAgBQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAABAAAAIgCABIgBgBQgDAAgBgEQAAgDADgBIABAAIgDgBIgBgBQAAAAgBABQAAAAAAAAQAAAAAAAAQAAAAAAABgAA2gEIABgBIABgCIgCABIgCABIAAAAIAAABIAAAAIABgBIABABgABAgOQAAABABAAQAAABAAAAQAAAAAAABQAAAAAAAAIAAACQAAABAAABQABAAAAABQAAAAABAAQAAABABAAIAAAAIABAAIABgBIAAgBIgCgBQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAgBIgBgCIABAAIABgBIABgCIgGACgAhcgZIgBACQgBAAAAAAQgBABAAAAQAAAAAAABQAAAAAAABIgBAEIgBABQAAAAAAAAQgBABAAAAQAAAAABAAQAAABABAAIgBABIAAACIAAACIgBABIABABIABAAIACgGIgBgCIgBgBIABgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAgBAAIAAgBIABgBQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAIgBgBIABAAQAAAAABAAQAAAAAAgBQABAAAAAAQAAAAAAgBIACgDIgBAAIgCABgAhEgPIgBABIACACIABgBIAAgBQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAgBAAgAA+gTIAAABIABACIABABIAHgCIABgBIgDAAIgDABIAAgBIABgCgAhJgZIABAAIAEADIABADIAAABIAAABIAAAAIAAAAIABgCIgBgDIAAgBIgEgDIgBAAgAhLgSIABAAIACABIAAAAIABAAIAAgBIgDgBgAhLgVIAAABIABABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAgBIgCgBgAhIggIgBABIAAACIAAABIABAAIACABIABAAIAAgBIgBgBIAAAAIgCgBIAAgBIABgCIAAgBIABAAIABAAQAAAAAAgBQgBgBAAAAQgBAAAAgBQgBAAgBAAIgBAAIAAABIABABQAAAAABAAQAAAAAAABQAAAAAAAAQAAAAAAABIgBgBIgBABIABABIABAAIAAAAgAgogfIgBACIACABIACgBIABgDIAEAAIgCgBIABAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAIgDgBIgBAAQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAgAAogiIABAFIABAAIgBgDIACgBIADgDQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgDABIAAADIgCgBgAhOggIAAABIACAAIABgBIgCgBgABBghIABAAIABgBIAAAAIgBgBIgBACgAhFgiIACABIAAgBIgBgCQgBgDgEgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBgBAAIgBADIAAABQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAAAAAIgCACIABABQAAAAABAAQAAAAABgBQAAAAAAAAQAAAAAAgBIABAAIAAAAIAAACIABgBQgBgDADABQADABACACIAAABIgBAAgABTgrIgBABIgBAAIAAABQAAABAAAAQABABAAAAQAAAAABABQABAAAAAAIACgBIAAgCIgCgCIAAAAIgBAAgAhDgnIABAAIABgBIgBgBIgCgBgAgdgrIgBABQAAABAAAAQAAAAABABQAAAAAAAAQAAAAABAAIABgBIgBgCIgBAAgAArg3IgCABIAAACIAAAAIADgBIAAAAIAAgBIABABIgCgCgAgRg/IAAACIABAAQAAAAAAABQAAAAAAAAQABAAAAAAQAAgBAAAAQAAAAgBAAIAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAAAAAgAg8g+IAAABIACAAIABAAIgBgBIgBgBgAAbhCIgBABQAAABAAAAQAAAAAAAAQAAAAAAAAQABABAAAAIAAABQABAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIABgBIAAgEIgBgBIgCACIABgCIABgBIgBAAIgCAAIAAABIgBACIgBAAIgBACIAAACIgBABIABAAgAgQhBIACACIAAgBIAAAAQgBAAAAAAQAAgBAAAAQgBAAAAAAQAAgBAAAAQAAAAgBAAQAAAAAAAAQAAABAAAAQAAAAABAAgAAXhKIgCAAIAAAGIACABQAAAAAAABQAAAAABAAQAAAAAAgBQAAAAAAAAIAAgBIABgBIgBgBIAAgEIAAgBIgBAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAgAAmhEIABAAIgBgCQAAABAAAAQgBAAAAAAQAAABAAAAQAAAAABAAgAAphOIAAACIABgBQAAAAABAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBABIgBgBIAAABgAAIhfQAAAAAAAAQgBAAAAAAQAAABAAAAQABAAAAAAIABABIAAgCIAAAAgAA8hkIABABIADAAIgDgCgAA1hlIACABQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIACAAIABgBIgBAAIgCAAIgDgBIgBABgAAghnIABABIACAAIABAAIgBgBIgCgBgAAchtIACACQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAgBQAAAAAAgBQAAgBAAAAQgBAAAAgBQgBAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAAAQAAABAAAAgAgwhwQgBAAAAABQAAAAAAAAQAAAAABAAQAAAAAAAAIACAAIgCABIADABIACABIABAAIgBgBIABgBIAAgBIgFgBIAAAAIgBAAgAg4hwIABADQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAQgBAAAAgBQAAAAAAgBQgBAAAAAAQAAAAgBAAIgCgBgAgDhxIACABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAgBAAAAIgBgCIgBABIAAAAIgBAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAgAg4h0IABACIAAAAIAFACIAAAAIAAgBIAAgBQABAAAAABQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAgBQgCgBgDAAIgCAAgAgDh4QAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIABACIgBABIACAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIABgBIAAgBIAAgBIAAABIAAAAIgBgBIAAgBIgBgBIgDgCIADgBIAAgCIgCgBIgCgEQgBgEgEABIgBAAIgCgBIAEAAIAAAAIAAgBIgBAAQgBABAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAIAAAAIgBAAIABACIgCABQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgCAAIAAABIABABQAAAAABABQAAAAAAAAQAAAAAAAAQABAAAAAAIAAAAIADABIgBgDIAAgBIABAAIABACIAAACIAAACIACAEIABABIACgBIAAACIAAAAIAFACgAgGhzIADAAIAAgBIgBgBIAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCAAIABABgAguh2IABABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIACgDIgBgCIgBgBIgFgDQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIgBABIgBACIgBACIAFAEIABAAIAAgCgAgLh6IABACQABAAAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAgBAAgAASh5IACgBIgCAAIAAABgAgBh8QAAABAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABgBIgBgBIABgBIAAAAIABgBIAAgBQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgCIAAgBIAAgBQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAAAAAIAAAFIABABQAAABgBgBIAAABgAgEiEIgBABIABABIABABIABgBIAAgBIgCgBIAAAAgAApiDIACABQAAAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAIAAgBIgBgBIACAAIACgBIAAgBQAAgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIABAAIACgBQAAAAAAgBQABAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAAAAAAAIgFABIgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAABAAAAIAAABIgCAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAABAAIAAgBIgBAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAgBgBIgBAAIAAABIACACQAAABAAAAQAAAAAAAAQAAABABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAABIACABQABAAAAAAQAAAAAAAAQABAAAAAAQAAABAAAAIgBgBQAAAAAAAAQAAAAgBABQAAAAAAAAQAAAAAAABgAgEiGIABABIABgBIgBgBQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAAAgAABiMIAAgCIAAgCIgBgBIABAFgAgDiOIABAAIABAAIAAgBQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAAAgBAAgAgUiQIABABIABAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAAAAAAAgAAwiWIgBACIAAABIABAAIACgBIAAgBIAAgBIgCgBgAgmiZIABABIAAABIAAAAQABAAAAAAQAAgBAAAAQAAgBAAAAQAAAAgBgBIAAAAgAgpibIABABIABAAIAAgBIgBAAIAAgBgAhcCLIAAAAgAg4BDIAAAAgAAZA9IAAAAgAh9A2gAAHiSIAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAIgBACIgBgCg");
	this.shape_128.setTransform(231.0607,25.5832,0.662,0.662);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25}]},61).to({state:[{t:this.shape_128},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25}]},7).to({state:[]},1).wait(127));

	// 2-T-2
	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AAhCoQgNAAgLgKQgJgKAAgNQAAAOgJAJQgLAKgNAAQAAgOAKgKQAJgJAOgBQgNAAgKgJQgKgKAAgPQAAgNAKgKQAJgKAOAAQgNAAgKgJQgKgKAAgPQAAgOAKgJQAJgKAOAAQgOAAgJgJQgKgJAAgPQAAgOAKgJQAJgKAOAAQgOAAgJgKQgKgJAAgPIAAAAQgOAAgKgJQgJgKAAgOQAAAOgKAKQgKAJgOAAQAAgOAKgJQAJgKAOAAQgNAAgKgKQgKgJAAgPQAOAAAKAKQAKAKAAANQAAgNAJgKQAKgKAOAAQAOAAAKAKQAJAKAAANQAAgMAJgLQAKgKAOAAQAOAAAKAKQAKAKAAANQAAgMAJgLQAKgKAPAAQAAAOgKAKQgLAKgNAAQAOAAAKAKQAKAKAAANIgBAAQgOAAgKgJQgJgLAAgNQAAAOgKAKQgKAJgOAAQAAAPgKAJQgJAKgOAAQANAAAKAKQAKAJAAAOQAAAPgKAJQgJAJgOAAQANAAAKAKQAKAJAAAOQAAAPgKAKQgJAJgOAAQANAAAKAKQAKAKAAANQAAAPgKAKQgKAJgNAAQAOAAAJAKQAKAKAAAOgAgJBbQgKAJgNAAQANAAAKAKQAJAKAAAOQAAgNAJgLQAKgJANgBQgNAAgKgJQgJgLAAgNQAAAOgJAKgAgJAYQgKAJgNAAQANAAAKAKQAJAKAAANQAAgMAJgLQAKgJANgBQgNAAgKgJQgJgLAAgNQAAAOgJAKgAgJgqQgKAJgNAAQANAAAKAKQAJAKAAANQAAgMAJgLQAKgJANgBQgNAAgKgJQgJgLAAgNQAAAOgJAKgAgJhtQgKAJgNAAQANAAAKAKQAJAKAAANQAAgMAJgLQAKgJANgBQgNAAgKgJQgJgLAAgNQAAAOgJAKgAAXiPQgKAKgNAAQAOAAAJAKQAKAJAAAOQAAgNAKgKQAJgKAOAAQgNAAgKgKQgKgKAAgNQAAAOgKAJgAgriPQgKAKgNAAQAOAAAJAKQAKAKAAANQAAgOAKgJQAJgKAOAAQgNAAgKgKQgKgJAAgOQAAANgKAKg");
	this.shape_129.setTransform(247.4332,25.3258,0.6621,0.6621);
	this.shape_129._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_129).wait(65).to({_off:false},0).to({_off:true},5).wait(126));

	// 2-O-2
	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AgMChIgCABIgBAAQgGAEgGAAQgLAAgHgJIgGABQgJAAgHgHQgHgGgBgJQgDgBgDgCIAAAAIABgBIAGgFIACgBIADgGIAAgCQACgDAAgEQAAgLgKgIIAAgBIAAAAIgBAAIAAgBIgFgCIADgKIAAgBQADAHAAAFIAAABIAIgBQAKAAAGAGQAHAGABAKQAHABAFAGIAGAAQAGAAAHADQAGgHAKAAQAFAAAFACQAGgJALgCQAGgQAQAAIAHABQAEgEAGgCIgBgEQAAgOANgHQACgLAIgFIAAABIAAACIACAKIAAABIABAAQAFAMAOABIABABIACAAQAFAAAGgDIAAAAIABgBQgCALgKAGIAAABIgBgBIAAgBIAAAAIAAgBQgIgMgOAAQgDAAgFACIgBAAIgBABQgHADgEAHIgBABIAAABIgBACIAAABIgBAHIAAACQAAAIAGAGIABABIAAABQAIAHAJAAIADAAQgGAJgLACQAAAKgHAGQgHAHgKAAQgFAAgHgDIgKACIgDgBIABAAIAAgCQAAgIgFgGIAAgBIgBgCQgFgFgJgDIgBAAIgEAAQgGAAgGADIABACIABABQAFgDAFAAIADAAIACAAQAJADAFAIIABABIAAACIACAIIAAACQgBAIgGAGQgHAFgIAAQgMAAgFgKgAhrB+QgHgGAAgJIAAgDIADgJIAGABQAMAAAIgKIAEACIABAAIACACIABABQAHAHAAAJQAAANgNAGIAAABIgBAAQgEABgEAAQgJAAgGgGgABcB1QgLAAgGgJIgBgCIgCgFIgBgGIAAgCIAAgDIAEgHQADgGAGgCIAAAAIABAAQADgCAEAAQANAAAGALIAAAAIABABIABACIAAABIAAABIABAGQAAAIgFAGQgFAGgHABIgBABgAh9BaIACACQAEAEAFADIgCAGIAAABIgBABQgHgHgBgKgAhtBhIgDgBQgHgDgEgGIgBgCQgDgFAAgFIABgEIgCgBIgBAAQgKgIAAgMQAAgKAHgHIgBgHIAAABIAEACIABAAIAAAAIACAAIABABIAGABQAFAAAFgDIABAAIAAgBQAGgCAEgGIAAgBIAAgBQACgDABgGIAAgCQAJAIAAALIAAAEQACAEAAAGQAAAJgGAIIgBgBIgBAAIAAAAIAAABIgBABIAAAAIABABQAHAGACAJIAAACQAAAHgDAFIgBABIgBABQgHAIgKAAgABwBDIgCAAQgIgCgGgHIgBgCQgCgFAAgFIAAgDIAAgCIACgEQABgEAFgEIABgBIAAAAQAGgEAHAAQAJAAAGAHIABABIAEAFIAAADIABABIAAAFQAAAKgIAHIgBABIgBAAQgGAEgFAAgACGAfIgBgBIAAgBQgHgIgLAAQgJAAgGAFIgBABQgEADgCAEIAAgFQAAgFACgFIAAgCIAAgDIgBgCIACgJIgBgGQgEgHAAgGQAAgFABgEIgBgIIABgHQgOgHAAgPQAAgHAEgFQgGgHAAgIQgNgBgFgLIgCgFQgDgCgDgFIgBgBIAAgBIgBgDIAAAAIAAgBIgBgEQAAgKAIgGIAAgBIABAAQAHgFAGAAIACAAQAKABAGAIIABACIACAAIACACIgBgDIgBAAIAAgBIABAAQAKAAAHAHQAHAHAAAKIAAAEQAJAIAAALQAAAFgCAEIgBAAIAAgBIgFAAIgDAAQgOABgGAMIgBABQgCAGAAAEQAAAHADAGIABABIAAAAIADAEIABABIADACIAAAAIABABQAGADAHAAQAGAAAGgDIABgBIAAAAQAEgDADgEIAAAAIABgBQADAFAAAGIgCAIQABADAAAEQAEAHAAAHQAAAEgBADIABAJQAAAIgDAFIgBACIgCABIAAABIAAAFgAh+AaIgBAAIgFgCIgBgCQgIgGAAgKQAAgGADgEIAAgBIABAAQAEgHAJgDIAFAAQALAAAHAKIAAAAIAAABIADAHIAAADQAAAGgDAEIAAABIAAABQgEAGgHACIgCABIgJAAgAhfAAIgBAAIgCgFIAAAAIAAgBQgIgMgNAAIgFAAIgBABIAAAAQgIABgFAGIgBABIAAABIAAgCQAAgKAHgHQgGgHAAgJQAAgJAHgIIgBgGQAAgHAFgHQAFgGAHgDQgDgGAAgFQAAgJAGgGQAGgHAIgBQACgOANgGIAAABIgBABIAAAFQAAAIAFAHIABACQAGAGAJACIABAAIABAAIACAAIAGgBIAAAAIABAAQgBAFgEAEIABAGQAAAPgOAGIgBABIgCAAIABAFQAAAIgGAGQgFAGgIABIgFAAIgFgBIgDgBIgBgBQgIgEgCgJIAAgBIgBgEQAAgIAFgFIgBgBIgBgCQgGAHAAAJIABAEIAAABQACAJAHAFIAAABIABAAQAFAEAGAAIAHAAIAAAAIABAAQAJAHAAALQAAAOgMAHQgBAGgCADgABpglIAAAAIgCgBIgBgBQgEgCgCgFIgBgBIAAAAQgCgFAAgFIACgJIAAAAIABgBQAGgLANAAIACAAIACAAIABAAIABABQAHACAEAFQAEAGAAAHIgCAKIAAAAIgBABQgDAFgFADIgBABIAAAAIgJACIgKgCgAANh5QgFADgGAAQgHAAgFgEQgHAHgKAAQgIAAgGgEIABgBIAAAAIABgBIACgEIAAAAIAAgBQACgEAAgGQAAgLgIgHIgBgBIgDgCIAAAAIgBAAQgFgDgGAAIgDAAIgBAAQAGgGAJAAIAHABQAGgFAIAAQAFAAAEABIgBABIgGAFIgBABIAAABIgCAFIgBAAIAAABIgBAHQAAAIAEAFIAAABIABABQADAEAFADIABAAIAAABIAGACIABAAIAEAAQAGAAAHgFIgCgCQgGAEgFAAIgBAAIgCAAIgEgBIgBAAIgCgBIgDgCQgEgCgCgFIgBgBIAAgBQgCgFAAgEIAAgDIAAgBIABgBQABgEACgEIABAAIAAgBIAFgEIABgBIABAAQAEgCAGAAQAGAAAFADIABABIABAAIAAAAIACgBQAFgEAIAAQAMAAAHAKIAGgBQAPAAAHANIgCAAQgIABgFAEIgBAAIAAABQgKAIAAALIABAGIAAABIABAAIAAABIAAABIAAABIgDgBQgEACgHAAQgMAAgHgJgAhAhyIgEgBIgGgEIgBgBQgGgHAAgJIABgGIAAgBIAAgBQAEgJAJgDIADgBIAFAAQAFAAAFACIAAABIABAAIACABIABABQAHAHAAAJQAAAFgBADIgBABIAAABIgCAEIgBABIgBABIgBABIgGADIAAABIgBAAIgHABg");
	this.shape_130.setTransform(265.0776,25.7892,0.6621,0.6621);
	this.shape_130._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_130).wait(67).to({_off:false},0).to({_off:true},8).wait(121));

	// 2-R
	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AB7CaQAAgJAJAAQAKAAAAAJQAAAKgKAAQgJAAAAgKgABnCaQAAgJAJAAQAKAAAAAJQAAAKgKAAQgJAAAAgKgABTCaQAAgJAJAAQAKAAAAAJQAAAKgKAAQgJAAAAgKgAgpCaQAAgJAJAAQAKAAAAAJQAAAKgKAAQgJAAAAgKgAg9CaQAAgJAJAAQAEAAADACQADADAAAEQAAAEgDADQgDACgEABQgJAAAAgKgAhOChQgDgDAAgEQAAgEADgDQADgCAEAAQAEAAACACQADADAAAEQAAAEgDADQgCACgEABQgEgBgDgCgAhlCaQAAgHAGgCQgFgDAAgFQAAgFADgDQACgCAEAAQAEAAADACQADADAAAFQAAAGgGADQAFACAAAGQAAAKgJAAQgKAAAAgKgAh5CaQAAgJAKAAQAJAAAAAJQAAAKgJAAQgKAAAAgKgAiNCaQAAgJAKAAQAJAAAAAJQAAAKgJAAQgKAAAAgKgABOCHQAAgKAJABQAKgBAAAKQAAAKgKAAQgJAAAAgKgAhhB8QgDgDAAgEQAAgEADgDQACgCAEAAQAEAAADACQADADAAAEQAAAEgDADQgDADgEAAQgEAAgCgDgABJB0QAAgKAJAAQAKAAAAAKQAAAKgKAAQgJAAAAgKgAhhBoQgDgCAAgFQAAgDADgDQACgDAEAAQAEAAADADQADADAAADQAAAFgDACQgDADgEAAQgEAAgCgDgABGBnQgDgCAAgFQAAgDADgDQADgDAEAAQAEAAADADQADADAAADQAAAFgDACQgDADgEAAQgEAAgDgDgAhhBVQgDgDAAgEQAAgEADgDQACgCAEgBQAEABADACQADADAAAEQAAAEgDADQgDACgEAAQgEAAgCgCgABBBUQgDgDAAgEQAAgEADgDQADgCAEgBQAEABADACQADADAAAEQAAAEgDADQgDADgEgBQgEABgDgDgAA4A6QAAgFAFgDIgEABQgEAAgDgDQgDgCAAgFQAAgDADgEQgCACgEAAQgJAAAAgJQAAgKAJAAQAKAAAAAKQAAAFgDACQADgCADAAQAKAAAAAJQAAAGgFADIAEgBQAJAAAAAJQAAAKgJAAQgKAAAAgKgAhhBCQgDgEAAgEQAAgDADgEQACgCAEAAQAEAAADACQADAEAAADQAAAEgDAEQgDACgEAAQgEAAgCgCgAhhAuQgDgDAAgEQAAgEADgDQACgDAEABQAEgBADADQADADAAAEQAAAEgDADQgDACgEAAQgEAAgCgCgAhhAbQgDgEAAgDQAAgFADgCQACgDAEAAQAEAAADADQADACAAAFQAAADgDAEQgDACgEAAQgEAAgCgCgAAWAVQgDgDAAgEQAAgFAEgDQgEgCAAgEQAAgEADgDQADgDAEAAQAEAAACADQADADAAAEQAAAEgEACQAEADAAAFQAAAEgDADQgCADgEgBQgEABgDgDgAgoAFQAAgIAJAAQAKAAAAAIQAAAKgKAAQgJAAAAgKgAg9AFQAAgIAKAAQAJAAAAAIQAAAKgJAAQgKAAAAgKgAhOANQgDgDAAgFQAAgDADgDQADgCAEAAQAEAAACACQADADAAADQAAAFgDADQgCACgEAAQgEAAgDgCgAgUAFQAAgJAJAAQAKAAAAAJQAAAJgKAAQgJAAAAgJgAAAAEQAAgIAJAAQAJAAAAAIQAAAKgJAAQgJAAAAgKgAhhAHQgDgDAAgEQAAgDADgDQACgCAEAAQAEAAADACQADADAAADQAAAEgDADQgDADgEAAQgEAAgCgDgAAmgKQAAgEACgDQADgDAEAAQAEAAADADQADADAAAEQAAAKgKgBQgJABAAgKgAhhgMQgDgCAAgFQAAgEADgCQACgDAEAAQAEAAADADQADACAAAEQAAAFgDACQgDADgEAAQgEAAgCgDgAA3gRQgDgDAAgEQAAgEADgDQADgCAEAAQAEAAADACQADADAAAEQAAAEgDADQgDADgEAAQgEAAgDgDgAhhgfQgDgDAAgEQAAgEADgDQACgCAEgBQgEAAgCgCQgDgEAAgEQAAgDADgDQADgDADAAQgEAAgCgDQgDgDAAgEQAAgEADgDQADgCADAAQgEgBgCgCQgDgEAAgDQAAgEADgDQADgDADAAQgDAAgDgDQgDgCAAgEQAAgFADgCQACgDAEAAQgDgBgDgDQgDgCAAgEQAAgGAFgCQgHgDAAgHQAAgKAKAAQAIAAABAJQABgJAJAAQAIAAABAJQABgJAJAAQAJAAAAAKQAAAKgJAAQgJAAgBgJQgBAJgIAAQgJAAgBgJQAAAFgFACQAHADAAAHQAAAEgDACQgDADgDABQADAAADADQADACAAAFQAAAEgDACQgDADgDAAQADAAADADQADACAAAFQAAADgDAEQgDACgDABQADAAADACQADADAAAEQAAAEgDADQgDADgDAAQADAAADADQADADAAADQAAAEgDAEQgDACgDAAQADABADACQADADAAAEQAAAEgDADQgDACgEAAQgEAAgCgCgABBgiQgDgDAAgEQAAgEADgDQADgDAEABQAEgBADADQADADAAAEQAAAEgDADQgDACgEAAQgEAAgDgCgABDg9QAAgJAJAAQAKAAAAAJQAAAKgKAAQgJAAAAgKgABDhQQAAgKAJAAQAKAAAAAKQAAAJgKAAQgJAAAAgJgABAhkQAAgFAEgCIgBAAQgKAAAAgKIABgFIgDAAQgKABAAgKIABgDQgCABgEABQgJAAAAgKIAAgCQgDAFgFAAQgEAAgDgDQgDgDAAgEQAAgEADgDQADgCAEAAQAEAAADACQACADAAAEIAAACQADgFAFABQAKAAAAAJIgBADQADgCADABQAJAAAAAJQAAADgBACIAEgBQAJAAAAAKQAAAFgEADIABAAQAKAAAAAJQAAAKgKAAQgJAAAAgKgAgFiYQAAgKAJABQAJgBAAAKQAAAKgJAAQgJAAAAgKgAgYiZQAAgKAJAAQAKAAAAAKQAAAKgKAAQgJAAAAgKgAgsiZQAAgKAJAAQAKAAAAAKQAAAKgKAAQgJAAAAgKgAh5iZQAAgKAJAAQAKAAAAAKQAAAKgKAAQgJAAAAgKgAiNiZQAAgKAKAAQAJAAAAAKQAAAKgJAAQgKAAAAgKg");
	this.shape_131.setTransform(283.4503,25.1437,0.6621,0.6621);
	this.shape_131._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_131).wait(71).to({_off:false},0).to({_off:true},9).wait(116));

	// 2-S
	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AAGCSQBJgFAAhDQAAghgbgPQgLgHgxgOQgtgLgTgPQgagVAAgnQAAglAXgWQAYgXAsgCIAAAUQhCAEAAA7QAAAdAYAQQAPAJApAMQAyAOAUANQAdAVAAApQAAAsgcAYQgaAXguACgAg2CeQgIgDgPgHQgHAAgBAQIgUAAIAAhcIAVAAIAEAuQAgAbApABIAAAUQgZgBgWgHgABHhQIgEgpQgPgLgKgEQgRgIgTgBIAAgUQAUABASAGIAVAIQAGAAABgMIATAAIAABSg");
	this.shape_132.setTransform(301.4919,25.094,0.6621,0.6621);
	this.shape_132._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_132).wait(74).to({_off:false},0).to({_off:true},4).wait(118));

	// 1-D
	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AiOCkIAAlHIB/AAQBAAAAwAvQAuAuAABCIAAAJQAABCguAuQgwAvhAAAgAiLChIB8AAQBAAAAugtQAtguAAhBIAAgJQAAhBgtgtQguguhAAAIh8AAg");
	this.shape_133.setTransform(20.492,25.3529,0.662,0.662);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("Ah8CQIAAkfIBuAAQA5AAApApQApApAAA6IAAAIQAAA6gpAoQgoApg6AAgAhSBpIBBAAQApAAAegeQAdgdAAgrIAAgFQAAgqgdgeQgegegpAAIhBAAg");
	this.shape_134.setTransform(20.492,25.3529,0.662,0.662);

	this.mc_headline = new lib.mc_headline();
	this.mc_headline.name = "mc_headline";
	this.mc_headline.parent = this;
	this.mc_headline.setTransform(159.85,25.4);
	this.mc_headline._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_134},{t:this.shape_133}]},10).to({state:[{t:this.shape_134},{t:this.shape_133}]},77).to({state:[{t:this.mc_headline}]},11).to({state:[{t:this.mc_headline}]},10).to({state:[]},1).wait(87));
	this.timeline.addTween(cjs.Tween.get(this.mc_headline).wait(98).to({_off:false},0).to({alpha:0},10,cjs.Ease.get(1)).to({_off:true},1).wait(87));

	// 1-I
	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("Ag4CjIAAgQIAbAAQAGAAAEgFQAFgFAAgGIAAkEQAAgFgFgGQgEgFgGAAIgbAAIAAgRIBxAAIAAARIgbAAQgGAAgFAFQgFAGAAAFIAAEEQAAAFAFAGQAFAFAGAAIAbAAIAAAQg");
	this.shape_135.setTransform(34.7571,25.6342,0.662,0.662);
	this.shape_135._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_135).wait(16).to({_off:false},0).to({_off:true},82).wait(98));

	// 1-G
	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AgVB4IAAjvIArAAIAADvg");
	this.shape_136.setTransform(42.9819,25.4688,0.662,0.662);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AhBAWIAAgrICDAAIAAArg");
	this.shape_137.setTransform(48.7575,34.852,0.662,0.662);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AAWA3IAAhBIhWAAIAAgsICBAAIAABtg");
	this.shape_138.setTransform(51.637,29.7549,0.662,0.662);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AhBAWIAAgrICDAAIAAArg");
	this.shape_139.setTransform(48.7575,16.0855,0.662,0.662);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AgVAWIAAgrIArAAIAAArg");
	this.shape_140.setTransform(54.5331,18.965,0.662,0.662);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136}]},20).to({state:[]},78).to({state:[]},1).wait(97));

	// 1-I-2
	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AAjCjIA1g2IgSA2gAgQCjIAzg2IAjAAIg0A2gAhFCjIBohsIgRA2Ig0A2gAhFBtIAjAAIg1A2gAgiBtgAgQA3IAzg3IgRA3Ig0A2gAgQAAIAzg1IgRA1Ig0A3gAgQg1IAzg3IgRA3Ig0A1gAgQhsIAzg2IAjAAIhoBtgAAjhsIA0g2IgRA2gAhFhsIA0g2IAiAAIgzA2gAhGiiIAkAAIg1A2g");
	this.shape_141.setTransform(64.324,25.4543,0.6621,0.6621);
	this.shape_141._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_141).wait(30).to({_off:false},0).to({_off:true},68).wait(98));

	// 1-T
	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AggCkIAAkFIhBAAIAAhCIDDAAIAABCIhBAAIAAEFg");
	this.shape_142.setTransform(78.6745,25.4874,0.6621,0.6621);
	this.shape_142._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_142).wait(28).to({_off:false},0).to({_off:true},70).wait(98));

	// 1-A
	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("ABuClQgOAAgGgJIgZg3IhjAAIgVA5QgDAHgNAAIg/AAQgIAAAAgFIABgIIBxkuQAFgOAPAAQAOAAAGAOICCEvIABAGQAAAGgLAAgAAGgaIgaBMIgBADQAAAEAFAAIA6AAQAFAAAAgEIAAgCIgihNQAAgBgBAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAABgBAAQAAABAAAAg");
	this.shape_143.setTransform(94.598,25.4688,0.662,0.662);
	this.shape_143._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_143).wait(35).to({_off:false},0).to({_off:true},63).wait(98));

	// 1-L
	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_144.setTransform(119.2725,34.9513,0.662,0.662);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_145.setTransform(115.4993,34.9513,0.662,0.662);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_146.setTransform(111.7096,34.9513,0.662,0.662);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_147.setTransform(107.9199,34.9513,0.662,0.662);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_148.setTransform(107.9199,31.145,0.662,0.662);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_149.setTransform(107.9199,27.3719,0.662,0.662);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_150.setTransform(107.9199,23.5656,0.662,0.662);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_151.setTransform(107.9199,19.7925,0.662,0.662);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_152.setTransform(107.9199,15.9862,0.662,0.662);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144}]},37).to({state:[]},61).to({state:[]},1).wait(97));

	// 1-I-2_1
	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("AheCjQgHAAgGgEQgEgFAAgHIAAgvQAAgHAEgEQAGgFAHAAIAsAAIAAinIgsAAQgHAAgGgEQgEgFAAgHIAAgvQAAgHAEgFQAGgEAHAAIC+AAQAHAAAEAEQAFAFAAAHIAAAvQAAAHgFAFQgEAEgHAAIgsAAIAACnIAsAAQAHAAAEAFQAFAFAAAGIAAAvQAAAHgFAFQgEAEgHAAg");
	this.shape_153.setTransform(137.975,25.3258,0.6621,0.6621);
	this.shape_153._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_153).wait(51).to({_off:false},0).to({_off:true},47).wait(98));

	// 1-N
	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("ABGCkIAAlHIAkAAIAAFHgAhpCkIAAlHIAjAAIAAFHgAgzhFIAAhZIBnDNIAABWg");
	this.shape_154.setTransform(155.2552,25.3092,0.6621,0.6621);
	this.shape_154._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_154).wait(50).to({_off:false},0).to({_off:true},48).wait(98));

	// 1-N-2
	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("ABcCkIiijDIAADDIhGAAIAAlHIA1AAICfDEIAAjEIBEAAIAAFHgABmCOIASAAIAAkbIgbAAIAADqIi+jqIgVAAIAAEbIAaAAIAAjog");
	this.shape_155.setTransform(174.29,25.3092,0.6621,0.6621);
	this.shape_155._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_155).wait(61).to({_off:false},0).to({_off:true},37).wait(98));

	// 1-O
	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#FFFFFF").s().p("AgNCgQgFADgIAAQgLAAgGgIIgGABQgKAAgGgHQgHgGAAgJQgFgBgEgDQgFADgEAAQgKAAgHgHQgHgHAAgJIABgEQgJgGAAgMIAAAAQgEgGAAgHIABgGQgMgHAAgNQAAgJAIgIQgCgDAAgFQgKgHAAgMQAAgGAFgGIgBgDQAAgLAIgGQgGgGAAgKQAAgKAHgHIgBgGQAAgIAFgGQAFgGAHgCQgDgFAAgHQAAgIAFgHQAGgGAIgBQACgPAOgFQAEgNANgDQAHgHAKAAIAGABQAGgFAIAAQAGAAAEACQAFgDAHAAQAIAAAGAGQAGgFAIAAQAMAAAHAKIAGgBQAQAAAFAOQAMAAAHALIADAAQAJAAAHAHQAHAGAAAKIgBAFQAJAGAAAMQAAAGgCAEQAIACAEAGQAFAHAAAHQAAAGgDAGQADAGAAAFQAAAEgCAFIACAHQAEAGAAAHQAAAFgCADIACAJQAAAHgEAGIAAADQAAAEgCAFQACAFAAADQAAANgLAHQgBALgLAGIgBADIACAJQAAAJgGAHQgGAGgJABQgGAKgLACQAAAJgHAHQgGAHgKAAQgHAAgFgEQgEACgGAAIgEAAQAAAJgHAGQgHAGgJAAQgMAAgHgLgAgNB5QAHgHAJAAQAHAAADACQAGgKALgCQADgHAFgEQAHgFAHAAIAHABQAEgDAGgDIAAgEQAAgOAMgHQACgKAJgGIABgFQgBgEAAgFQAAgHAEgGIAAgDIABgJQgBgDAAgEQgEgGAAgHQAAgEABgEQgBgEAAgFIABgHQgNgGAAgPQAAgGADgGQgGgGAAgJIAAAAQgNgBgGgNQgGgEgDgHIgGAAQgEACgGAAQgMAAgGgKQgFADgHAAQgHAAgFgDQgHAHgKAAQgHAAgGgFIgCABIgJAGQgCAFgFAFIABAGQAAAPgOAGIABAGQAAAIgGAHQgGAHgJABQALAHAAAMQAAANgMAHQAAAGgEAEIABADIAAABQAJAHAAALIAAAEQACAFAAAFQAAALgHAGQAKAIAAAMIAAAAQAEAGAAAHIAAACQAEgCAFAAQAJAAAHAHQAGAGABAJQAHACAFAGIAGgBQAHAAAGAEg");
	this.shape_156.setTransform(195.0296,25.3258,0.6621,0.6621);
	this.shape_156._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_156).wait(57).to({_off:false},0).to({_off:true},41).wait(98));

	// 1-V
	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FFFFFF").s().p("AgNCjIhskhQgCgHgHgGQgGgGgHAAIgMAAIAAgRIBoAAIAAARIgvAAIBvE0gAALBwIBUjlQAKgcgZAAIgYAAIAAgRIBkAAIAAARIgLAAQgHAAgHAFQgGAGgDAIIhlEMg");
	this.shape_157.setTransform(213.0058,25.2688,0.662,0.662);
	this.shape_157._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_157).wait(67).to({_off:false},0).to({_off:true},31).wait(98));

	// 1-A-2
	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FFFFFF").s().p("ABcClIAAAAIAAhkIgDAAIAAgHIADAAIAAgGIACAAIAAgEIgkAAIAAAEIgFAAIAAgEIhpAAIAAAEIgGAAIAAgEIgkAAIAAAEIADAAIAAAGIADAAIAAAHIgDAAIAABkIAAAAQgFACgHAAIgCAAIgKgCIAAhkIgDAAIAAgHIADAAIAAgGIACAAIAAgbIgCAAIAAgHIgDAAIAAgGIADAAIAAhHIgDAAIAAgFIADAAIAAgKIACAAIAAgDQABgGAFgFIAEgCIgCgDIAGgEIgCgCIAEgEIACADIBHg4IgCgCIAEgDIACACIAHgGIADADIABgBQADgDAGgBQAGABAEADIABABIACgDIAHAGIACgCIAFADIgCACIBHA4IACgDIAEAEIgBACIAFAEIgCADIAEACQAGAFgBAGIAAADIADAAIAAAKIADAAIAAAFIgDAAIAABHIADAAIAAAGIgDAAIAAAHIgDAAIAAAbIADAAIAAAGIADAAIAAAHIgDAAIAABkIAAAAIgLACQgJAAgEgCgAhwBfIAAAGQAAABAAAAQAAAAAAABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAgBAAAAQAAAAAAgBIAAgGIgCgBQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAAAgAhwA5IAAAhQAAAAAAAAQAAAAAAABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAgBAAAAQAAAAAAAAIAAghIgCgBQAAAAAAABQAAAAgBAAQAAAAAAAAQAAAAAAAAgAARAiQAAAAAAAAQAAAAAAABQAAAAAAAAQABAAAAAAIAgAAQAAAAABAAQAAAAAAAAQAAgBAAAAQABAAAAAAIgCgCIggAAQAAAAgBAAQAAAAAAAAQAAABAAAAQAAAAAAABgAAEAiQAAAAABAAQAAAAAAABQAAAAAAAAQABAAAAAAIAGAAQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQgBAAAAAAIgGAAQAAAAgBAAQAAAAAAAAQAAABAAAAQgBAAAAABgAA6AZIAAADIAkAAIAAgDIgCAAIAAgHIgDAAIAAgGIADAAIAAhHIgDAAIAAgFIADAAIAAgLIgGgEIgCACIgEgCIACgDIhHg3IgCADIgEgEIACgCIgHgFIAAAAIgGAFIACACIgEAEIgCgDIhHA3IACADIgFACIgCgCIgFAEIAAALIADAAIAAAFIgDAAIAABHIADAAIAAAGIgDAAIAAAHIgDAAIAAADIAkAAIAAgDIAGAAIAAADIBpAAIAAgDgABfgbIAAAFQAAABABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABgBIAAgFQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAABAAAAQgBAAAAABgAhwgbIAAAFQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIACgBIAAgFQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAABgABfhCIAAAgQAAABABAAQAAAAAAABQAAAAAAAAQABAAAAAAIABgCIAAggQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAABAAAAQgBAAAAAAgAhwhCIAAAgQAAABAAAAQAAAAAAABQABAAAAAAQAAAAAAAAIACgCIAAggQAAAAAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAAAgAhnhVQgDABgBACQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAgBAAAAQAAgEADAAIABgBIAAgBIgBgCIgBABgAAEigIACAAIABgBIgBgBQgCgCgEAAIgFACQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAIABAAIABAAQAAAAABAAQAAAAAAgBQABAAAAAAQABAAAAAAQAAAAABAAQABAAAAAAQABABAAAAQABAAAAAAg");
	this.shape_158.setTransform(230.7131,25.2688,0.662,0.662);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFFFFF").s().p("AgFAHQgDgDAAgEQAAgDADgDQACgCADAAQAEAAADACQACADAAADQAAAEgCADQgDACgEAAQgDAAgCgCg");
	this.shape_159.setTransform(230.6966,22.3728,0.662,0.662);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_159},{t:this.shape_158}]},69).to({state:[]},29).to({state:[]},1).wait(97));

	// 1-T-2
	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FFFFFF").s().p("AgLCiIgGgDQgEgBAAgDIgBgLQgCgKgDh7IgCgvQAAgOACg1IgBgCIgBAAQgcgBg+gFQgEgBgBgBIgCgDQAAgGAGgBIABAAIAAgKQgHAAAAgEIADgUQABgEAEgBQAZgHBrAGIBpAHQAFAAABAFIACASIgBADIgDACIgEAAIgBALIAEACIACACQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAIgCAEIgBABIhkAAIgBABIAIBpQABAUgBBIIAAAjIgCAjIAAAAIgCACQgDACgDAAIgDAAIgFAAIgBAAIAAAAIgBAAIgCABQgEAAgNgFgAAKCgIABABIAEACIADAAIABgNIgKAAgAAFhNIgBACQAFBPgCATQgBATAAAqQgBArACADQAFAAAHgCQABAAAAgBQAAAAAAAAQABAAAAgBQAAAAAAgBQgGhfABgTQACgNgDhKQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAIgFAAgAAEhgIAJACIAAAAIAAgOIAAAAIgJgBgAhniEIAAALIDNAEIAAgNQhzgEg0AAQgeAAgIACg");
	this.shape_160.setTransform(247.1329,25.5284,0.6621,0.6621);
	this.shape_160._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_160).wait(70).to({_off:false},0).to({_off:true},28).wait(98));

	// 1-O-2
	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFFFFF").s().p("AhwB4QgjgsAAhMQABgyARgfQAOgaAggZQAZgRAVgIQAXgJAdABQCEAAABCWQAAA2gTAmQgPAegfAaQgXASgVAIQgWAIgZAAQhDgBglgugAg/huQgRAZAAA8QAABRAZAoQAYAmAvAAQAQAAAJgDQALgFAIgLQAVgfAAhMQAAhLgXghQgXgfgwAAQghAAgRAVg");
	this.shape_161.setTransform(265.0941,25.4085,0.6621,0.6621);
	this.shape_161._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_161).wait(75).to({_off:false},0).to({_off:true},23).wait(98));

	// 1-R
	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#FFFFFF").s().p("AgqDFQgJgCgGgCIgOgFQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAIgCgHIABgJQACgIgBgEIgFgXIgIgZQgDgGADgXIADgbIgGgSIgFgTIgCgMIgHgPQgBgGAAgGIABgFIgGgEQAOgtABgIQAAgHgGgWQgCgGAAgFIAAgEQgBgHAFgIIAIgKQAEgEAZgNQAEgDACgFIAFgHIAIgGQAEgCAEgBIgBgBQACgBAEABIAAgCQACAAADAFQADgEADAEIAAAAIAEAGQACABADAIIgBAIQAAABABABQAAAAAAABQABAAAAAAQABABABAAQAAAGgEADQgBAAAAAAQgBAAgBABQAAAAgBAAQAAAAgBAAIgBgBIgDADIAEABQAEACAHgEQABAAAAAAQABAAAAgBQAAAAAAgBQAAgBAAgBQgDgHAFgEIADgEQAHgDALAHIAMAHIAIACIAKAAIAMACQAMAEAGAMQACAFAIACQAGAEgBAGQgBgCgDgEQgEgCgCAAIADAFIAEAEQAHAIgBAIQgDgJgIgFIADAHQACAFgCADIgCgGIAAAEIAAAAQgBAJAFAHQgEgCgCgEIgBABQgEALgCAPQgNAsgOAHQgLAGgYAAIgUAAIgCAGIAQAVIAEAAIAFAAIABAAQABAAAAABQAAAAAAAAQABAAAAABQAAAAAAABIAAAGIgBACIADACIABAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAIAAAJIADAGIADAFQABACABAFIACAGIACAAIAIADQAHAEAEAIQABADgCADIAEACIAFAAQADABAFAEQAEADACAEQAFAJgEAKIgBgHIgBAJIgBAGQAAgBgBAAQAAAAAAAAQAAABgBAAQAAABAAABQAAADACACIADAGIABAAIAEAGQABACAGACIADACIADAAQAAABABAAQAAAAgBAAQAAAAAAABQAAAAgBAAIABABQAAAAAAAAQAAABAAAAQAAAAgBAAQAAAAgBABQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAIgDgCIgEgCQgBAAAAAAQgBAAAAAAQAAABABAAQAAABABABIACADIAHAHIABABIAGAHQADADAGADQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAgBAAIgCACQAAAAAAAAQAAAAgBAAQAAAAgBAAQgBABgCAAIgFgDIgEgDIgBgBIACAGQABAAAAAAQAAABAAAAQAAAAAAAAQAAABgBAAQgDAAgCgFIgDgFIgHgHIgFgJIgLgJIgDAAQgBABAAAAQgBAAAAABQAAAAAAABQAAAAAAABIABADQgEgDAAgEIACgDQgBgBAAAAQgBAAgBgBQAAAAAAAAQgBABAAAAIgCAEIAAgBQgBgEABgCIADgDIgPgSQAAABAAABQAAAAAAABQgBAAAAABQgBAAAAAAQgEAAgEAFIgBgCQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAABgBQAAAAAAAAQABAAAAgBQAAAAAAgBQAAgBAAgBQgBABAAAAQgBAAAAAAQAAAAgBgBQAAAAAAAAIgBgBQAGACABgGQAAgBgCgGIgEgCIgGgDIgBgBIgBgEQAAgBgBAAQAAgBAAAAQgBAAAAAAQgBgBgBAAIgGgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIABgCIgDgEQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAAAQgDgCACgGIADgCIADgBQABgCgEgCQgLgEgIgFQgFgCgFgHIgHgJQgHgHgEgHQAAgBgBAAQAAgBgBAAQAAAAgBAAQgBAAAAAAQgBABAAAAQgBAAAAABQAAAAgBABQAAAAAAABIgDAPIgDAUIgEALQABAEgCAFIgBAgQgBAIACAHIADADIAMALIAPAGQAAADgFACIgLABIAHADIAFAEIgIgDIANAFQADACADADQAAABABAAQAAABAAAAQAAABAAAAQAAAAgBAAQgGACgGAAIgNgBIgFgCIAXAQQAFADACADQAAADgHADIgHABIgJgBgAgriHIgGABIgCACIgBACIgCACQAHAKABAMIAAAQIgCASIgCASQAKAJAIADIADgEIALgFQANgFAHAAQAQgCACgCQAFgDAKgaQACgDgDgFQgCgEAAgCIgDgFQgEgDABgCIACgJIgGAAQAAABgBAAQAAABAAAAQAAAAgBAAQAAABAAAAQgBAAgFgEIgGgBIgEgBIgDgCQgJgFgLgCIgUgDg");
	this.shape_162.setTransform(283.7482,25.4085,0.6621,0.6621);
	this.shape_162._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_162).wait(80).to({_off:false},0).to({_off:true},18).wait(98));

	// 1-S
	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#FFFFFF").s().p("AgECmQg8AAg6gcQgIgDADgJIATgpQACgFAHAAIAEAAQA0AZAoABQA8AAABgiQAAgbgTgRQgJgIgggRQgdgOgMgMQgTgSABgdQAAgWASgPQAUgPAlAAQAjAAAlAPIALgZQgigOgxgBQgsgBgdAUQggAUgBAmQAAA7A6AbQAFADAAAFQAAADgDADQgDADgEAAIgFgBQhFghABhFQABgvAngZQAjgYAzABQAiAAAZAGQAUAFAVAKQAJAEgEAHIgSArQgCAFgHAAIgEgBQgmgRgkgBQg2gBgBAkQAAAWAPAOQAJAJAYANQAlARALALQAXAWAAAhQAAAVgPANQgUASguAAQgpgBgygWIgKAYQAwAXA0AAQAvABAegQQAjgUAAgoQABgjgSgYQgRgYgngRQgGgDAAgFQAAgFAFgDQAFgCAFACQBWAlgBBPQgBAugmAYQgiAXg4AAIgEAAg");
	this.shape_163.setTransform(300.1679,25.4086,0.6621,0.6621);
	this.shape_163._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_163).wait(78).to({_off:false},0).to({_off:true},20).wait(98));

	// Background
	this.mc_bg = new lib.mc_bg();
	this.mc_bg.name = "mc_bg";
	this.mc_bg.parent = this;
	this.mc_bg.setTransform(159.2,25.2,0.5589,0.5589,0,0,0,363.9,45);

	this.timeline.addTween(cjs.Tween.get(this.mc_bg).wait(156).to({regY:45.1,scaleX:0.6234,scaleY:0.9563,rotation:-4.9648},20,cjs.Ease.get(1)).to({regY:45,scaleX:0.5589,scaleY:0.5589,rotation:0},12,cjs.Ease.get(1)).wait(8));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(115.8,22.3,406.8,59);
p.frameBounds = [rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, new cjs.Rectangle(113.5,22.3,411.7,59.1), new cjs.Rectangle(111.1,18.8,416.5,62.9), new cjs.Rectangle(108.8,15.5,421.1,69.6), new cjs.Rectangle(106.6,12.2,425.5,76.1), new cjs.Rectangle(104.7,9.8,429.4,81.1), new cjs.Rectangle(102.7,6.6,433.3,87.3), new cjs.Rectangle(101,4.3,436.9,91.9), new cjs.Rectangle(99.3,2.1,440.1,96.2), new cjs.Rectangle(97.7,0,443.2,100.4), new cjs.Rectangle(96.4,-1.9,445.9,104.4), new cjs.Rectangle(95.2,-3.9,448.4,108.1), new cjs.Rectangle(94,-5.6,450.7,111.6), new cjs.Rectangle(92.9,-7.2,452.8,114.9), new cjs.Rectangle(92,-8.7,454.6,117.9), new cjs.Rectangle(91.3,-9.4,456,119.2), new cjs.Rectangle(90.7,-10.6,457.2,121.8), new cjs.Rectangle(90.3,-11.1,458.2,122.7), new cjs.Rectangle(89.9,-11.5,458.8,123.3), new cjs.Rectangle(89.8,-11.5,459.2,123.6), new cjs.Rectangle(89.5,-12.4,459.6,125), new cjs.Rectangle(94,-5.6,450.7,111.6), new cjs.Rectangle(97.8,0.1,443,100.3), new cjs.Rectangle(101.3,4.6,436.1,91.2), new cjs.Rectangle(104.4,9.5,429.8,81.5), new cjs.Rectangle(107.2,13.3,424.4,73.9), new cjs.Rectangle(109.5,16.8,419.6,67), new cjs.Rectangle(111.4,19.2,415.7,62.2), new cjs.Rectangle(113.1,21.3,412.6,60.1), new cjs.Rectangle(114.3,22.3,410,59), new cjs.Rectangle(115.2,22.3,408.2,59), new cjs.Rectangle(115.7,22.3,407.2,59), rect=new cjs.Rectangle(115.8,22.3,406.8,59), rect, rect, rect, rect, rect, rect, rect];
// library properties:
lib.properties = {
	id: '94580FBEA47E434C90AB555EA46F208C',
	width: 320,
	height: 50,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Image.png", id:"Image"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['94580FBEA47E434C90AB555EA46F208C'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;