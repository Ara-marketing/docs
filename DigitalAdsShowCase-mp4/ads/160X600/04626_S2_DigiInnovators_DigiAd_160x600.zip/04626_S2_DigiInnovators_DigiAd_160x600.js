(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
var rect; // used to reference frame bounds
lib.ssMetadata = [];


// symbols:



(lib.Image = function() {
	this.initialize(img.Image);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,320,1200);


(lib.Image_1 = function() {
	this.initialize(img.Image_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,470,504);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.mc_talent = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image_1();
	this.instance.parent = this;
	this.instance.setTransform(-59,-189,0.7114,0.7114);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_talent, rect = new cjs.Rectangle(-59,-189,334.4,358.6), [rect]);


(lib.mc_logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhaBVQgiglAAgwQAAgxAigjQAigjAxAAQAlAAAfAZIAAgUIBAAAIAADlIhAAAIAAgVQghAagjAAQgxAAgigjgAgqgrQgTARABAaQgBAZATARQARASAZAAQAZAAASgSQASgRAAgZQAAgagSgRQgSgSgZAAQgZAAgRASg");
	this.shape.setTransform(26.5,42.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhNB2IAAjmIA/AAIAAAUQASgSAagFQAYgEAYAHIAAA7QgWgCgRACQgVAEgQARQgQASAAAWIAABug");
	this.shape_1.setTransform(6.05,41.837);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABmCgIgfg2IiNAAIgfA2IhSAAIC3k/IC4E/gAAkAuIgkg+IgjA+IBHAAg");
	this.shape_2.setTransform(-20.525,37.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AjwFSIGEqjIBdCgIkpIDg");
	this.shape_3.setTransform(-14.875,-20.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhZhNICzAAIhaCbg");
	this.shape_4.setTransform(9.6,-12.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhZBOIBZibIBaCbg");
	this.shape_5.setTransform(19.8,-11.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhZhNICzAAIhaCbg");
	this.shape_6.setTransform(19.8,5.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhZhNICzAAIhaCbg");
	this.shape_7.setTransform(-0.6,5.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhZBOIBZibIBaCbg");
	this.shape_8.setTransform(30,5.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhZBOIBZibIBaCbg");
	this.shape_9.setTransform(9.6,5.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_logo, rect = new cjs.Rectangle(-38.9,-54,78,108.1), [rect]);


(lib.mc_CTA = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F94B8").s().p("AAaAxIgahTIAAAAIgZBTIgJAAIgcheIAAgEIAIAAIAZBUIAbhUIAHAAIAZBUIABAAIAYhUIAIAAIAAAEIgcBeg");
	this.shape.setTransform(37.225,2.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F94B8").s().p("AghAlQgMgOAAgXQAAgWAMgOQANgNAUAAQAUAAANANQANAOAAAWQAAAXgNAOQgNANgUAAQgUAAgNgNgAgagfQgJAMAAATQAAAUAJAMQAKALAQAAQARAAAKgLQAJgMAAgUQAAgTgJgMQgLgLgQAAQgQAAgKALg");
	this.shape_1.setTransform(24.7,2.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F94B8").s().p("AAeAyIAAhHQAAgUgUAAQgRAAgWAQIAABLIgKAAIAAhiIAFAAQABAAAAAAQABAAABAAQAAABAAAAQABAAAAAAQABADAAAGIAAAGQAWgRAUAAQAaAAAAAaIAABJg");
	this.shape_2.setTransform(13.8,2.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F94B8").s().p("AgSBBIAAgDIAQgjIgohYIAAgDIAJAAIAiBQIAihQIAIAAIAAADIg0B+g");
	this.shape_3.setTransform(-1.725,3.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F94B8").s().p("AgEBCIAAiDIAEAAQADAAABABQABABAAAHIAAB6g");
	this.shape_4.setTransform(-8.775,0.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F94B8").s().p("AgqBCIAAiCIAFAAQAAAAABABQABAAAAAAQABAAAAAAQAAABABAAQABACAAAGIAAAIQAQgTAVAAQAQABAKAJQAMANAAAbQAAAagOAMQgLALgSAAQgTAAgNgLIAAArgAggglIAAAzQAMANATAAQAOAAAJgIQALgMAAgVQAAgXgKgMQgHgIgNAAQgSAAgRAUg");
	this.shape_5.setTransform(-15.975,3.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F94B8").s().p("AgqBCIAAiCIAFAAQAAAAABABQABAAAAAAQABAAAAAAQABABAAAAQABACAAAGIAAAIQAQgTAVAAQAQABAKAJQAMANAAAbQAAAagOAMQgLALgSAAQgTAAgNgLIAAArgAggglIAAAzQAMANATAAQAOAAAJgIQALgMAAgVQAAgXgKgMQgHgIgNAAQgSAAgRAUg");
	this.shape_6.setTransform(-26.925,3.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2F94B8").s().p("AArBCIgOgpIg5AAIgOApIgJAAIAAgDIAviAIAKAAIAuCAIAAADgAAaARIgahHIgZBHIAzAAg");
	this.shape_7.setTransform(-38.8,0.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AnyCxQhHAAgygyQgygyAAhHIAAgLQAAhHAygyQAygyBHAAIPlAAQBHAAAyAyQAyAyAABHIAAALQAABHgyAyQgyAyhHAAg");
	this.shape_8.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_CTA, rect = new cjs.Rectangle(-67,-17.6,134.1,35.3), [rect]);


(lib.mc_course = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAAQABgCACgDQACgCADAAQADAAADACQADADgBACQABADgDADQgDACgDAAQgIABAAgJg");
	this.shape.setTransform(30.75,5.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgUBLIAAgDIARgpIguhmIAAgDIAKAAIAoBcIAnhcIAKAAIAAADIg9CSg");
	this.shape_1.setTransform(23.1,2.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgEBNIAAiZIADAAQAEAAACACQAAACAAAHIAACOg");
	this.shape_2.setTransform(14.85,-1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgsAcIAAhVIAMAAIAABUQgBAWAWAAQAUAAAZgTIAAhXIALAAIAABxIgFAAQgEAAgBgCQgBgCAAgIIAAgFQgYATgXAAQgfAAAAgeg");
	this.shape_3.setTransform(6.05,0.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AghBGIAAgKIAFAAQAIAIAQAAQAaAAAAgbIAAh2IAMAAIAAB2QAAAkglAAQgSAAgMgHg");
	this.shape_4.setTransform(-5.625,-1.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAjA6IAAhTQAAgXgYAAQgUABgYASIAABXIgLAAIAAhyIAEAAQABAAABABQABAAAAAAQABAAAAABQABAAAAAAQABACABAIIAAAGQAYgTAYAAQAfAAAAAeIAABVg");
	this.shape_5.setTransform(-21.85,0.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgEBJIAAhxIADAAQADAAACACQABACAAAIIAABlgAgGhBQAAgDACgDQACgCACAAQADAAACACQACADAAADQAAAIgHAAQgHAAABgIg");
	this.shape_6.setTransform(-30.7,-0.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgNAwIAAhQIgQAAIAAgJIAQAAIAAggIALAAIAAAgIAdAAIAAAJIgdAAIAABPQAAAKADAEQAFAEAKAAIAOAAIAAAHQgHACgKAAQgaAAAAgag");
	this.shape_7.setTransform(60.025,-26.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgaA6IAAhyIAFAAQABAAABAAQABAAAAABQABAAAAAAQABABAAAAQABACAAAJIAAAHQAQgVAVAAIAFABIAAAJIgFAAQgTAAgSAVIAABUg");
	this.shape_8.setTransform(53.025,-25.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AggAyQgKgJAAgPQgBgSANgIQAMgHAVAAQAQAAANADIAAgVQAAgYgcABQgWAAgNAKIgEAAIAAgJQASgKAWAAQAngBgBAhIAABSIgDAAQgEAAgCgCQgBgCgBgHIAAgEQgPAQgWABQgRAAgKgJgAggAZQABAZAbAAQAVAAAPgSIAAgdQgPgDgOAAQgiAAgBAZg");
	this.shape_9.setTransform(42.4,-25.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgNAwIAAhQIgQAAIAAgJIAQAAIAAggIALAAIAAAgIAdAAIAAAJIgdAAIAABPQAAAKADAEQAFAEAKAAIAOAAIAAAHQgHACgKAAQgaAAAAgag");
	this.shape_10.setTransform(33.575,-26.675);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgmAvIAAgJIAEAAQAMAMAVAAQAdAAAAgZQAAgKgGgFQgHgEgQgEQgSgCgIgGQgKgIAAgNQAAgPALgIQAKgHAQAAQAUgBAOAJIAAAJIgFAAQgLgJgSAAQgbAAAAAVQAAAKAHAEQAGAFAQADQATADAIAFQAKAIAAAPQAAAhgoABQgWAAgPgMg");
	this.shape_11.setTransform(25.15,-25.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgmAvIAAgJIAEAAQAMAMAVAAQAdAAAAgZQAAgKgGgFQgHgEgQgEQgSgCgIgGQgKgIAAgNQAAgPALgIQAKgHAQAAQAUgBAOAJIAAAJIgFAAQgLgJgSAAQgbAAAAAVQAAAKAHAEQAGAFAQADQATADAIAFQAKAIAAAPQAAAhgoABQgWAAgPgMg");
	this.shape_12.setTransform(9.4,-25.15);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgiArQgOgQAAgbQAAgZAOgRQAPgPAVAAQAWAAAMAMQANAOAAAbIAAAEIhWAAQAAAyArAAQAYAAALgNIAFAAIAAAIQgQAOgZAAQgZgBgOgPgAAmgHQgBgqgjAAQgPAAgLALQgLAKgCAVIBLAAIAAAAg");
	this.shape_13.setTransform(-1.375,-25.15);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgiArQgOgQAAgbQAAgZAOgRQAPgPAVAAQAWAAAMAMQANAOAAAbIAAAEIhWAAQAAAyArAAQAYAAALgNIAFAAIAAAIQgQAOgZAAQgZgBgOgPgAAmgHQgBgqgjAAQgPAAgLALQgLAKgCAVIBLAAIAAAAg");
	this.shape_14.setTransform(-13.075,-25.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgaA6IAAhyIAFAAQABAAABAAQABAAAAABQABAAAAAAQAAABABAAQABACAAAJIAAAHQAQgVAVAAIAFABIAAAJIgFAAQgTAAgSAVIAABUg");
	this.shape_15.setTransform(-22.475,-25.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgqBCIAAgIIAEAAQANAKAZAAQAmAAAAgeIAAgTQgRAUgYAAQgTAAgMgNQgOgOAAgcQAAgeAPgQQAOgNATAAQAYAAAOAOQABgNAHAAIADAAIAABwQAAATgOAKQgNAJgVAAQgbAAgQgKgAgYg5QgNANAAAbQAAAZALAMQAJAKAPAAQAXAAARgXIAAg6QgPgQgVAAQgQAAgKAKg");
	this.shape_16.setTransform(-33.775,-23.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgiArQgOgQAAgbQAAgZAOgRQAPgPAVAAQAWAAAMAMQANAOAAAbIAAAEIhWAAQAAAyArAAQAYAAALgNIAFAAIAAAIQgQAOgZAAQgZgBgOgPgAAmgHQgBgqgjAAQgPAAgLALQgLAKgCAVIBLAAIAAAAg");
	this.shape_17.setTransform(-45.525,-25.15);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgiBBQgOgPAAgeQAAgeAPgQQAOgMATAAQAYAAAOAOIAAg1IAEAAQAFAAABADQABABAAAHIAACOIgFAAQgEAAgBgCQgBgCAAgJIAAgHQgQAWgZAAQgTAAgMgNgAgYgTQgNANAAAaQAAAaALAMQAJALAPAAQAXAAARgYIAAg7QgPgQgVAAQgQAAgKALg");
	this.shape_18.setTransform(-58.225,-27.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgFBNIAAiQIgyAAIAAgJIBvAAIAAAJIgyAAIAACQg");
	this.shape_19.setTransform(49.575,-53.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgnA6QgTgWAAgkQAAgkAUgVQATgUAcAAQARAAALAEQAJAEAKAIIAAAJIgGAAQgPgPgZAAQgYAAgPARQgRASAAAgQAAAgAPATQAPARAYAAQAcAAASgSIAFAAIAAAJQgVATgeAAQgdAAgSgUg");
	this.shape_20.setTransform(36.275,-53.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgFBNIAAiZIALAAIAACZg");
	this.shape_21.setTransform(26.3,-53.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgiArQgOgQAAgbQAAgZAOgRQAPgPAVAAQAWAAAMAMQANAOAAAbIAAAEIhWAAQAAAyArAAQAYAAALgNIAFAAIAAAIQgQAOgZAAQgZAAgOgQgAAmgHQgBgqgjAAQgPAAgLALQgLAKgCAVIBLAAIAAAAg");
	this.shape_22.setTransform(11.825,-51.15);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgEBNIAAiZIADAAQAEAAACACQAAACAAAGIAACPg");
	this.shape_23.setTransform(3.5,-53.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgmBAQgBANgHAAIgCAAIAAiaIAEAAQAEABABACQACABAAAHIAAAxQASgWAYABQATAAALALQAOAQAAAcQAAAggQAPQgNAOgUAAQgXAAgPgOgAglgGIAAA7QANAQAXAAQAQAAAKgKQANgNAAgcQAAgZgLgMQgJgKgPAAQgVAAgTAXg");
	this.shape_24.setTransform(-4.825,-53.05);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgEBKIAAhyIADAAQADAAACACQABACAAAIIAABmgAgGhBQAAgDACgDQACgCACAAQADAAACACQACADAAADQAAAHgHABQgHgBABgHg");
	this.shape_25.setTransform(-14.05,-52.75);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAlA5Iglg1IglA1IgJAAIAAgEIAng2IglgzIAAgEIAKAAIAiAwIAggwIAJAAIAAAEIgiAyIAoA3IAAAEg");
	this.shape_26.setTransform(-22.025,-51.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgiArQgOgQAAgbQAAgZAOgRQAPgPAVAAQAWAAAMAMQANAOAAAbIAAAEIhWAAQAAAyArAAQAYAAALgNIAFAAIAAAIQgQAOgZAAQgZAAgOgQgAAmgHQgBgqgjAAQgPAAgLALQgLAKgCAVIBLAAIAAAAg");
	this.shape_27.setTransform(-33.375,-51.15);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgEBNIAAiZIADAAQAEAAACACQABACAAAGIAACPg");
	this.shape_28.setTransform(-41.7,-53.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgtBNIAAiZIBbAAIAAAKIhPAAIAAA/IA6AAIAAAJIg6AAIAABHg");
	this.shape_29.setTransform(-49.725,-53.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_course, rect = new cjs.Rectangle(-68.9,-65,137.8,78), [rect]);


(lib.mc_background = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image();
	this.instance.parent = this;
	this.instance.setTransform(-80,-300,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_background, rect = new cjs.Rectangle(-80,-300,160,600), [rect]);


(lib.clicktag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgO/AyBMAAAhkBId/AAMAAABkBg");
	this.shape.setTransform(0.025,0.025);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = null;
p.frameBounds = [rect, rect, rect, new cjs.Rectangle(-96,-320,192.1,640.2)];


// stage content:
(lib._04626_S2_DigiInnovators_DigiAd_160x600 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* Click to Go to Web Page
		Clicking on the specified symbol instance loads the URL in a new browser window.
		
		Instructions:
		1. Replace http://www.adobe.com with the desired URL address.
		   Keep the quotation marks ("").
		*/
		
		this.button_1.addEventListener("click", fl_ClickToGoToWebPage_4);
		
		function fl_ClickToGoToWebPage_4() {
			window.open(window.clicktag);
		}
	}
	this.frame_352 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(352).call(this.frame_352).wait(1));

	// clicktag
	this.button_1 = new lib.clicktag();
	this.button_1.name = "button_1";
	this.button_1.parent = this;
	this.button_1.setTransform(80,298.05);
	new cjs.ButtonHelper(this.button_1, 0, 1, 2, false, new lib.clicktag(), 3);

	this.timeline.addTween(cjs.Tween.get(this.button_1).wait(353));

	// CTA
	this.instance = new lib.mc_CTA();
	this.instance.parent = this;
	this.instance.setTransform(80.25,188.25,0.2635,0.2635);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(39).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},15).wait(49).to({alpha:0},10).to({_off:true},1).wait(49).to({_off:false,scaleX:0.2635,scaleY:0.2635},0).to({scaleX:1,scaleY:1,alpha:1},15).wait(50).to({alpha:0},10).to({_off:true},1).wait(49).to({_off:false,scaleX:0.2635,scaleY:0.2635},0).to({scaleX:1,scaleY:1,alpha:1},15).wait(50));

	// CourseSpecific
	this.instance_1 = new lib.mc_course();
	this.instance_1.parent = this;
	this.instance_1.setTransform(79.7,121.6,0.7208,0.7208);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(24).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},15).wait(64).to({alpha:0},10).to({_off:true},1).wait(34).to({_off:false,scaleX:0.7208,scaleY:0.7208},0).to({scaleX:1,scaleY:1,alpha:1},15).wait(65).to({alpha:0},10).to({_off:true},1).wait(34).to({_off:false,scaleX:0.7208,scaleY:0.7208},0).to({scaleX:1,scaleY:1,alpha:1},15).wait(65));

	// Logo
	this.instance_2 = new lib.mc_logo();
	this.instance_2.parent = this;
	this.instance_2.setTransform(80.6,506.75,0.4103,0.4103);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:1,scaleY:1,alpha:1},14,cjs.Ease.get(1)).wait(339));

	// Talent
	this.instance_3 = new lib.mc_talent();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-10.85,638.05);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({_off:false},0).to({y:433,alpha:1},20).wait(79).to({y:675.05,alpha:0},10).to({_off:true},1).wait(14).to({_off:false,y:638.05},0).to({y:433,alpha:1},20).wait(80).to({y:675.05,alpha:0},10).to({_off:true},1).wait(14).to({_off:false,y:638.05},0).to({y:433,alpha:1},20).wait(80));

	// Background
	this.instance_4 = new lib.mc_background();
	this.instance_4.parent = this;
	this.instance_4.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(353));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(64,278,192.1,640.2);
p.frameBounds = [rect, rect, rect, rect, new cjs.Rectangle(10.2,278,334.4,829.6), new cjs.Rectangle(10.2,278,334.4,819.4), new cjs.Rectangle(10.2,278,334.4,809.1), new cjs.Rectangle(10.2,278,334.4,798.9), new cjs.Rectangle(10.2,278,334.4,788.6), new cjs.Rectangle(10.2,278,334.4,778.4), new cjs.Rectangle(10.2,278,334.4,768.1), new cjs.Rectangle(10.2,278,334.4,757.9), new cjs.Rectangle(10.2,278,334.4,747.6), new cjs.Rectangle(10.2,278,334.4,737.4), new cjs.Rectangle(10.2,278,334.4,727.1), new cjs.Rectangle(10.2,278,334.4,716.8), new cjs.Rectangle(10.2,278,334.4,706.6), new cjs.Rectangle(10.2,278,334.4,696.3), new cjs.Rectangle(10.2,278,334.4,686.1), new cjs.Rectangle(10.2,278,334.4,675.8), new cjs.Rectangle(10.2,278,334.4,665.6), new cjs.Rectangle(10.2,278,334.4,655.3), new cjs.Rectangle(10.2,278,334.4,645.1), rect=new cjs.Rectangle(10.2,278,334.4,640.2), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, new cjs.Rectangle(10.2,278,334.4,648.8), new cjs.Rectangle(10.2,278,334.4,673), new cjs.Rectangle(10.2,278,334.4,697.2), new cjs.Rectangle(10.2,278,334.4,721.4), new cjs.Rectangle(10.2,278,334.4,745.6), new cjs.Rectangle(10.2,278,334.4,769.8), new cjs.Rectangle(10.2,278,334.4,794), new cjs.Rectangle(10.2,278,334.4,818.2), new cjs.Rectangle(10.2,278,334.4,842.4), new cjs.Rectangle(10.2,278,334.4,866.6), rect=new cjs.Rectangle(64,278,192.1,640.2), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, new cjs.Rectangle(10.2,278,334.4,829.6), new cjs.Rectangle(10.2,278,334.4,819.4), new cjs.Rectangle(10.2,278,334.4,809.1), new cjs.Rectangle(10.2,278,334.4,798.9), new cjs.Rectangle(10.2,278,334.4,788.6), new cjs.Rectangle(10.2,278,334.4,778.4), new cjs.Rectangle(10.2,278,334.4,768.1), new cjs.Rectangle(10.2,278,334.4,757.9), new cjs.Rectangle(10.2,278,334.4,747.6), new cjs.Rectangle(10.2,278,334.4,737.4), new cjs.Rectangle(10.2,278,334.4,727.1), new cjs.Rectangle(10.2,278,334.4,716.8), new cjs.Rectangle(10.2,278,334.4,706.6), new cjs.Rectangle(10.2,278,334.4,696.3), new cjs.Rectangle(10.2,278,334.4,686.1), new cjs.Rectangle(10.2,278,334.4,675.8), new cjs.Rectangle(10.2,278,334.4,665.6), new cjs.Rectangle(10.2,278,334.4,655.3), new cjs.Rectangle(10.2,278,334.4,645.1), rect=new cjs.Rectangle(10.2,278,334.4,640.2), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, new cjs.Rectangle(10.2,278,334.4,648.8), new cjs.Rectangle(10.2,278,334.4,673), new cjs.Rectangle(10.2,278,334.4,697.2), new cjs.Rectangle(10.2,278,334.4,721.4), new cjs.Rectangle(10.2,278,334.4,745.6), new cjs.Rectangle(10.2,278,334.4,769.8), new cjs.Rectangle(10.2,278,334.4,794), new cjs.Rectangle(10.2,278,334.4,818.2), new cjs.Rectangle(10.2,278,334.4,842.4), new cjs.Rectangle(10.2,278,334.4,866.6), rect=new cjs.Rectangle(64,278,192.1,640.2), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, new cjs.Rectangle(10.2,278,334.4,829.6), new cjs.Rectangle(10.2,278,334.4,819.4), new cjs.Rectangle(10.2,278,334.4,809.1), new cjs.Rectangle(10.2,278,334.4,798.9), new cjs.Rectangle(10.2,278,334.4,788.6), new cjs.Rectangle(10.2,278,334.4,778.4), new cjs.Rectangle(10.2,278,334.4,768.1), new cjs.Rectangle(10.2,278,334.4,757.9), new cjs.Rectangle(10.2,278,334.4,747.6), new cjs.Rectangle(10.2,278,334.4,737.4), new cjs.Rectangle(10.2,278,334.4,727.1), new cjs.Rectangle(10.2,278,334.4,716.8), new cjs.Rectangle(10.2,278,334.4,706.6), new cjs.Rectangle(10.2,278,334.4,696.3), new cjs.Rectangle(10.2,278,334.4,686.1), new cjs.Rectangle(10.2,278,334.4,675.8), new cjs.Rectangle(10.2,278,334.4,665.6), new cjs.Rectangle(10.2,278,334.4,655.3), new cjs.Rectangle(10.2,278,334.4,645.1), rect=new cjs.Rectangle(10.2,278,334.4,640.2), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect];
// library properties:
lib.properties = {
	id: '864E46D2E14B4EDAA09C92E5FADDAEB2',
	width: 160,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Image.png", id:"Image"},
		{src:"images/Image_1.png", id:"Image_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['864E46D2E14B4EDAA09C92E5FADDAEB2'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;