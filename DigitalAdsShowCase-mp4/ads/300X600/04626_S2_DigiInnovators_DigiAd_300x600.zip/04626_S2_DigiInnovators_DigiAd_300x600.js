(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
var rect; // used to reference frame bounds
lib.ssMetadata = [];


// symbols:



(lib.Image = function() {
	this.initialize(img.Image);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,1200);


(lib.Image_1 = function() {
	this.initialize(img.Image_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,470,504);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.mc_talent = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image_1();
	this.instance.parent = this;
	this.instance.setTransform(65,22);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_talent, rect = new cjs.Rectangle(65,22,470,504), [rect]);


(lib.mc_nowstime = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLBXQgEgFAAgHQAAgGAEgFQAFgFAGAAQAGAAAFAFQAFAFAAAGQAAAHgFAFQgFAFgGAAQgGAAgFgFgAgIArIgFh1IAAgRIAbAAIAAARIgFB1g");
	this.shape.setTransform(72,69.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgUA0IAAhTIgRAAIAAgSIARAAIAAglIAaAAIAAAlIAdAAIAAASIgdAAIAABQQAAAKAEAFQAFAEAKAAIAMAAIAAARQgJACgMAAQgkAAAAgjg");
	this.shape_1.setTransform(63.6,70.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgkAzQgRgSAAghQgBgfAUgTQASgTAcAAQAYAAASALIAAAVIgMAAQgLgLgTAAQgRAAgKANQgLANAAAWQAAAYAKANQAKANARAAQAWAAAMgNIAKAAIAAATQgSAOgaAAQgeAAgRgTg");
	this.shape_2.setTransform(52.4,71.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgqA7QgMgKAAgUQAAgUAPgKQAOgKAYAAQAOAAAPAEIAAgSQAAgYgcAAQgUAAgQAMIgIAAIAAgUQAXgMAZAAQAzAAAAAqIAABfIgLAAQgIAAgDgDQgDgDgBgJQgQARgYAAQgTAAgMgLgAgcAcQAAAYAaAAQAQAAAOgQIAAgdQgNgCgMAAQgfAAAAAXg");
	this.shape_3.setTransform(38.375,71.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgtAyQgRgSAAggQAAgeARgTQASgTAbAAQAdAAARATQARATAAAeQAAAggRASQgRATgdAAQgbAAgSgTgAgkgqQgNAPABAbQgBAcANAPQAOAQAWAAQAXAAANgQQAOgPAAgcQAAgbgOgPQgNgQgXAAQgWAAgOAQg");
	this.shape_4.setTransform(17.45,72);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgQA5IAAhgIgSAAIAAgKIASAAIAAglIANAAIAAAlIAjAAIAAAKIgjAAIAABeQAAAMAFAFQAFAEAMAAIAQAAIAAAJQgIACgMAAQgfAAAAgeg");
	this.shape_5.setTransform(5.8,70.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgoAyQgRgRAAghQAAgeARgTQARgTAZAAQAaAAAOAPQAQAQAAAhIAAAEIhlAAQAAA7AyAAQAcgBAOgOIAGAAIAAAKQgUAPgeAAQgdAAgQgTgAAtgIQgCgygpAAQgSAAgNAMQgMANgCAZIBYAAIAAAAg");
	this.shape_6.setTransform(89.55,44);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("ABRBEIAAhjQAAgagZAAQgWAAgbAXIAABmIgMAAIAAhjQAAgagZAAQgXAAgbAXIAABmIgNAAIAAiGIAHAAQAEAAABADQABABAAAKIAAAHQAcgXAbAAQAZABAGAWQAagWAcgBQAiABAAAhIAABmg");
	this.shape_7.setTransform(71.175,43.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgFBXIAAiGIADAAQAFgBABADQACACAAAJIAAB5gAgIhNQAAgDADgDQADgDACAAQAEAAACADQADADAAADQAAAJgJAAQgIAAAAgJg");
	this.shape_8.setTransform(56.8,42.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgQA5IAAhgIgSAAIAAgJIASAAIAAgmIANAAIAAAmIAjAAIAAAJIgjAAIAABeQAAAMAFAFQAFAEANABIAPAAIAAAJQgJABgLAAQgfAAAAgeg");
	this.shape_9.setTransform(49.7,42.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgpAyQgQgRAAghQAAgeARgTQARgTAZAAQAaAAAPAPQAPAQAAAhIgBAEIhlAAQAAA7AzAAQAcgBAOgOIAFAAIAAAKQgSAPgeAAQgdAAgSgTgAAtgIQgCgygpAAQgSAAgMAMQgNANgDAZIBZAAIAAAAg");
	this.shape_10.setTransform(31.9,44);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AApBbIAAhiQAAgbgbAAQgYAAgeAXIAABmIgNAAIAAi1IAFAAQAFAAACACQABACAAAIIAAA4QAegXAdAAQAjAAAAAkIAABkg");
	this.shape_11.setTransform(17.55,41.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgQA5IAAhgIgSAAIAAgJIASAAIAAgmIANAAIAAAmIAjAAIAAAJIgjAAIAABeQAAAMAFAFQAFAEAMABIAQAAIAAAJQgIABgMAAQgfAAAAgeg");
	this.shape_12.setTransform(5.8,42.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AguA5IAAgMIAGAAQAOAOAYAAQAjAAAAgdQAAgMgHgGQgIgGgUgDQgUgDgKgHQgMgJAAgQQAAgRANgKQAMgJAUAAQAXAAAQAKIAAALIgGAAQgNgLgUAAQghAAAAAZQAAALAIAGQAHAFAUAEQAWAEAKAGQAMAJAAARQAAAogxAAQgaAAgSgMg");
	this.shape_13.setTransform(64.35,16);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgKAMQAKgCAAgIQAAgCgFgDQgDgCAAgGQAAgIAJAAQAJAAABANQAAAWgVAEg");
	this.shape_14.setTransform(56.35,6.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAkBEIgjhyIgBAAIgiByIgMAAIgoiCIAAgFIAMAAIAiBzIABAAIAkhzIAKAAIAjBzIAAAAIAihzIALAAIAAAFIgnCCg");
	this.shape_15.setTransform(44.475,16.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgtAzQgRgTAAggQAAgfARgSQASgTAbAAQAdAAARATQARASAAAfQAAAggRATQgRASgdAAQgbAAgSgSgAgkgqQgNAQABAaQgBAcANAPQAOAQAWAAQAYAAAMgQQAOgPAAgcQAAgagOgQQgNgQgXAAQgWAAgOAQg");
	this.shape_16.setTransform(27.35,16);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AA1BbIhoiiIgBAAIAACiIgNAAIAAi1IARAAIBkCcIABAAIAAicIANAAIAAC1g");
	this.shape_17.setTransform(10.825,13.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_nowstime, rect = new cjs.Rectangle(0,0,98.9,86), [rect]);


(lib.mc_logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhsBlQgpgqAAg7QAAg7ApgqQApgqA5AAQAuAAAmAdIAAgXIBMAAIAAEUIhMAAIAAgaQgoAfgsAAQg5AAgpgrgAg0g0QgVAVAAAfQAAAeAVAVQAWAWAeAAQAeAAAWgWQAVgVAAgeQAAgegVgWQgWgWgeAAQgeAAgWAWg");
	this.shape.setTransform(162.65,56.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhdCNIAAkUIBMAAIAAAYQAWgWAggGQAbgFAdAIIAABIQgagDgVADQgYAEgUAVQgTAWAAAaIAACEg");
	this.shape_1.setTransform(138.05,56.3038);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AB6DAIglhBIipAAIglBBIhjAAIDcl/IDdF/gAArA3IgrhKIgqBKIBVAAg");
	this.shape_2.setTransform(106.15,51.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Aj7FhIGWrBIBhCnIk2Iag");
	this.shape_3.setTransform(25.175,35.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhdhRIC7AAIheCjg");
	this.shape_4.setTransform(50.775,43.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhdBRIBdihIBeChg");
	this.shape_5.setTransform(61.45,43.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhdhRIC7AAIheCjg");
	this.shape_6.setTransform(61.45,61.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhdhRIC7AAIheCjg");
	this.shape_7.setTransform(40.1,61.725);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhdBSIBdijIBeCjg");
	this.shape_8.setTransform(72.1,62.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhdBSIBdijIBeCjg");
	this.shape_9.setTransform(50.775,62.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_logo, rect = new cjs.Rectangle(0,0,177.7,71), [rect]);


(lib.mc_headline = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiOCkIAAlHIB/AAQBAAAAwAvQAuAuAABCIAAAJQAABCguAuQgwAvhAAAgAiLChIB8AAQBAAAAugtQAtguAAhBIAAgJQAAhBgtgtQguguhAAAIh8AAg");
	this.shape.setTransform(-120.25,-23.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah8CQIAAkfIBuAAQA5AAApApQApApAAA6IAAAIQAAA6gpAoQgoApg6AAgAhSBpIBBAAQApAAAegeQAdgdAAgrIAAgFQAAgqgdgeQgegegpAAIhBAAg");
	this.shape_1.setTransform(-120.25,-23.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag4CjIAAgQIAbAAQAGAAAEgFQAFgFAAgGIAAkEQAAgFgFgGQgEgFgGAAIgbAAIAAgRIBxAAIAAARIgbAAQgGAAgFAFQgFAGAAAFIAAEEQAAAFAFAGQAFAFAGAAIAbAAIAAAQg");
	this.shape_2.setTransform(-98.7,-22.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgVB4IAAjvIArAAIAADvg");
	this.shape_3.setTransform(-86.275,-22.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhBAWIAAgrICDAAIAAArg");
	this.shape_4.setTransform(-77.55,-8.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAWA3IAAhBIhWAAIAAgsICBAAIAABtg");
	this.shape_5.setTransform(-73.2,-16.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhBAWIAAgrICDAAIAAArg");
	this.shape_6.setTransform(-77.55,-37.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgVAWIAAgrIArAAIAAArg");
	this.shape_7.setTransform(-68.825,-32.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAjCjIA1g2IgSA2gAgQCjIAzg2IAjAAIg0A2gAhFCjIBohsIgRA2Ig0A2gAhFBtIAjAAIg1A2gAgiBtgAgQA3IAzg3IgRA3Ig0A2gAgQAAIAzg1IgRA1Ig0A3gAgQg1IAzg3IgRA3Ig0A1gAgQhsIAzg2IAjAAIhoBtgAAjhsIA0g2IgRA2gAhFhsIA0g2IAiAAIgzA2gAhGiiIAkAAIg1A2g");
	this.shape_8.setTransform(-54.05,-22.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AggCkIAAkFIhBAAIAAhCIDDAAIAABCIhBAAIAAEFg");
	this.shape_9.setTransform(-32.375,-22.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("ABuClQgOAAgGgJIgZg3IhjAAIgVA5QgDAHgNAAIg/AAQgIAAAAgFIABgIIBxkuQAFgOAPAAQAOAAAGAOICCEvIABAGQAAAGgLAAgAAGgaIgaBMIgBADQAAAEAFAAIA6AAQAFAAAAgEIAAgCIgihNQAAgBgBAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAABgBAAQAAABAAAAg");
	this.shape_10.setTransform(-8.3,-22.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_11.setTransform(28.975,-8.625);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_12.setTransform(23.275,-8.625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_13.setTransform(17.55,-8.625);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_14.setTransform(11.825,-8.625);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_15.setTransform(11.825,-14.375);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_16.setTransform(11.825,-20.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_17.setTransform(11.825,-25.825);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_18.setTransform(11.825,-31.525);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_19.setTransform(11.825,-37.275);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AheCjQgHAAgGgEQgEgFAAgHIAAgvQAAgHAEgEQAGgFAHAAIAsAAIAAinIgsAAQgHAAgGgEQgEgFAAgHIAAgvQAAgHAEgFQAGgEAHAAIC+AAQAHAAAEAEQAFAFAAAHIAAAvQAAAHgFAFQgEAEgHAAIgsAAIAACnIAsAAQAHAAAEAFQAFAFAAAGIAAAvQAAAHgFAFQgEAEgHAAg");
	this.shape_20.setTransform(-123.3,19.575);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("ABGCkIAAlHIAkAAIAAFHgAhpCkIAAlHIAjAAIAAFHgAgzhFIAAhZIBnDNIAABWg");
	this.shape_21.setTransform(-97.2,19.55);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("ABcCkIiijDIAADDIhGAAIAAlHIA1AAICfDEIAAjEIBEAAIAAFHgABmCOIASAAIAAkbIgbAAIAADqIi+jqIgVAAIAAEbIAaAAIAAjog");
	this.shape_22.setTransform(-68.45,19.55);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgNCgQgFADgIAAQgLAAgGgIIgGABQgKAAgGgHQgHgGAAgJQgFgBgEgDQgFADgEAAQgKAAgHgHQgHgHAAgJIABgEQgJgGAAgMIAAAAQgEgGAAgHIABgGQgMgHAAgNQAAgJAIgIQgCgDAAgFQgKgHAAgMQAAgGAFgGIgBgDQAAgLAIgGQgGgGAAgKQAAgKAHgHIgBgGQAAgIAFgGQAFgGAHgCQgDgFAAgHQAAgIAFgHQAGgGAIgBQACgPAOgFQAEgNANgDQAHgHAKAAIAGABQAGgFAIAAQAGAAAEACQAFgDAHAAQAIAAAGAGQAGgFAIAAQAMAAAHAKIAGgBQAQAAAFAOQAMAAAHALIADAAQAJAAAHAHQAHAGAAAKIgBAFQAJAGAAAMQAAAGgCAEQAIACAEAGQAFAHAAAHQAAAGgDAGQADAGAAAFQAAAEgCAFIACAHQAEAGAAAHQAAAFgCADIACAJQAAAHgEAGIAAADQAAAEgCAFQACAFAAADQAAANgLAHQgBALgLAGIgBADIACAJQAAAJgGAHQgGAGgJABQgGAKgLACQAAAJgHAHQgGAHgKAAQgHAAgFgEQgEACgGAAIgEAAQAAAJgHAGQgHAGgJAAQgMAAgHgLgAgNB5QAHgHAJAAQAHAAADACQAGgKALgCQADgHAFgEQAHgFAHAAIAHABQAEgDAGgDIAAgEQAAgOAMgHQACgKAJgGIABgFQgBgEAAgFQAAgHAEgGIAAgDIABgJQgBgDAAgEQgEgGAAgHQAAgEABgEQgBgEAAgFIABgHQgNgGAAgPQAAgGADgGQgGgGAAgJIAAAAQgNgBgGgNQgGgEgDgHIgGAAQgEACgGAAQgMAAgGgKQgFADgHAAQgHAAgFgDQgHAHgKAAQgHAAgGgFIgCABIgJAGQgCAFgFAFIABAGQAAAPgOAGIABAGQAAAIgGAHQgGAHgJABQALAHAAAMQAAANgMAHQAAAGgEAEIABADIAAABQAJAHAAALIAAAEQACAFAAAFQAAALgHAGQAKAIAAAMIAAAAQAEAGAAAHIAAACQAEgCAFAAQAJAAAHAHQAGAGABAJQAHACAFAGIAGgBQAHAAAGAEg");
	this.shape_23.setTransform(-37.125,19.575);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgNCjIhskhQgCgHgHgGQgGgGgHAAIgMAAIAAgRIBoAAIAAARIgvAAIBvE0gAALBwIBUjlQAKgcgZAAIgYAAIAAgRIBkAAIAAARIgLAAQgHAAgHAFQgGAGgDAIIhlEMg");
	this.shape_24.setTransform(-9.95,19.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("ABcClIAAAAIAAhkIgDAAIAAgHIADAAIAAgGIACAAIAAgEIgkAAIAAAEIgFAAIAAgEIhpAAIAAAEIgGAAIAAgEIgkAAIAAAEIADAAIAAAGIADAAIAAAHIgDAAIAABkIAAAAQgFACgHAAIgCAAIgKgCIAAhkIgDAAIAAgHIADAAIAAgGIACAAIAAgbIgCAAIAAgHIgDAAIAAgGIADAAIAAhHIgDAAIAAgFIADAAIAAgKIACAAIAAgDQABgGAFgFIAEgCIgCgDIAGgEIgCgCIAEgEIACADIBHg4IgCgCIAEgDIACACIAHgGIADADIABgBQADgDAGgBQAGABAEADIABABIACgDIAHAGIACgCIAFADIgCACIBHA4IACgDIAEAEIgBACIAFAEIgCADIAEACQAGAFgBAGIAAADIADAAIAAAKIADAAIAAAFIgDAAIAABHIADAAIAAAGIgDAAIAAAHIgDAAIAAAbIADAAIAAAGIADAAIAAAHIgDAAIAABkIAAAAIgLACQgJAAgEgCgAhwBfIAAAGQAAABAAAAQAAAAAAABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAgBAAAAQAAAAAAgBIAAgGIgCgBQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAAAgAhwA5IAAAhQAAAAAAAAQAAAAAAABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAgBAAAAQAAAAAAAAIAAghIgCgBQAAAAAAABQAAAAgBAAQAAAAAAAAQAAAAAAAAgAARAiQAAAAAAAAQAAAAAAABQAAAAAAAAQABAAAAAAIAgAAQAAAAABAAQAAAAAAAAQAAgBAAAAQABAAAAAAIgCgCIggAAQAAAAgBAAQAAAAAAAAQAAABAAAAQAAAAAAABgAAEAiQAAAAABAAQAAAAAAABQAAAAAAAAQABAAAAAAIAGAAQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQgBAAAAAAIgGAAQAAAAgBAAQAAAAAAAAQAAABAAAAQgBAAAAABgAA6AZIAAADIAkAAIAAgDIgCAAIAAgHIgDAAIAAgGIADAAIAAhHIgDAAIAAgFIADAAIAAgLIgGgEIgCACIgEgCIACgDIhHg3IgCADIgEgEIACgCIgHgFIAAAAIgGAFIACACIgEAEIgCgDIhHA3IACADIgFACIgCgCIgFAEIAAALIADAAIAAAFIgDAAIAABHIADAAIAAAGIgDAAIAAAHIgDAAIAAADIAkAAIAAgDIAGAAIAAADIBpAAIAAgDgABfgbIAAAFQAAABABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABgBIAAgFQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAABAAAAQgBAAAAABgAhwgbIAAAFQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIACgBIAAgFQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAABgABfhCIAAAgQAAABABAAQAAAAAAABQAAAAAAAAQABAAAAAAIABgCIAAggQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAABAAAAQgBAAAAAAgAhwhCIAAAgQAAABAAAAQAAAAAAABQABAAAAAAQAAAAAAAAIACgCIAAggQAAAAAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAAAgAhnhVQgDABgBACQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAgBAAAAQAAgEADAAIABgBIAAgBIgBgCIgBABgAAEigIACAAIABgBIgBgBQgCgCgEAAIgFACQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAIABAAIABAAQAAAAABAAQAAAAAAgBQABAAAAAAQABAAAAAAQAAAAABAAQABAAAAAAQABABAAAAQABAAAAAAg");
	this.shape_25.setTransform(16.8,19.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgFAHQgDgDAAgEQAAgDADgDQACgCADAAQAEAAADACQACADAAADQAAAEgCADQgDACgEAAQgDAAgCgCg");
	this.shape_26.setTransform(16.775,15.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgLCiIgGgDQgEgBAAgDIgBgLQgCgKgDh7IgCgvQAAgOACg1IgBgCIgBAAQgcgBg+gFQgEgBgBgBIgCgDQAAgGAGgBIABAAIAAgKQgHAAAAgEIADgUQABgEAEgBQAZgHBrAGIBpAHQAFAAABAFIACASIgBADIgDACIgEAAIgBALIAEACIACACQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAIgCAEIgBABIhkAAIgBABIAIBpQABAUgBBIIAAAjIgCAjIAAAAIgCACQgDACgDAAIgDAAIgFAAIgBAAIAAAAIgBAAIgCABQgEAAgNgFgAAKCgIABABIAEACIADAAIABgNIgKAAgAAFhNIgBACQAFBPgCATQgBATAAAqQgBArACADQAFAAAHgCQABAAAAgBQAAAAAAAAQABAAAAgBQAAAAAAgBQgGhfABgTQACgNgDhKQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAIgFAAgAAEhgIAJACIAAAAIAAgOIAAAAIgJgBgAhniEIAAALIDNAEIAAgNQhzgEg0AAQgeAAgIACg");
	this.shape_27.setTransform(41.5714,19.881);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AhwB4QgjgsAAhMQABgyARgfQAOgaAggZQAZgRAVgIQAXgJAdABQCEAAABCWQAAA2gTAmQgPAegfAaQgXASgVAIQgWAIgZAAQhDgBglgugAg/huQgRAZAAA8QAABRAZAoQAYAmAvAAQAQAAAJgDQALgFAIgLQAVgfAAhMQAAhLgXghQgXgfgwAAQghAAgRAVg");
	this.shape_28.setTransform(68.7,19.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgqDFQgJgCgGgCIgOgFQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAIgCgHIABgJQACgIgBgEIgFgXIgIgZQgDgGADgXIADgbIgGgSIgFgTIgCgMIgHgPQgBgGAAgGIABgFIgGgEQAOgtABgIQAAgHgGgWQgCgGAAgFIAAgEQgBgHAFgIIAIgKQAEgEAZgNQAEgDACgFIAFgHIAIgGQAEgCAEgBIgBgBQACgBAEABIAAgCQACAAADAFQADgEADAEIAAAAIAEAGQACABADAIIgBAIQAAABABABQAAAAAAABQABAAAAAAQABABABAAQAAAGgEADQgBAAAAAAQgBAAgBABQAAAAgBAAQAAAAgBAAIgBgBIgDADIAEABQAEACAHgEQABAAAAAAQABAAAAgBQAAAAAAgBQAAgBAAgBQgDgHAFgEIADgEQAHgDALAHIAMAHIAIACIAKAAIAMACQAMAEAGAMQACAFAIACQAGAEgBAGQgBgCgDgEQgEgCgCAAIADAFIAEAEQAHAIgBAIQgDgJgIgFIADAHQACAFgCADIgCgGIAAAEIAAAAQgBAJAFAHQgEgCgCgEIgBABQgEALgCAPQgNAsgOAHQgLAGgYAAIgUAAIgCAGIAQAVIAEAAIAFAAIABAAQABAAAAABQAAAAAAAAQABAAAAABQAAAAAAABIAAAGIgBACIADACIABAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAIAAAJIADAGIADAFQABACABAFIACAGIACAAIAIADQAHAEAEAIQABADgCADIAEACIAFAAQADABAFAEQAEADACAEQAFAJgEAKIgBgHIgBAJIgBAGQAAgBgBAAQAAAAAAAAQAAABgBAAQAAABAAABQAAADACACIADAGIABAAIAEAGQABACAGACIADACIADAAQAAABABAAQAAAAgBAAQAAAAAAABQAAAAgBAAIABABQAAAAAAAAQAAABAAAAQAAAAgBAAQAAAAgBABQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAIgDgCIgEgCQgBAAAAAAQgBAAAAAAQAAABABAAQAAABABABIACADIAHAHIABABIAGAHQADADAGADQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAgBAAIgCACQAAAAAAAAQAAAAgBAAQAAAAgBAAQgBABgCAAIgFgDIgEgDIgBgBIACAGQABAAAAAAQAAABAAAAQAAAAAAAAQAAABgBAAQgDAAgCgFIgDgFIgHgHIgFgJIgLgJIgDAAQgBABAAAAQgBAAAAABQAAAAAAABQAAAAAAABIABADQgEgDAAgEIACgDQgBgBAAAAQgBAAgBgBQAAAAAAAAQgBABAAAAIgCAEIAAgBQgBgEABgCIADgDIgPgSQAAABAAABQAAAAAAABQgBAAAAABQgBAAAAAAQgEAAgEAFIgBgCQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAABgBQAAAAAAAAQABAAAAgBQAAAAAAgBQAAgBAAgBQgBABAAAAQgBAAAAAAQAAAAgBgBQAAAAAAAAIgBgBQAGACABgGQAAgBgCgGIgEgCIgGgDIgBgBIgBgEQAAgBgBAAQAAgBAAAAQgBAAAAAAQgBgBgBAAIgGgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIABgCIgDgEQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAAAQgDgCACgGIADgCIADgBQABgCgEgCQgLgEgIgFQgFgCgFgHIgHgJQgHgHgEgHQAAgBgBAAQAAgBgBAAQAAAAgBAAQgBAAAAAAQgBABAAAAQgBAAAAABQAAAAgBABQAAAAAAABIgDAPIgDAUIgEALQABAEgCAFIgBAgQgBAIACAHIADADIAMALIAPAGQAAADgFACIgLABIAHADIAFAEIgIgDIANAFQADACADADQAAABABAAQAAABAAAAQAAABAAAAQAAAAgBAAQgGACgGAAIgNgBIgFgCIAXAQQAFADACADQAAADgHADIgHABIgJgBgAgriHIgGABIgCACIgBACIgCACQAHAKABAMIAAAQIgCASIgCASQAKAJAIADIADgEIALgFQANgFAHAAQAQgCACgCQAFgDAKgaQACgDgDgFQgCgEAAgCIgDgFQgEgDABgCIACgJIgGAAQAAABgBAAQAAABAAAAQAAAAgBAAQAAABAAAAQgBAAgFgEIgGgBIgEgBIgDgCQgJgFgLgCIgUgDg");
	this.shape_29.setTransform(96.875,19.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgECmQg8AAg6gcQgIgDADgJIATgpQACgFAHAAIAEAAQA0AZAoABQA8AAABgiQAAgbgTgRQgJgIgggRQgdgOgMgMQgTgSABgdQAAgWASgPQAUgPAlAAQAjAAAlAPIALgZQgigOgxgBQgsgBgdAUQggAUgBAmQAAA7A6AbQAFADAAAFQAAADgDADQgDADgEAAIgFgBQhFghABhFQABgvAngZQAjgYAzABQAiAAAZAGQAUAFAVAKQAJAEgEAHIgSArQgCAFgHAAIgEgBQgmgRgkgBQg2gBgBAkQAAAWAPAOQAJAJAYANQAlARALALQAXAWAAAhQAAAVgPANQgUASguAAQgpgBgygWIgKAYQAwAXA0AAQAvABAegQQAjgUAAgoQABgjgSgYQgRgYgngRQgGgDAAgFQAAgFAFgDQAFgCAFACQBWAlgBBPQgBAugmAYQgiAXg4AAIgEAAg");
	this.shape_30.setTransform(121.6752,19.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_headline, rect = new cjs.Rectangle(-134.5,-39.5,269.1,79), [rect]);


(lib.mc_course = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKAAQAAgDADgDQADgEAEAAQAEAAAEAEQADADAAADQAAAFgDADQgEADgEAAQgKAAAAgLg");
	this.shape.setTransform(164.225,90.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgbBgIAAgFIAXgzIg7iCIAAgFIAOAAIAyB3IAyh3IAMAAIAAAFIhNC6g");
	this.shape_1.setTransform(154.5,86.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgGBiIAAjDIAFAAQAFAAABADQACABAAAJIAAC2g");
	this.shape_2.setTransform(144.1,81.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag4AkIAAhtIAOAAIAABsQAAAbAbAAQAaAAAggXIAAhwIAOAAIAACRIgGAAQgFAAgBgCQgCgDAAgKIAAgGQgeAXgeAAQgnAAAAgmg");
	this.shape_3.setTransform(132.925,84.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgrBYIAAgMIAGAAQALALAUAAQAiAAAAgjIAAiWIAQAAIAACWQgBAvgvAAQgYAAgPgLg");
	this.shape_4.setTransform(118.05,81.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAsBKIAAhqQAAgdgdAAQgaAAggAZIAABuIgOAAIAAiRIAHAAQAEAAABACQACADAAAKIAAAIQAfgZAhAAQAlAAAAAnIAABsg");
	this.shape_5.setTransform(97.55,84.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgGBeIAAiRIAEAAQAGAAABACQACADAAAKIAACCgAgIhTQgBgEADgDQADgDADAAQAEAAADADQACADAAAEQAAAJgJAAQgIAAAAgJg");
	this.shape_6.setTransform(86.35,82.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgRA9IAAhmIgTAAIAAgLIATAAIAAgpIANAAIAAApIAnAAIAAALIgnAAIAABkQAAANAGAGQAFAEAOAAIAQAAIAAAKQgJACgMAAQghAAAAghg");
	this.shape_7.setTransform(201.55,48.725);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AghBJIAAiRIAGAAQAFABABACQACADAAALIAAAJQAVgaAagBIAGABIAAAMIgGgBQgZAAgWAcIAABqg");
	this.shape_8.setTransform(192.625,50.65);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgpBAQgOgMAAgUQAAgVARgLQAPgJAaAAQAVAAARADIAAgaQABgeglAAQgcgBgQANIgGAAIAAgLQAYgMAbAAQAxAAABAoIAABqIgFAAQgGAAgCgCQgCgEAAgIIAAgGQgUAWgcgBQgWABgMgLgAgoAfQAAAgAjABQAbAAATgZIAAgjQgTgEgSAAQgsAAAAAfg");
	this.shape_9.setTransform(179.1,50.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgRA9IAAhmIgTAAIAAgLIATAAIAAgpIAOAAIAAApIAmAAIAAALIgmAAIAABkQgBANAGAGQAFAEAOAAIAQAAIAAAKQgIACgNAAQghAAAAghg");
	this.shape_10.setTransform(167.9,48.725);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgxA9IAAgMIAFAAQAQAOAaAAQAmAAAAgfQAAgNgJgGQgIgGgVgEQgWgDgMgIQgMgJAAgSQAAgSANgKQAOgKAVAAQAaAAARALIAAALIgGAAQgOgLgXAAQgiAAgBAaQAAANAJAGQAIAGAUADQAZAEAKAHQANAKAAASQAAArg0AAQgdAAgSgNg");
	this.shape_11.setTransform(157.2,50.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgxA9IAAgMIAGAAQAPAOAZAAQAnAAAAgfQAAgNgIgGQgJgGgVgEQgXgDgLgIQgMgJAAgSQAAgSAOgKQANgKAVAAQAaAAAQALIAAALIgFAAQgOgLgWAAQgjAAAAAaQgBANAJAGQAIAGAVADQAYAEALAHQAMAKAAASQAAArg0AAQgcAAgTgNg");
	this.shape_12.setTransform(137.25,50.675);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgsA3QgRgUAAgiQAAghASgVQASgUAbAAQAcAAAQAQQAQASAAAiIAAAGIhtAAQAAA+A2AAQAeAAAQgPIAGAAIAAAKQgVAQggAAQggAAgSgTgAAwgJQgBg2gtAAQgUAAgNAOQgNAOgDAaIBfAAIAAAAg");
	this.shape_13.setTransform(123.525,50.675);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgsA3QgRgUAAgiQAAghASgVQASgUAbAAQAcAAAQAQQAQASAAAiIAAAGIhtAAQAAA+A2AAQAeAAAQgPIAGAAIAAAKQgVAQggAAQggAAgSgTgAAwgJQgBg2gtAAQgUAAgNAOQgNAOgDAaIBfAAIAAAAg");
	this.shape_14.setTransform(108.625,50.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AghBJIAAiRIAGAAQAFABABACQACADAAALIAAAJQAVgaAagBIAGABIAAAMIgGgBQgZAAgWAcIAABqg");
	this.shape_15.setTransform(96.625,50.65);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ag2BUIAAgLIAGAAQAQANAgAAQAwAAAAgmIAAgZQgVAaggAAQgYAAgPgPQgSgTAAgkQAAgnAUgTQARgRAZAAQAfAAARASQACgRAIAAIAFAAIAACQQAAAXgSANQgRAMgbAAQgiAAgVgNgAgfhIQgQAPAAAjQAAAgAOAQQALAMATAAQAdABAWgeIAAhKQgSgUgbAAQgVAAgNANg");
	this.shape_16.setTransform(82.275,52.95);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgsA3QgRgUAAgiQAAghASgVQASgUAbAAQAcAAAQAQQAQASAAAiIAAAGIhtAAQAAA+A2AAQAeAAAQgPIAGAAIAAAKQgVAQggAAQggAAgSgTgAAwgJQgBg2gtAAQgUAAgNAOQgNAOgDAaIBfAAIAAAAg");
	this.shape_17.setTransform(67.325,50.675);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgsBTQgSgUAAglQAAgmAUgUQARgRAZAAQAfAAARASIAAhCIAFAAQAGAAACACQACACAAAJIAAC1IgIAAQgEAAgBgDIgCgNIAAgIQgUAaggAAQgZAAgPgQgAgfgZQgQAQAAAiQAAAiAOAQQALAMATAAQAeAAAVgdIAAhNQgSgTgcAAQgVAAgMANg");
	this.shape_18.setTransform(51.175,48.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgGBiIAAi3IhBAAIAAgMICPAAIAAAMIhAAAIAAC3g");
	this.shape_19.setTransform(188.025,14.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgyBKQgYgcAAguQAAguAagbQAYgZAjAAQAXAAANAFQAMAFANAKIAAALIgHAAQgUgTghAAQgeAAgUAWQgUAXAAApQAAApASAYQATAWAgAAQAiAAAXgXIAGAAIAAALQgZAYgnAAQgmAAgWgZg");
	this.shape_20.setTransform(171.2,14.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgHBiIAAjDIAPAAIAADDg");
	this.shape_21.setTransform(158.575,14.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgsA3QgRgUAAgiQAAghASgVQASgUAbAAQAcAAAQAQQAQASAAAiIAAAGIhtAAQAAA+A2AAQAeAAAQgPIAGAAIAAAKQgVAQggAAQggAAgSgTgAAwgJQgBg2gtAAQgUAAgNAOQgNAOgDAaIBfAAIAAAAg");
	this.shape_22.setTransform(140.275,17.075);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgGBiIAAjDIAFAAQAFAAACACQABADAAAIIAAC2g");
	this.shape_23.setTransform(129.75,14.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgwBRQgCARgIgBIgEAAIAAjDIAFAAQAGAAACADQABACAAAJIAAA/QAYgcAfAAQAYAAAOAPQASATAAAmQAAAogUATQgRARgagBQgdABgTgSgAgwgIIAABNQASASAdAAQAUABANgNQARgRAAgiQAAghgPgQQgLgNgSABQgcAAgZAdg");
	this.shape_24.setTransform(119.125,14.65);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgGBeIAAiRIAEAAQAFAAACACQACADgBAKIAACCgAgJhTQAAgEADgDQADgDADAAQAEAAACADQADADAAAEQABAJgKAAQgJAAAAgJg");
	this.shape_25.setTransform(107.45,15.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAvBJIgvhEIgvBEIgLAAIAAgFIAwhGIguhBIAAgFIAMAAIAsA9IApg9IALAAIAAAFIgsBBIAzBGIAAAFg");
	this.shape_26.setTransform(97.325,17.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgsA3QgRgUAAgiQAAghASgVQASgUAbAAQAcAAAQAQQAQASAAAiIAAAGIhtAAQAAA+A2AAQAeAAAQgPIAGAAIAAAKQgVAQggAAQggAAgSgTgAAwgJQgBg2gtAAQgUAAgNAOQgNAOgDAaIBfAAIAAAAg");
	this.shape_27.setTransform(82.875,17.075);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgGBiIAAjDIAFAAQAFAAACACQABADAAAIIAAC2g");
	this.shape_28.setTransform(72.35,14.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("Ag6BiIAAjDIB0AAIAAAMIhkAAIAABRIBKAAIAAAMIhKAAIAABag");
	this.shape_29.setTransform(62.2,14.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_course, rect = new cjs.Rectangle(38.2,0,174,99.2), [rect]);


(lib.mc_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_bg, rect = new cjs.Rectangle(0,0,300,600), [rect]);


(lib.mc_applynow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F94B8").s().p("AAkBEIgjhyIgBAAIgiByIgMAAIgoiCIAAgFIAMAAIAiBzIABAAIAkhzIAKAAIAjBzIAAAAIAihzIALAAIAAAFIgnCCg");
	this.shape.setTransform(145.825,25.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F94B8").s().p("AgtAyQgRgSAAggQAAgeARgUQASgSAbAAQAdAAARASQARAUAAAeQAAAggRASQgRATgdAAQgbAAgSgTgAgkgqQgNAPABAbQgBAcANAQQAOAPAWAAQAYAAANgPQANgQAAgcQAAgbgNgPQgOgQgXAAQgWAAgOAQg");
	this.shape_1.setTransform(128.7,25.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F94B8").s().p("AApBFIAAhjQAAgbgbABQgYAAgeAWIAABnIgNAAIAAiHIAGAAQAFAAABACQABADAAAIIAAAIQAegWAdAAQAjAAAAAkIAABkg");
	this.shape_2.setTransform(113.85,25.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F94B8").s().p("AgYBZIAAgEIAUgwIg2h5IAAgEIAMAAIAwBuIAuhuIALAAIAAAEIhICtg");
	this.shape_3.setTransform(92.6,28.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F94B8").s().p("AgGBbIAAi1IAFAAQAFAAABACQABACABAJIAACog");
	this.shape_4.setTransform(82.95,23.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F94B8").s().p("Ag5BaIAAixIAGAAQAEAAACACQABADAAAIIAAALQAWgZAcAAQAXAAANANQAQASAAAjQAAAkgSATQgPAPgZAAQgaAAgSgQIAAA6gAgsgyIAABGQAQARAbABQATgBAMgMQAPgOAAgfQAAgggNgPQgKgLgSAAQgZAAgXAcg");
	this.shape_5.setTransform(73.075,28);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F94B8").s().p("Ag5BaIAAixIAGAAQAEAAACACQABADAAAIIAAALQAWgZAcAAQAXAAANANQAQASAAAjQAAAkgSATQgPAPgZAAQgaAAgSgQIAAA6gAgsgyIAABGQAQARAbABQATgBAMgMQAPgOAAgfQAAgggNgPQgKgLgSAAQgZAAgXAcg");
	this.shape_6.setTransform(58.075,28);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2F94B8").s().p("AA7BbIgUg5IhOAAIgUA5IgMAAIAAgFIBAiwIAPAAIBACwIAAAFgAAjAXIgjhhIAAAAIgjBhIBGAAg");
	this.shape_7.setTransform(41.85,23.65);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ArEDwQhkAAhGhHQhGhGAAhjQAAhiBGhHQBGhGBkAAIWJAAQBkAABGBHQBHBGAABiQAABjhHBGQhGBHhkAAg");
	this.shape_8.setTransform(94.95,23.9748);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_applynow, rect = new cjs.Rectangle(0,0,189.9,48), [rect]);


(lib.clicktag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgbMAw7MAAAhh1MA2ZAAAMAAABh1g");
	this.shape.setTransform(174.05,313.075);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = null;
p.frameBounds = [rect, rect, rect, new cjs.Rectangle(0,0,348.1,626.2)];


// stage content:
(lib._04626_S2_DigiInnovators_DigiAd_300x600 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* Click to Go to Web Page
		Clicking on the specified symbol instance loads the URL in a new browser window.
		
		Instructions:
		1. Replace http://www.adobe.com with the desired URL address.
		   Keep the quotation marks ("").
		*/
		
		this.clicktag.addEventListener("click", fl_ClickToGoToWebPage_2);
		
		function fl_ClickToGoToWebPage_2() {
			window.open(window.clicktag);
		}
	}
	this.frame_177 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
		
		/* Click to Go to Web Page
		Clicking on the specified symbol instance loads the URL in a new browser window.
		
		Instructions:
		1. Replace http://www.adobe.com with the desired URL address.
		   Keep the quotation marks ("").
		*/
		
		this.clicktag.addEventListener("click", fl_ClickToGoToWebPage_2);
		
		function fl_ClickToGoToWebPage_2() {
			window.open(window.clicktag);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(177).call(this.frame_177).wait(1));

	// clicktag
	this.clicktag = new lib.clicktag();
	this.clicktag.name = "clicktag";
	this.clicktag.parent = this;
	this.clicktag.setTransform(144.1,297.1,1,1,0,0,0,174.1,313.1);
	new cjs.ButtonHelper(this.clicktag, 0, 1, 2, false, new lib.clicktag(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clicktag).wait(178));

	// Logo
	this.mc_logo = new lib.mc_logo();
	this.mc_logo.name = "mc_logo";
	this.mc_logo.parent = this;
	this.mc_logo.setTransform(149.95,524.75,1,1,0,0,0,88.8,35.5);
	this.mc_logo.alpha = 0;
	this.mc_logo._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_logo).wait(124).to({_off:false},0).to({alpha:1},17,cjs.Ease.get(1)).wait(37));

	// ApplyNow
	this.mc_applynow = new lib.mc_applynow();
	this.mc_applynow.name = "mc_applynow";
	this.mc_applynow.parent = this;
	this.mc_applynow.setTransform(149.95,329.15,0.8575,0.8575,0,0,0,95.2,24.2);
	this.mc_applynow.alpha = 0;
	this.mc_applynow._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_applynow).wait(135).to({_off:false},0).to({regX:95,regY:23.9,scaleX:1,scaleY:1,x:149.8,y:328.9,alpha:1},14,cjs.Ease.get(1)).wait(29));

	// CourseSpec
	this.mc_course = new lib.mc_course();
	this.mc_course.name = "mc_course";
	this.mc_course.parent = this;
	this.mc_course.setTransform(149.4,184.95,1,1,0,0,0,125.2,49.6);
	this.mc_course.alpha = 0;
	this.mc_course._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_course).wait(124).to({_off:false},0).to({alpha:1},15,cjs.Ease.get(1)).wait(39));

	// NowsTime
	this.mc_nowstime = new lib.mc_nowstime();
	this.mc_nowstime.name = "mc_nowstime";
	this.mc_nowstime.parent = this;
	this.mc_nowstime.setTransform(80.8,227.35,1,1,0,0,0,67.9,29);
	this.mc_nowstime.alpha = 0;
	this.mc_nowstime._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_nowstime).wait(59).to({_off:false},0).to({alpha:1},9,cjs.Ease.get(1)).wait(37).to({alpha:0},16,cjs.Ease.get(1)).to({_off:true},1).wait(56));

	// 2-D
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgCCkIAAgCIg4AAIAAAEIh6gEIACgiIAHgDIAOAAIAFgBIAbABIAAgDIgEAAIAAgwIACAAIAAggIgDAAIAAgiIADAAIAAgqIgDgCIAAgkIAIAAIAAgcIgHAAIAAgGIgFAAIgBgDIABgOIgOACIgBgCIgWADIgJgJIgCghIAaAAIAAACIAWAAIAAgDIAigBIAAgCIAWAAIADADIAuABIAAgBIARAAIAAgBIATAAIAAAFIAtACIAAATIALgXIA+AlIgDAGIAKAHIACgDIAMAHIgFAKIALAHIgCAFIAZALIgEACIAIAWIgQAIIAMAcIgHAEIAPAbIgPAHIADAHIACAAIAFADIgKAMIAGAMIgIAEIgQAwIADAFIgWALIgCAAIgNAGIAEAIIgPAIIgFgEIABAFIgfAJIgBgDIgBAAIAAAHIgkAAIgCgCIgBAHgAhAB0IAHAAIAAANIA3AAIAAgFIACgCIAcgBIACADIAAACIAPgBIgHgPIAdgOIgFgIIAagTIgMgWIAIgFIgRgaIACgCIgHgLIACgDIARgJIgMghIABgDIgHgTIgIADIAKgWIgSgJIACgFIgHgDIABgHIADgMIgKAAIAAAEIgRAAIAAgEIgfABIgBgFIgOAAIgCACIgTAAIgDAOIgIAAIAAAJIABAIIAAATIACAIIAAA7IgEAAIAAAvIgBABIAAAdIADAAIAAATIgGAAg");
	this.shape.setTransform(29.55,124.9);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4).to({_off:false},0).to({_off:true},5).wait(169));

	// 2-I
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AggCkIAAlHIBBAAIAAFHg");
	this.shape_1.setTransform(53.575,124.75);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(7).to({_off:false},0).to({_off:true},8).wait(163));

	// 2-G
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAqDVIAAgSIhDAAIAAAEQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAgBAAIgFAAQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAIAAgQQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAIAFAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABIAAAEIBDAAIAAgKIgDgDIAAAAIABgCIACgCIAAgBIgDgDIAAgBIADgDIAAgBQgBAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAIAAgBIADgDIAAgBQgBAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAIAAgBIADgDIAAgBQgBAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAIABgCIACgCIAAgBQgBAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAIABgCIACgCIAAgBIgDgDIhygQQgYgHgLgNIgDgDQgNgRgBgdIgDi7QAAgNAHgPQAHgMALgJQADgDAIgFQALgFAKgCQAPgEARAFIABABIBXAZQAGACAEAFQAEAFAAAHIgCADQgGACgKACQgLACgFgCIgEgDIgBgBIhWgHQgKAAgEADQgGAEgCAGIgBAHIAADCQAAAKAHAJQAHAIAKACIBmAOIAAAAQAAgBAAAAQAAAAAAgBQAAAAABAAQAAgBAAAAIACgCIAAgCQgDgCAAgDIABgDIACgCIAAgCQgDgCAAgDQAAAAAAAAQAAgBAAAAQAAAAABgBQAAAAAAAAIACgDIAAgBIgBgBQgCgCAAgCIABgDIACgDIAAgBIgBAAQgCgDAAgCIAAgBIAAAAIADgEIAAgCQgDgCAAgDIACgEIABgBIAAgBQgDgDAAgCQAAgBAAAAQAAgBAAAAQABgBAAAAQABgBAAAAIAAgBIABgBIAAgBQgDgCAAgDIAAAAIACgEIABgBIgJABQgDABABgDIAAgPQAAgBAAAAQAAAAAAgBQAAAAABAAQAAgBAAAAQAGgBALAAQAMAAAGACQABAAAAAAQAAAAAAABQABAAAAAAQAAABAAAAIAAAQQgBAAAAABQAAAAAAAAQgBABAAAAQgBAAAAAAIgIgBIACAEIAAAAIgBADIgCADIACADIABADIgBADIgCADIACACIABADIAAABIgBACIgCADIACADIABADIgBADIgCADIACADIABADIgBADIgCADIACADIABACIgBADIgCADIACADIABADIgBADIgCADIACADIABADIAAAAIAIAAQAAAAABAAQABABAAAAQAAAAABABQAAAAAAABQAAABAAABQgBAAAAAAQAAABgBAAQgBAAAAAAIgCAAIAAAZIACAAQAAAAABAAQABAAAAAAQAAABABAAQAAABAAABQAAABAAAAQgBABAAAAQAAABgBAAQgBAAAAAAIgIAAIgBACIgCACIACACIABACIgBACIgCACIACACIABACQAAACgDACIADADIAAABQAAABAAAAQAAAAAAABQgBAAAAABQgBAAgBABIADADIAAABIAAAAQAAABAAAAQAAABAAAAQgBABAAAAQgBAAgBABIACACIABACIAAAAIAAAAQAAABAAAAQAAABAAAAQgBABAAAAQgBAAgBABIACACIABACIAAAAIgCADIAAAKIA+AAIAAgEQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAIAGAAQAAAAABAAQAAABABAAQAAAAAAABQAAAAAAABIAAAQQAAAAAAABQAAAAAAABQgBAAAAAAQgBAAAAAAIgGAAQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAIAAgEIg+AAIAAASgAhOjIQgKADgJAGQgJAIgHAKQAAABgBAAQAAABAAAAQAAAAABABQAAAAAAAAIABABIACgBQAHgLAJgGQAGgGALgEIACgBIAAgBIgCgCIgBABg");
	this.shape_2.setTransform(75.625,128.9279);
	this.shape_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(12).to({_off:false},0).to({_off:true},7).wait(159));

	// 2-I-2
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag4CkIAAgRIAbAAQAGAAAFgFQAEgFABgGIAAkEQgBgGgEgFQgFgFgGAAIgbAAIAAgRIBxAAIAAARIgbAAQgGAAgEAFQgGAFAAAGIAAEEQAAAGAGAFQAEAFAGAAIAbAAIAAARg");
	this.shape_3.setTransform(96.9,125.05);
	this.shape_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(17).to({_off:false},0).to({_off:true},12).wait(149));

	// 2-T
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgYCjQgLAAAAgJIAAkqIhLAAIAAAZIAiAAQAEAAADACQADADAAAEQAAAEgDADQgDACgEAAIgtAAQgDAAgEgCQgDgDAAgEIAAgrQAAgEADgDQAEgCADAAIBhAAQADAAAEACQADADAAAEIAAEqIAdAAIAAkqQAAgEAEgDQADgCAEAAIBfAAQAEAAAEACQADADAAAEIAAArQAAAEgDADQgEACgEAAIgsAAQgEAAgDgCQgDgDAAgEQAAgEADgDQADgCAEAAIAiAAIAAgZIhLAAIAAEqQAAAJgKAAg");
	this.shape_4.setTransform(118.95,124.925);
	this.shape_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(22).to({_off:false},0).to({_off:true},5).wait(151));

	// 2-A
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AglAOIAKgbIBBAAIgJAbg");
	this.shape_5.setTransform(132.275,140.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AglAOIAKgbIBBAAIgJAbg");
	this.shape_6.setTransform(133.525,136.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ah4AOIAJgbIDfAAIAJAbg");
	this.shape_7.setTransform(143.125,132.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AglAOIAKgbIBBAAIgKAbg");
	this.shape_8.setTransform(137.275,125.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhsAOIAKgbIDGAAIAJAbg");
	this.shape_9.setTransform(143.125,128.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgbAOIgKgbIBCAAIAJAbg");
	this.shape_10.setTransform(153.975,140.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AglAOIAKgbIBBAAIgKAbg");
	this.shape_11.setTransform(138.525,121.375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgbAOIgKgbIBCAAIAJAbg");
	this.shape_12.setTransform(152.725,136.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgbAOIgKgbIBCAAIAJAbg");
	this.shape_13.setTransform(148.975,125.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAFAOIgFgOIgEAOIhCAAIAJgbIB7AAIAJAbg");
	this.shape_14.setTransform(143.125,117.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgbAOIgKgbIBCAAIAJAbg");
	this.shape_15.setTransform(147.725,121.375);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ag6AOIAJgbIBjAAIAJAbg");
	this.shape_16.setTransform(143.125,113.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgtAOIAJgbIBJAAIAJAbg");
	this.shape_17.setTransform(143.125,110.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]},26).to({state:[]},8).to({state:[]},67).wait(77));

	// 2-L
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AhZChIAagQIgIkjIgdgKIACgNIBmgBIADARIgbAJIgBEcIBVgTIgGgfIArgGIgCBJIi7AOg");
	this.shape_18.setTransform(167.075,125.625);
	this.shape_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_18).wait(32).to({_off:false},0).to({_off:true},4).wait(142));

	// 2-I-2_1
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ag3CjIAAgQIAaAAQAGAAAFgFQAEgGAAgFIAAkEQAAgFgEgGQgFgFgGAAIgaAAIAAgRIBvAAIAAARIgaAAQgGAAgFAFQgFAGAAAFIAAEEQAAAFAFAGQAFAFAGAAIAaAAIAAAQg");
	this.shape_19.setTransform(27.175,167.9);
	this.shape_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(38).to({_off:false},0).to({_off:true},12).wait(128));

	// 2-N
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("ABBCjIAAkEIBCAAIAAEEgAiCCjIAAkEIBCAAIAAEEgAhAhhIAAhCICBAAIAABCgAhAhhg");
	this.shape_20.setTransform(52.4,167.3);
	this.shape_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(42).to({_off:false},0).to({_off:true},7).wait(129));

	// 2-N-2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("ABGCkIAAlHIAkAAIAAFHgAhpCkIAAlHIAkAAIAAFHgAgzhGIAAhYIBnDNIAABWg");
	this.shape_21.setTransform(82.5,167.325);
	this.shape_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_21).wait(47).to({_off:false},0).to({_off:true},13).wait(118));

	// 2-O
	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhOCjQgaAAgKgcIDlAAQgKAcgaAAgAh1B+IgBgcIDtAAIAAATIgBAJgAA7BZIAAgcIA8AAIAAAcgAh2BZIAAgcIA8AAIAAAcgAA7AzIAAgcIA8AAIAAAcgAh2AzIAAgcIA8AAIAAAcgAA7AOIAAgbIA8AAIAAAbgAh2AOIAAgbIA8AAIAAAbgAA7gWIAAgcIA8AAIAAAcgAh2gWIAAgcIA8AAIAAAcgAA7g8IAAgcIA8AAIAAAcgAh2g8IAAgcIA8AAIAAAcgAh2hhIABgcIDrAAIABAJIAAATgAhyiGQAKgcAaAAICdAAQAaAAAKAcg");
	this.shape_22.setTransform(112.1,167.325);
	this.shape_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_22).wait(52).to({_off:false},0).to({_off:true},4).wait(122));

	// 2-V
	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgoCpIgCAFIgXggQgkANgMgEIAygQIAKAMIACgDQACgEAEgDIADggIAAgMIgZgGIgNAXIgGgCIgCABIgDgBIgHADIgMgXQgMAIgKADIgaAFIAqgUIAPgBIADgCIABgzIAFAuIAEACIAAgfIACgCIAAh2QAAAAAAgBQAAAAAAAAQABAAAAAAQAAgBAAAAQABAAAAABQAAAAABAAQAAAAAAAAQAAABAAAAIAAB0IAGgDIgEAJIABAjIARAAIAVAFIAAgFIgLgDIALABIAAhSQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAABSIAmACIADgMIgBgWIACgFIABABIAAgnQgJAAgDgBIAMgDIAAhMQAAAAAAgBQAAAAAAAAQABAAAAAAQAAgBAAAAQABAAAAABQAAAAABAAQAAAAAAAAQAAABAAAAIAABMIAKgDIANABIAFgqIAEAnIAAAAIAAgwIgBAAIABgGIAAgfIgEADIAEgFIAAgcQgLgCgKgDIAVgBIAAgSQAAgBABAAQAAAAAAgBQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAABAAAAQABAAAAABIAAASIAXgBIAAgkQAAAAABgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAABAAAAIAAAjIAEAAIADgEIgCgcIAFgHIADAAIABAcIABAAIAAgYQAAgBAAAAQAAAAABgBQAAAAAAAAQABAAAAAAIABAAIAAgLIAEAJQAEANgBAUIACACIADgCIA9gFIglAMIgNgCIgQAcIgLgEIgBgCIgCACIgKgOIgBAAIAAA1IAMABIAbguIABAEIgSAvIAJAAIgCASIgIgDIgGAKIgPgGIgQACIgBgCIgDAAIgEgLIgCgBIAAAxIAEAAIAHgYIABgEIADADIAOACIgLABIgFAaIAMAAIARAJIABAAIAGACIgdgEIgKAUIgKgEIgDADIgJABIgBgCIgCACIgIgYIgNABIAAApIABABIABAGIAIgVIADAFIADAoIAGACIAZgCIAcAAIgXAEIgRACIgFAAIgMAcIgDgBIgCABIgHgEIgKABIgJgTQgNgEgJAAIgLgCIAAAFIAOADQgEABgKgBIAAABIACAUIADABIAAAWIACACQAEAEABADIAKgIIA2gCQgKAFgKACQgRAEgQgBIgKALIgJARgAAwg9IgCgfIgEADIAAAbIAGABgAAzhfIAJAgIAFAAIAAg1IgXgBIAAAXIACgCIAEgBg");
	this.shape_23.setTransform(146.25,166.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AArBfIgOADIgFgWIgLADIAEgKIAFgBIAIAAIACgUIgNAAIAPgHIAEACIAEAZIAEgIIAFABIAAglIgOgEIgGAMIgOAAIAIgBIgIABIAAAAIgIABIgHgNIAFgGIgrAYIAfgeIAOgCIAGgyIADAyIAEABIAAg8IgGAAIgOAWIgFgFIAAAFIgHgHIgGACIgMgQIgvABIAlgKIAQADIADgDIgBgeIgEgCIADgBIAIAAIACABIACAbIAEAAIAAgfQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAAgIACAAIAJgkIADAEIgFAiIABAAIAPADIAAglQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAAmIAbAFIAAgYQAAgBAAAAQAAAAAAAAQABgBAAAAQAAAAAAAAQABAAAAAAQAAAAABABQAAAAAAAAQAAAAAAABIAAAZIAMACIgMAAIAABAIAWASIgWgGIAAAlIACAAIACADIAQgfIgMAoIACAAIAGAAIAGAEIgFAHIgFAAIgIARgAAggeIAAAmIAFAIIAMgHIACACIAAg+IgbgBIAAAlIACgSIANgBgAARAgg");
	this.shape_24.setTransform(129.65,160.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_24},{t:this.shape_23}]},57).to({state:[]},9).to({state:[]},35).wait(77));

	// 2-A-2
	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAAAAIAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIAAAAIgBABg");
	this.shape_25.setTransform(161,179.45);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgBABIAAAAIAAgBQAAAAABAAIABAAIABAAIgBABIgBAAg");
	this.shape_26.setTransform(161.1625,178.8917);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAAABIgBAAIABgBIAAABIACAAg");
	this.shape_27.setTransform(162.225,175.975);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAAABIAAgBIAAAAIABAAIAAAAIgBABg");
	this.shape_28.setTransform(177.8125,179.4625);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAAAAIACABIgCAAQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAABAAg");
	this.shape_29.setTransform(174.745,171.05);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AABABIgBgBIgBgBIACAAQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIAAACg");
	this.shape_30.setTransform(175.1821,171.425);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAAAAIAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIABAAIAAABg");
	this.shape_31.setTransform(167.7,172.675);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAAgBIAAAAIABABIAAAAIgBACg");
	this.shape_32.setTransform(173.3875,174.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAAAAIABAAQAAAAABAAIgBABIgBAAg");
	this.shape_33.setTransform(169.45,172.975);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AAAABIAAgCIAAABQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAAAIgBABg");
	this.shape_34.setTransform(172.3948,173.275);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AADABIgBAAIgCAAIgJgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAIABAAQAAgBABAAQAAAAAAAAQABAAAAAAQAAAAABABIADgBQAAAAAAAAQAAAAABAAQAAABAAAAQAAAAABAAIAJAAIADAAIAAABIgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAIgBAAIgBAAIgBgBg");
	this.shape_35.setTransform(171.075,172.1813);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAAAAIABAAIAAAAIgBABIAAgBg");
	this.shape_36.setTransform(163.1875,166.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAAAAIABAAIgBAAg");
	this.shape_37.setTransform(164,163.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAAAAIABAAIAAABIgBgBg");
	this.shape_38.setTransform(163.425,163.85);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgBACIAAgBIgBgDIABAAIAAAAIAAACIABACIADABg");
	this.shape_39.setTransform(163.75,166.575);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AAAACIgCgCQABAAAAAAQAAAAAAAAQAAAAAAAAQAAgBgBAAIABgBIABAAIAAACQAAAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABgBIAAABIgBAAIgBACIAAABg");
	this.shape_40.setTransform(162.7125,164.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AABACIgBgBIAAABIgBgBIgBgBIABgBIABgBIAAABIABAAIABABIAAABIABgBIAAACQAAAAAAAAQAAAAgBABQAAAAAAAAQAAAAgBAAg");
	this.shape_41.setTransform(163.425,161.75);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgCACIACgCIgBAAIAAgBIAEAAIgBABIgCABIAAABIgBAAIgBAAg");
	this.shape_42.setTransform(173.975,171.4875);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_43.setTransform(164.225,169.85);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_44.setTransform(174.025,158.825);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_45.setTransform(177.725,164.475);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIgBABg");
	this.shape_46.setTransform(159.025,171.6125);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AAAABIAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAIgBABg");
	this.shape_47.setTransform(175.875,174.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIAAABIgBgBg");
	this.shape_48.setTransform(175.5875,164.125);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgBAAIABAAIAAAAIABAAIABAAIgCABIgBgBg");
	this.shape_49.setTransform(161.55,157.05);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AAAABIAAgBIABAAIAAABg");
	this.shape_50.setTransform(170.275,152.325);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AAAABIAAgBIAAAAIABAAQAAAAgBAAIAAAAIAAABg");
	this.shape_51.setTransform(183.1833,181.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIAAAAIgBABg");
	this.shape_52.setTransform(165.75,151.875);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAQAAABgBAAIAAAAIAAgBg");
	this.shape_53.setTransform(170.3833,151.745);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_54.setTransform(164.675,155.425);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAAAAQAAAAABAAQAAAAAAAAQAAABAAAAQgBAAAAAAg");
	this.shape_55.setTransform(173.125,158.275);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAAAAIABAAIgBABg");
	this.shape_56.setTransform(163.375,171.45);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_57.setTransform(167.775,161.15);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AAAAAIABAAIABAAQgBAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAABQgBgBAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAg");
	this.shape_58.setTransform(176.8417,166.975);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AAAABQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIABAAIgBABg");
	this.shape_59.setTransform(160,183.35);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AAAABIAAgDIAAAAIAAABIAAADIAAABg");
	this.shape_60.setTransform(174.5625,176.125);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AAAAAIABAAIAAAAIgBABIAAgBg");
	this.shape_61.setTransform(166.575,151.925);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AAAABIAAgBIAAAAIAAAAIAAABg");
	this.shape_62.setTransform(161.0625,182.7375);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_63.setTransform(160.425,182.025);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AAAABIAAgBIAAAAIABAAIAAAAQAAAAAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAIAAAAg");
	this.shape_64.setTransform(160.2,161.655);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgBABIABgBIABAAIABAAIAAAAIAAAAIgCABIgBAAg");
	this.shape_65.setTransform(164.175,170.95);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AAAAAQAAAAAAAAQAAgBAAAAQAAAAAAABQAAAAABAAIAAAAIgBACQAAgBAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAg");
	this.shape_66.setTransform(160.5417,181.65);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAAAAIABABQgBAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAg");
	this.shape_67.setTransform(161.3107,161.875);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AAAAAIAAAAQABAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAg");
	this.shape_68.setTransform(166.72,155.75);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAg");
	this.shape_69.setTransform(170.7938,165.125);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAIAAABIgBAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAg");
	this.shape_70.setTransform(173.4375,151.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AAAABQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAAAIAAAAIABAAIgBABg");
	this.shape_71.setTransform(170.555,153.375);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AAAABIgBgBIABAAIAAAAIAAAAIACABIgCAAg");
	this.shape_72.setTransform(174.225,178.775);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AAAABIgBgBIABAAIACAAIgCABIAAAAIAAAAg");
	this.shape_73.setTransform(175,156.6375);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgBABIABgBIABAAIgBAAIAAAAIAAABIAAAAIAAAAIgBAAg");
	this.shape_74.setTransform(174.9,156.175);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AAAAAIAAAAQAAgBAAAAQABAAAAAAQAAAAAAAAQAAAAAAABIAAAAIgBACg");
	this.shape_75.setTransform(160.8625,183.225);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgBABIABgBIABAAIABAAQAAAAAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAg");
	this.shape_76.setTransform(170.9,151.75);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AAAABIAAgBIAAAAIAAAAIACABIgBAAIgBAAIAAAAg");
	this.shape_77.setTransform(157.3,171.445);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AACABQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBAAIAAgBQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIACABg");
	this.shape_78.setTransform(163.425,159.5679);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AAAABQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAIAAAAIABAAIAAAAIAAABg");
	this.shape_79.setTransform(152.6938,182.95);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AAAACIAAgBIAAgBIAAgCQAAAAABAAQAAABAAAAQAAAAAAAAQAAABAAAAIgBADg");
	this.shape_80.setTransform(165.3563,169.95);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AAAABIgBAAIABgCQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAABAAIgBABIgBABIAAgBg");
	this.shape_81.setTransform(152.05,183.6083);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AAAABIAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIABgBIABACIgBABIgBgBg");
	this.shape_82.setTransform(160.35,161);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAAAAIAAgBQAAAAAAABQABAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIgBABIAAgCg");
	this.shape_83.setTransform(170.55,163.1781);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AAAACIAAgCIAAgBIAAABIAAAAIABAAIAAgBIAAABIAAACg");
	this.shape_84.setTransform(184.325,183.575);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AAAABIAAAAIAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAIABAAIAAABIgBACg");
	this.shape_85.setTransform(165.425,163.075);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AAAABIgBAAIgCgBQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAIACAAIgDAAIgBAAIAAABIAAAAg");
	this.shape_86.setTransform(172.9,151.73);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgBABIAAAAIABgBIABAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIAAAAIgDABg");
	this.shape_87.setTransform(166.2625,151.6);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AABABQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAAAIgCAAIADAAIABAAIAAAAIAAABIAAAAIgBAAg");
	this.shape_88.setTransform(160.3625,183.4875);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AACACQAAAAgBgBQAAAAgBAAQAAAAAAAAQgBgBgBAAIACgBQAAAAAAAAQAAAAAAAAQAAAAABABQAAAAAAAAIACACg");
	this.shape_89.setTransform(165.775,156.1083);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AAAACIAAgFIAAgBIAAABIAAACQABABAAAAQAAAAAAAAQAAAAAAABQAAAAgBABIAAACg");
	this.shape_90.setTransform(170.85,167.15);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AAAABIgBgBIAAAAIABAAQAAgBAAAAQAAAAAAAAQAAAAAAAAQABAAAAABIABACg");
	this.shape_91.setTransform(183.65,181.0375);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AABAEQAAAAAAAAQgBgBAAAAQAAAAAAAAQAAAAAAAAIAAgBIAAAAIAAgBIAAgBIgBgEIACAHIAAACg");
	this.shape_92.setTransform(184.35,182.825);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgBACIAAgCIABAAIAAAAIABgBIACABIgBAAIgCACg");
	this.shape_93.setTransform(166.5375,158.175);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AABADQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIAAgCQgBgBAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIAAAAIAAACIABAAIABADIgBAAg");
	this.shape_94.setTransform(174.5,179.975);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AAAADIgBgCIABgBIAAgBIAAgBIAAAAIABACIAAAAIABACIgCABg");
	this.shape_95.setTransform(181.575,175.375);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AAAABIAAgBIgBgBIAAAAIABgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAABABQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAABAAAAIAAABIAAABIAAgCg");
	this.shape_96.setTransform(166.8867,159.0175);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgDABIgBgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIABAAQAAAAABABQAAAAAAAAQABAAAAAAQAAAAABgBIABgBQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAABgBIABAAIAAABIAAAAIgBAAIgCAAQAAABAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAg");
	this.shape_97.setTransform(169.28,152.35);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgBACIgBAAIgBgCIAAgBIABABIABAAIACgBQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAABQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAIgBABIAAABg");
	this.shape_98.setTransform(166.2,159.48);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AAAAEIgBAAIAAgCQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAIAAgBIABAAIgBgBIAAgCIAAgCIAAABIACAFIgBAAIAAACIAAABIgBgBg");
	this.shape_99.setTransform(183.925,181.9321);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgFABIAAgBIACAAIAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIAFgBIABABIABAAIgCABIAAAAIgCgBQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAIgBAAIgCACIgCgBg");
	this.shape_100.setTransform(171.075,152.225);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgBABIAAABIgBgBIAAgBIAAAAIAAgBIABAAIABABIAAAAIAAAAIAAgBIABgBIACABIAAABIgCAAIgBABIAAACg");
	this.shape_101.setTransform(177.9625,165.4167);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgBAFQAAAAAAAAQABAAAAgBQAAAAAAAAQAAgBAAgBIABgEIABgCIAAAEIAAACQAAABAAAAQAAAAAAAAQAAAAAAAAQgBABAAAAIgBABIgBAAg");
	this.shape_102.setTransform(161.3,183.4);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AAAADQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAIABgBIgBAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIAAAAIgBgDQAAAAABAAQAAAAAAABQAAAAAAAAQABABAAAAIABABIAAAAIAAADIgBABIAAAAIgBgBg");
	this.shape_103.setTransform(158.275,169.5333);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgCACIAAgCIACAAIAAAAIAAgCIABABIACABIAAABQAAAAgBAAQAAAAAAABQgBAAAAgBQAAAAgBAAQAAABAAAAQAAAAAAAAQAAAAAAABQAAAAgBAAIAAAAIgBgBg");
	this.shape_104.setTransform(177.425,164.9867);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgBACIAAgBIAAgBIAAgBQAAAAABgBQAAAAAAAAQAAAAAAAAQAAABAAAAIABABIACAAIgCACIgBAAIgBABIAAgBg");
	this.shape_105.setTransform(166.35,160.1625);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AABADQAAgBAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAIgCgBIAAAAIAAAAIACgCIgBAAIAAgBIABAAIABABIACABIAAACQAAAAAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAIgBAAg");
	this.shape_106.setTransform(167.1875,158.15);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgFADIAAgBIABAAQABAAAAAAQABAAAAgBQABAAAAAAQAAAAAAgBIABAAIABAAIAAgBIAAgBIAAAAIABABIAAABIAAAAIABAAIACAAIABAAIgEABIAAABIgBABQAAgBgBAAQAAgBAAAAQAAAAgBABQAAAAgBAAIgCABg");
	this.shape_107.setTransform(163.425,157.925);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AAAAFIgBgCIgBAAIgCgDIABAAIABAAIABAAIgBABIAAACQABAAAAAAQAAAAABgBQAAAAAAAAQAAAAAAAAIAAgBIABAAIAAgBIgBAAIgBAAQAAAAABAAQAAgBAAAAQAAgBAAgBQAAAAAAgBIAAADIABAAQABAAAAAAQABAAAAAAQAAAAAAAAQAAgBABAAIABgBIAAABIgBABQgBAAAAABQAAAAgBAAQAAAAAAAAQAAAAAAABQAAABABgBIgBACIgBAAQAAAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAIAAABg");
	this.shape_108.setTransform(165.9,162.225);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AAAADQAAAAgBgBQAAAAAAgBQAAAAAAAAQAAgBAAAAIAAgCIABgBIAAABIACADIgBACIgBABIAAgBg");
	this.shape_109.setTransform(176.055,180.0083);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AAAADIgBgCIABgDIAAAAQAAAAAAAAQABAAAAABQABAAAAAAQAAABAAAAIAAAAQAAABAAABQAAAAAAAAQAAABgBAAQAAAAgBAAIAAAAg");
	this.shape_110.setTransform(159.8341,161.4611);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgDABIACgBIACgBQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAIAAABIAAACIgBAAIgCAAIgCAAg");
	this.shape_111.setTransform(159.2,169.5);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AAAADIAAgBIgCgBIABgBIAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIABAAIACACIABAAQAAABAAAAQAAAAgBABQAAAAAAAAQgBABAAAAg");
	this.shape_112.setTransform(159.525,164.775);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgBABIAAgBQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIAAgCIgBABIAAAAIAAgBIABgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIAAADIgBAAIABACIgCgBQABABAAAAQAAABAAAAQAAAAAAAAQAAABAAAAIgCgDg");
	this.shape_113.setTransform(160.85,182.05);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AAAADQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAgBAAAAIgBgCIABAAQAAAAAAAAIABgCIABAAIABACQABAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAg");
	this.shape_114.setTransform(153.255,181.4875);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AAAACIgBgBQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIACgCIABAAIABABIAEgBIAAABIABABIgBAAIAAgBIgCAAIgCABIACAAQAAAAABAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgBACIgBABIAAgBg");
	this.shape_115.setTransform(171.9833,151.92);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AAAAHQgCgGAAgDIABgEIABAAIAAAIQACgCABgDQAAABAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAIgDADIAAACIABADIgBAAg");
	this.shape_116.setTransform(176.6464,180.275);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AAAAGIgBgCIAAABIAAABIAAgDIgBgCIAAgBIAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIAAgBIABgEIAAAAIAAAFIAAABIAAAAQABgBAAAAQABAAAAAAQAAgBAAAAQABgBAAAAIABAAIAAABIgBABIgDAGIAAAAg");
	this.shape_117.setTransform(176.9875,175.55);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgBADIgBgCIAAgCQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAIABAAIABACIgCADg");
	this.shape_118.setTransform(159.2875,183.575);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AgCACIABgBIABgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQgBAAAAgBIAAgBIABABIAAACIABABQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAIABAFIgBAAIgBAAQgBAAAAAAQAAAAgBgBQAAAAgBgBQAAAAAAgBg");
	this.shape_119.setTransform(175.125,179.9341);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AgDAEIAAgBQAAgBAAAAQAAAAAAgBQAAAAAAAAQABAAAAAAIgBAAIgBAAIgBgBQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAAAgBIgBgCIAAAAIABgBIACABIABABIABAAIAEABIACACIgBAAIgDgCIgCAAQAAAAAAAAQAAABAAAAQAAAAAAgBQAAAAgBAAIgBAAQAAAAABABQAAAAAAABQABAAAAAAQAAAAAAABIAAAAIgBABIABABIAAAAIAAAAIAAABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgCABg");
	this.shape_120.setTransform(166.9,153.1);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AAAADIAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAAAABAAQAAAAAAgBIACgCQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQABABAAAAQAAABABAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAABIgBAAIgBgBg");
	this.shape_121.setTransform(158.4083,183.2083);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AAGAFIgBgBIgDgEQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgEADQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgBIgBAAIAAABIABAAIAAABIgBAAIAAgBIAAgDIAAAAIAAgBIABAAIABABIABAAIABAAIgBgBIAAgBIgBgCQABAAAAAAQAAAAAAAAQABAAAAAAQAAABAAAAIABABIABABIAAgBIABAAIAAgBIABABIABABIABAAIABACQAAAAAAAAQAAABAAAAQABAAAAAAQAAAAAAAAIABACIAAABIgBAAg");
	this.shape_122.setTransform(166.225,157.4388);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AAAAIQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBgBAAAAIAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQgBAAAAAAIgBgBQAAAAgBABQAAAAAAAAQgBAAAAAAQAAABAAAAIgBgDIAAAAIABgCIAAAAQABAAAAgBQgBAAAAAAQAAgBAAAAQgBAAAAAAIAAgBIABgBQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIABgCIgBAFIAAACIABABIABgBIABAAIABgBIAAAAQABgBAAABIABAAIABgDIAAABIgBAGIAAACIABAAIABgCIAAgBIACgBQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAAAIgBACIgDACIgCACg");
	this.shape_123.setTransform(175.1563,175.2);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AgFAGIgCgBIADABIAAgBIABABQAAAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABAAIAAAAIABgBIgDgFIAAgCQAAgBAAAAQAAgBAAAAQAAAAAAAAQAAAAABABIABgBIABgBIACgCIAFAIIAAACIAAACIgFABIgCABIgDABQAAgBAAAAQAAAAAAgBQgBAAAAAAQgBAAAAAAg");
	this.shape_124.setTransform(178.1583,166.65);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AgCAJIAAgBIABgBIgBgBIgCABIgCgBIABgCIACgFIAAgCQAAgBAAgBQAAAAAAgBQABAAAAgBQABAAAAAAIABgBIACABIAAABIABAAQAAAAAAAAQAAAAABAAQAAAAAAABQAAAAAAAAIAAACIgBACIgBABIAAABQAAAAAAABQgBAAAAAAQAAAAAAABQgBAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAIAAAAIAAABIgBABIABABIAEAAIgBAAQgBAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAABIgCABgAgCAEIAAABIABAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBAAIgBABgAgBAAQAAABAAAAQAAAAAAABQABAAAAAAQAAAAAAAAIAAABIAAgCIAAgBIAAAAg");
	this.shape_125.setTransform(159.7,162.675);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AADANIgBgEIgFgQIgBgEIgCADIAAAAIAAgDIACgDIACgBIACACQAAABAAAAQAAAAAAABQABAAAAAAQAAAAABAAQADgBgBADIAAABIgCABQAAAAgBAAQAAAAAAAAQAAAAAAABQAAAAAAAAIACAGQAAABAAAAQABABAAAAQAAAAAAAAQAAAAABAAIgBABIABABIAAABIABADIAAABIABAEIAAABIAAABIgCABQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBg");
	this.shape_126.setTransform(168.9167,161.3225);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("ABiCiIgGABIgUgBIgCgBIACAAIABgCIAAAAIgBAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgBQAAgBABAAQAAAAgBAAQAAgBAAAAQAAAAgBAAIAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAgBgBIAAgCIgBgBQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAgDIgBgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIABADIAAAEIABABIABABIgBACIACAGIgJgfIABABIACADIAAACQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIAAABQAAABAAAAQAAAAABAAQAAABAAAAQAAAAABAAIABAAIAAgBIgCgHIgBgBIgBgBIABgBIABAAIAEAKIABABIABAAIACABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAIgBACIABACIACAAQAAAAABAAQAAAAAAABQAAAAAAAAQgBAAAAAAIABACIACACIAAAAIAAABIABABQAAABAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIABAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIgBgBIAAAAIgBAAIAAgCIABAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIAAgCIAAgBQAAgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIADACIABACIAAABIABAAIABgDQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAIgBAAIAAAAIAAABIAAAAIgBAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAIAAABIgBAAIAAAAIAAgBIgBgBIAAgBIAAAAIABAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQgBAAgBAAIACgBIAAgBIgBAAIgBABIgBAAQAAAAgBgBQAAAAgBAAQAAAAAAABQgBAAAAAAQgBAAAAABQAAAAgBAAQAAAAAAgBQgBAAAAAAIAAgBQADgFAAgGQABgEgEgDQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAgBAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIgEgFIAAAAIAAgBIAAgBIgDgDIgDgCIABABIgDgDIAAgCIgBAAIgBgBIABgBIABABQAAAAAAAAQAAABAAAAQAAAAABAAQAAABAAAAIAFAEQAAABABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIACABIACABIAAAAQAAAAAAABQABAAAAAAQAAAAAAAAQABAAAAAAIgBABIgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIAAAAIgBgBIAAAAIAAABIACADIADADIACACIABAAIAAABIABABIACAEIABAEIABADIABAAQABADADACIADABIABAAIABAAQABAAAAAAQAAABAAAAQABAAAAAAQAAAAABAAIgBgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAABAAQAAgBAAAAQABAAAAAAIABAAIABAAIgBgBIgBgCIAAgBIgBgBIADADIAAgFIgDgEIgBACIgDgCIAAgBIABAAIAAABIACAAIABgBIAAgBIAAgBQAAgBAAAAQAAAAgBAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgBIABgBIgFgEQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAABIgBABIABgCIAAgBQAAgBAAAAQgBAAAAAAQAAgBgBAAQAAAAAAAAIgCgCIgBACIgCAFIgBAAIAAAAIAAgBIAAAAIABgCIAAgBIACgDIgBgCQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgBIgDgEIgDgDIgDgBIgBAAIgCgCIADABIABgBIgCgBIgBgBIAAgCIAEABIABgBQAAAAAAAAQABAAAAAAQAAAAAAAAQAAgBgBAAIABgBIgDACIADgEQAAAAAAABQAAAAAAAAQAAAAAAAAQAAABABAAIAAAAIgBABQABAAAAABQAAAAAAAAQAAAAAAAAQABgBAAAAIABgBIAAgEIAAACIAAACQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAgBABAAQAAgBAAAAIABgBQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAABAAIAAgEIgBABIAAgBIABgBIgBgCIgBgBIADAAIABgEQABAAgBABIAAADIAAABIABADQABAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIABADIgBgBIgBgBIgBAAIAAABIgBAAIgCADIACAAIAAgCIABABIAAABQABAAAAABQABAAAAAAQAAAAABAAQAAgBAAAAIABgCIAAgBIABAAIAAACIAAABIADAAIADgBQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAAAgBIADgIIABgBIAAgBIgBAAIgBAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAgBQgDgCgBgFIAAgBIgCABIgBABIACgDIAAgCQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIgCABIAAgBIgDgBIAAABIAAACIABACQAAABgBAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIgBAAIgBAAIAAgBIABgBIgBABIgBABIAAgBIgBAAQAAAAAAAAQAAAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQgBAAAAAAQAAgBAAAAIABgCIgCAAIABgBIABgBIABAAIgBgBIgDAAQAAgBAAABIAAACIAAABQABAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAIgBAAIgBgCIABgCIAAAAIgBgBIgDAAIgBABQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgBIgBgBIABgBIAGAAIAHADIACgBIAAgEIgCgBIgFgCQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgBABQAAAAAAABQAAAAgBAAQAAAAAAgBQAAAAAAAAIAAgBIgBABQAAABAAAAQAAAAAAAAQAAABAAAAQAAgBgBAAIgBABQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAgBAAAAIgBAAIgEAAIAAAAIgDgCIgBgBIgFgEQAAgBAAAAQgBAAAAAAQAAgBgBAAQAAABAAAAIgCAAIACABIABACQAAABAAAAQAAABABAAQAAABAAAAQAAAAABABIAEADIACABIABgBIABAAIAAABIAAABIAFADIACACQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBABIgDACIAAABIgDACIAAABIgBADIAAAEIgBACIAAAJIgBgCIAAgFQAAgBAAgBQAAAAAAAAQgBgBAAAAQgBAAgBABIgBAAIgBgBQgBAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQgCADABADQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCIABgEIABAAIAAABIgDAFIgBAAIgBABIAAgCIAAgEIAAgCIAAgCIgBgBIAAgBIgBAAQAAgBgBAAQAAAAAAgBQgBAAAAAAQgBAAAAABIgBABIAAABQAAAAgBABQAAAAAAAAQAAABAAAAQAAABAAABIAAACIAAABIABgBIACgDIgBADIABACIABABQAAABABAAQAAAAAAABQAAAAAAAAQgBABAAAAIgDABIADAAIAEABQABAAAAAAQAAAAAAAAQABAAAAABQAAAAAAAAIAAACIgBgCQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAIgGAAIgKAAIgCAAIgNAAIABgBIgLAAIACAAIgEAAIgDABIgDgBQACgBAEABIgBgBIgEAAIgBAAIABgBIAYAAIgYgBIADgBIADAAIgEAAIgBgBIABAAIADAAIADgDIAAAAIgCgCIgBgBIgCgCIgBgCIgBACIACAAIAAACQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAIAAgCIgBAEIABACIgBADIAAAAIAAACIgBACIAAABIgJAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgCIAAgGIAAgBIgBAAQAAABgBAAQAAAAAAAAQAAABgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAABQABABAAABQAAAAAAAAQAAABgBAAQAAAAgBAAIgBACIgBAAIgcAAIgCgCIgEgEIABgCIAAgBIgDAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAIgBgBQAAAAABAAQAAAAAAAAQAAgBAAAAQgBAAAAAAIgCABQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAgBAAAAIAAAAIgBgBIAAABIgBACIAAgCIgBABIgFAMIAAAAIAAABIgDAIIgBADQAAAAAAAAQAAAAgBABQAAAAAAAAQAAABAAAAIABACIACAAIACgBIAAgBIAAgDIABAAIABABIgBABIABAAIABgBQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBABAAAAIABACQABAAAAAAQAAAAAAgBQABAAAAAAQgBAAAAgBIAAAAIACAAIAAgBIABAAIABAAIADAAIABgBIAAgCIAAgBIgCABIgBABIAAABQAAAAAAABQAAAAgBAAQAAAAAAAAQAAgBgBAAIAAAAIgBgBIABAAIABAAIAAAAIAAgCQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAIAAABIAAgCIgCAAQAAgBAAAAQAAAAABAAQAAgBAAAAQAAAAABAAIABgBIgCgCIACgDQAAAAAAABQABAAAAAAQAAABABAAQAAAAABABIAAgCIAAAAIgBgBIgCgBIAAgCIABAAIAAABIAAABIACgCIABABIAAgDIACgEIgEAAIAAgCIACgBIAAABIAAAAIAAABIABAAIADAAQAAAAABAAQAAAAAAAAQAAABAAAAQAAAAAAABIACgBIgBABQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAAAIgBACIABABIgBABQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAAAIABABIABAAIgCABIgBACIAAACIAEgBIACACIgBACIAAAAIgBACQABAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAIgBACQAAAAABAAQAAABgBAAQAAAAAAABQAAAAgBAAIgBABIABABIAAABQAAAAAAABQgBAAAAABQAAAAAAAAQgBAAAAAAIgBACIgDAKIABACIAAABIgCACIgBgBIAAgBIgDAAIgCAAIABABIAAABIABgBQAAAAAAAAQAAgBAAAAQABAAAAAAQAAAAAAABIAAABIgBABIABABIABABIABAAIABACIgBAFIABAAIgCACQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAIABAAIAAgBIgDAAIAAAAQAAAAgBAAQAAgBAAAAQAAAAAAgBQABAAAAAAIgDAAIgBgBIABgCIABABIgBACIADgBIADAAIAAAAIAAABIABgBQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIgBAAIAAgCIgDAAIgBAAIgDgBQAAAAAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAIgCABIACAGIAAACIAAAAIgBABIAAAAIAAABIgCAEIAAABIAAAAIACgCIADgBIACABIgBABIgDACQgBAAAAAAQAAAAAAABQgBAAAAAAQABABAAAAIAAACIgBgCIgBgBQAAAAAAAAQAAgBAAAAQgBAAAAABQAAAAAAAAIgBABIABACQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIgCABIgBAAIgBgDIgBgBIgBAAQgBAAAAAAQgBAAAAAAQgBgBABAAQAAgBAAAAIAAgBIgCgCIAAAAQABAAAAAAQAAAAABAAQAAAAAAgBQABAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAIAAAAIAAgBIADACIABAAIgBgBIgBgBIgBgDIgBgBIAAABIAAACIAAABIgCgDIABAAIgBgCIAAAAIgBAAIABACQAAAAAAABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgBAAIgBAAIAAAAIAAACIgCACQgDgBgCADIgCACIgEAAIACgBIABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAgBAAAAIAAgCIgBgBIAAABQAAAAAAAAQAAABgBAAQAAAAAAAAQAAABgBAAIgBAAIgBAAQAAABgBAAQAAAAAAAAQAAAAgBAAQAAAAgBAAIgBAAIABgCIABgBIAAgBIABgBQABAAAAgBQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAAAABQgBAAAAgBQAAAAgBgBQAAAAAAAAQgBAAAAAAQAAAAgBABIAAABIAAABIgBABIACAAIAAABIAAACIgBAAIgCgCIgCgBIgCgCIgBgDIgBABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABIAAAAQAAABABAAQAAAAAAAAQAAAAgBAAQAAAAAAAAIgBAAIgBgCIgBgBIgDADIgBABIgBAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAABIAAAAIgBgBIgCgBIABABIACAFIAAABIACgBIABgCIgBADIgCAEIAAgCIAAAAIgBAAIAAAAIgCABQgBAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAABIABAAIAFABIADgBIABgCIABgBIABABQAAAAAAABQABAAAAABQABAAAAAAQABAAABAAQAAAAABAAQAAAAABAAQAAgBAAAAQAAAAAAgBIgBABIgBAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAIAAgDQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAgBgBIgBgBIgBABIACgDIAAgBIAAAAIgCABIACgCIABAAIAAABIAAACQAAABAAgBQABAAAAAAQABAAAAAAQABgBAAAAQABAAAAgBQAAAAABgBQAAAAAAAAQABAAAAAAQABAAAAABIAAAAIAAABQAAAAgBgBQAAAAAAAAQgBAAAAAAQAAABgBAAIAAABIABAAIADABIADAAIACAAIABABIgCABIgBAAIABABQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAIAAAAQAAABABAAQAAAAAAAAQAAAAAAAAQABAAAAgBIAAAAIAAgBIABAAIAAADIAAABIgEAAIADABIABAAIAAABIgCABIABAAIAAABIgUgBIgBgBIgBAAIgBABIgCABIgBAAIgIABIgJAAQgFAAgEgCQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAABAAAAIABgFIABABIAFABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIABgDQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgHgEQgBAAAAAAQAAAAgBAAQAAAAAAgBQAAAAgBgBIABgBIABAAIAHgBIAMAAIABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgDAAQAAAAAAABQAAAAAAAAQgBAAAAgBQAAAAgBAAIAAgCIABAAIgBgCIgCgDQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBABAAIABgCIgDACQAAAAgBAAQAAAAAAAAQAAAAAAAAQABgBAAAAIAAgCQAAgBABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABABIABgBIgCgBQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABAAIgBgBIAAgBIABgCQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIACgBIAAgBIgBgBIgBABIAAAAIAAAAIgBgCIABgBIACgBIABAAIABAAIgBAAIgCgBIAAgEIgCAAQAAAAAAAAQAAAAgBgBQAAAAAAAAQAAAAAAgBQAAAAAAgBQAAgBABAAQAAgBAAAAQAAAAABgBIAAgBIACAAIASAGIACAAIgBgBIgDgBIAAAAIgJgEIgDAAIgEgCIgBAAIgBAAIAAgBIABgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQABAAAAgBQAAAAAAAAQAAAAAAAAQAAgBgBAAIAAgBIAFgMIAAgBIACgEQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIABAAQAAAAAAgBQgBAAAAAAQAAAAAAgBQAAAAAAAAIABgCIACgBIACAAQABAAgBABIABAAIABAAIgBgBIgDgCIgBAAIAAgCQABAAAAgBQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIgCgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAABgBIAAgBIACAAIABAAIAAAAIgBgBQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIACgFIABAAIAAAAIAAgBIACAAIAAABIABABQAAAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABIgBACIABABIABgBIACgGQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQAAAAgBABIgBAAIACABQABAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABIgBABIgBAAIgBgBIgBAAIgBABIAAgCQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAABAAIAAgBIgBAAIADgIIACgBIABAAIACgBIABgBIABAAIACAAIAJADIADACQABAAAAAAQAAAAAAAAQABAAAAgBQAAAAAAAAQAAAAAAABQAAAAABAAQAAAAAAABQAAAAABAAIAAAAIACABIABgBQAAAAABABQAAAAAAAAQAAAAABABQAAAAABAAIADABQgBgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIABgCIgBgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABAAIACAAIABgBIAAAAIABABIAAAAQAAAAAAABQABAAAAAAQAAAAAAABQAAAAAAAAIgBAEQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAgBAAIALAEQAAAAABABQAAAAAAAAQAAAAAAAAQAAgBAAAAIABgBQAAAAAAAAQABgBAAAAQAAAAAAAAQABABAAAAIABACQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIAFACQAAAAAAAAQABAAAAAAQAAAAAAABQgBAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAABAAIAFACQABAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAgBIgBgCQAAgBgBAAQAAAAAAAAQgBAAAAAAQAAAAAAABIgBABIgDAAIgCgCIgBgBQgCgFgFgFIgBAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAABABQAAABgBAAQAAAAAAABQgBAAAAAAIgCABQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBgBIAAgBQABAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIAAgBIABgBQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAgBQABAAAAAAQAAgBAAAAQAAAAAAgBQAAAAgBAAIAAgBIgCAAIAAgBIgEAAIgDgBQgBAAAAAAQAAAAgBAAQAAAAgBABQAAAAAAAAIgBABQAAAAAAAAQAAAAgBgBQAAAAAAAAQAAAAAAgBQAAgBAAABIgCAAIgBABIgCgBIgEABIgDACIgBAAIAAgBIAAgBIgCgCQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAABAAIABgBIABAAIAEgCIABgBIABgBIABAAQADABADgBIgFAAIADgBIAAAAIABgBIgDAAIgDgBIADABIABgBIgBgBIgCgCIgBAAIgDAAIAFACIgCAAIgBAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABIAAAAIgCgCQABAAgBAAIgCgCIgBgBIACAAQAAAAABABQAAAAAAAAQAAAAAAAAQABgBAAAAIAAAAQAAAAABABQAAAAAAAAQAAAAAAAAQABgBAAAAIAAABIAAAAIABABIABgBIAAAAIADABIACAAQAAABABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIADgEQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIAAAAIABgDIABgCQAAAAAAgBQAAAAABAAQAAAAAAAAQAAAAABAAIAAgBIACgCIAAgGQAAAAAAgBQABAAAAAAQAAgBABAAQAAgBAAAAIACgCIABgCIABgCIAAAAIgBAAIAAAAQAAAAgBABQAAAAAAgBQAAAAAAAAQAAAAAAgBIABgEIACgBIABAAIABABQAAABAAAAQAAABABAAQAAAAAAAAQAAABABAAIAAAAQAAAAABAAQAAAAAAABQABAAAAAAQABAAABAAIADgBIgDgCQgDgBgFgEIgBAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIgCAAIgBAAIAAABQAAABAAAAQAAABAAAAQAAAAAAAAQABABAAAAIACABIgEAAIgDAHIABABIACABQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAgBIAAAAIABgBIAAAAQABAAAAABQAAAAAAAAQAAAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAAAgBAAIAAABIAAABIAAAAIgFgCQAAAAAAgBQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAAABQAFACABAFQgCgEgCAAIABACIABACIAAABIgDAEIABgCIgBgBIAAAAQgBAAAAgBQAAAAgBgBQAAAAAAAAQgBAAAAAAIAAgBIAAAAIgBgBIgDAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQABAAAAgBIABgBIgCABIgBACIgBAAIAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgEACIgCADQgCAEACAEIgCAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBgBQgBAAAAAAQAAgBAAAAQAAAAAAAAQAAAAABAAIABgDIAAgCIABABIACgDIADgCIgCgBIgBAAIgDAFIABgDIAAAAIAAgBQABAAAAgBQAAAAABAAQAAAAAAgBQAAAAAAgBIgCABIgBABIgFANIAAACIgBACIAAACIgBABIABACQAAAAAAABQABAAAAAAQAAAAABAAQAAAAAAAAIgBACIgBABIAAAAIAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIgBgCIgBADIAAAAQgBABAAAAQAAABgBAAQAAAAgBAAQAAAAgBAAIgBAAQAAAAAAAAQAAAAgBgBQAAAAAAAAQAAAAAAgBIACgGQABAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIAAgBIABgCIACgIIAAAAIACgFIAAgBIACgGIAAAAIABgCIABgCIAAAAIACgCIAHgXIAAgBQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIAEABIABABQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIAFACQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAIgBgKIABgEIACgCIAEgCIADgBIADgCIADgCIABgCQABAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAIgFABIgCAAIgBAAIgCAAIACgBIAHgBIADgCIABgDIgBgBQAAAAgBABQAAAAAAAAQAAAAAAgBQAAAAAAAAIABgBIABAAIABAAIAAgCIgBgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABAAIAAgBIAAgCIABgBIAEgCIAAgBQAAgBAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQABgBAAAAQABgBAAAAIAAgBIgBAAIAAAAIACgBQAAgBABAAIACABQAAgBABAAQABAAAAABQABAAAAAAQAAABABABIAAAAIABgBQAAAAAAAAQAAgBAAAAQABAAAAAAQAAAAAAAAIABAAIABABIAAABQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAABAAIAFgCIAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAIgCAAIgBAAIABgBIAEAAIAAAAIABAAIAAgBIgDgBIgFgBIgBAAIgDgCIAAAAQAAAAAAAAQABAAAAAAQAAgBABAAQAAAAAAgBIACABIACAAIABACIADACIAAgBIACgBIABAAQABgBgBAAIgBgBIABgDQABAAAAgBQAAAAAAgBQAAAAAAAAQgBgBAAAAIgDgBQABAAAAAAQAAAAABAAQAAAAABAAQAAABABAAIAAABQABABAAAAQAAAAABAAQAAAAAAAAQABAAAAgBIACgCIgEAJIAEAAIAAAAIgBACIgEACQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAABIAAAGIAAABIgBgCIAAAAIAAAAIAAADIABAAIAAABQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIAAABIABABIACgBIABgDIAAgGIABgBQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBgBAAIgCAAIAEgCIACACIAEABIgBAAIgCgBIgBABIAAABIgCgBIgBABIABAAIAEACIABgBIABADIgEgCIgBAAIgCAAIAAABIAAACIgBAFIABABIgCAAIgBACIAAgBIAAgBIgBABIAAAAIACADIABADIgBACQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAABABIAAAAIABABIAAACIAAABIgBgBQgBADACACIgBABIABABIACAAIAAAAQAAAAAAAAQABAAAAABQAAAAAAAAQABAAAAABIAAAAIAAACQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAIABgCIAAgBIABAAIAAgCIAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIACgEIAAgDIACgDIgBgCIAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgCgDQgCgEgBgBIgBgCIABgBIACACIAAACQAAABAAAAQABABAAAAQAAABABAAQAAAAABABIABAAQAAAAgBgBQAAAAAAAAQAAgBABAAQAAgBAAAAIADgCQABAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIAAgBIABABQAAABAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIgBgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAIgBAAIABgCQAAAAAAABQABAAAAAAQAAAAABAAQAAgBAAAAIABgBQAAAAAAgBQABAAAAAAQAAgBABAAQAAABAAAAIAEABIAAACQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAAADIgEALIAAACIABAAIAAgBIABgBIABABIAAABIABgBQAAAEgDAHIABgGIAAgBIgCgBIgBAAIgBADIgCAEIABACIABABIgBAAIgBgBIAAABIgCAGIAAABIgCAFQAAAAgBABQAAAAAAAAQAAAAABABQAAAAAAAAIAAABIAAAAIgBABIgEANIgBADIABAEQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABIgCACIAAACIABAAIgCABIgCALIAAAEIABABQAAAAAAAAQABAAAAAAQAAAAAAABQgBAAAAAAIAAABQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQABADgCACQABAAAAABIgBABIgBgBIAAgBIgBgBIgCACIgBABIgDgBIgCAAIAAgBIAAAAIADABIABAAIAAgCIABgBQABAAAAAAQAAAAABAAQAAAAAAAAQABgBAAAAIACgEIAAgBIAAgBQAAAAABgBQAAAAAAAAQAAgBAAAAQAAAAgBgBIgBgBIACAAQAAAAAAAAQABAAAAAAQAAgBAAAAQAAAAgBAAIAAgCIABgFIgBAAIgBAEIAAACIgBAAIgBAAIgBgBQABAAAAAAQAAgBAAAAQAAAAAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAABAAAAQAAAAAAABIgBABQgBAAAAAAQAAABAAAAQgBAAAAABQABAAAAAAIgCAGIAAgEIgBAAQAAAAAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAIgEgBIgBABIAAAAQAAAAABABQAAAAAAAAQAAABAAAAQAAAAAAABIAAABIgCAEIAAABIABADIACgEIADgDIgBABIAAACIAAAAIgBABIgDAEIgCAFIgCAFIAAABQAAAAABAAQAAAAAAgBQAAAAABAAQAAABAAAAIAEgCIACABIAAgBQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIABAAQAAgBAAAAQAAAAABAAQAAAAAAAAQABAAAAAAIAAgBIADgDIABgBIgCgBQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIABAAIgBgBIAAgBIABABIABAAIABgCIABAAIABABIgBABIAAACQAAAAAAABQABAAAAAAQAAABAAAAQABAAAAAAIABAAIABgBIABABIABgCIAAACQAAABABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAEgCAEACIABABIACAAIABgBQAEgDADADIAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAAAAABgBIgBAAIAEgBIAFAAIABABIgDAAIABABIABAAIADAAIACACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIAQgBIADgBIAAAAQAAAAABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIAAgBIAAAAIABAAIAAgBIAAgCIgHgXIAAgBIABgBIABAAQAAgBABAAQAAAAAAgBQAAAAABAAQAAAAABAAIAIgBQAAAAABAAQAAAAAAgBQABAAAAAAQAAgBAAAAIgDACIgCAAQgEgBgBgDIgBAAIgCgDQAAAAAAAAQAAgBABAAQAAAAAAgBQAAAAABAAIACgCIAAgBIgBgEQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAAAAAABIgCABQAAAAgBABQAAAAAAAAQAAAAAAAAQgBgBAAAAIABAAIADgCQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIgDABIgCACIgBAAQgBAAAAABQAAAAAAAAQgBAAAAgBQAAAAAAAAIABgCIABAAIADAAIACgBQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBgBIgDgKIgBgBQAAAAAAAAQAAgBgBAAQAAAAAAABQAAAAgBAAIAAABIABgCQAAAAAAAAQABAAAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAABAAIAAgCIAAAAIAAgBIACABIACADIAAAAIAAACIAEAKQAAABABgBIABgBIgBgBIgBgEIgCgEIgBgCQAAgBAAAAQAAAAAAgBQAAAAABAAQAAAAAAAAIAEgCIACAAIAAABQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAABAAIACgBQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAIgBAAIAAABIABABIACgCIABAAIAEgBIACgBIgBAAIgBgBQAAAAABAAQAAAAABAAQAAAAAAAAQABABAAAAIACABIgBgBIAGgBIACAAIABgBQAAAAAAgBQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAABAAQAAABABAAQAAAAAAAAQABgBAAAAIAEAAQABAAAAAAQABAAAAAAQABgBAAAAQAAAAAAgBQAAAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAIACgBQABAAAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIgDAAIgBABIgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAABIgEABIgDABIgFAAIgBABIgFAAIgHgCQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABIAAABIgDAAIABgCQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgDgCIgBABQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAABIgBAAQAAABAAAAQAAAAgBABQAAAAgBAAQAAAAgBABIABgCQABAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBIgBABIgDgCIAEgBIgGgEIgCACIgCgEIAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIABgBIgBAAIgCgBIABgBQAAAAAAgBQgBAAAAAAQAAAAAAgBQAAAAAAgBIgBgBQABAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgBIABAAQABABAAgBIABgIIADgCIABAAIABgCIADgDIgFAAIAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAABIgEACIAAABIgBAAIABgBIAAgBQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAAAgBABIgEAAIgBgBIACgBIgDgBIACAAIABAAIABgBIAAAAIgCgCIgBgBIACAAIACAAIgCgBIgEgEIAAgBIgDgEIgBADIgBABIABAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgCAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgDgDIgFgCIgBAAIgBAAIgDgCIABgCIABgBIABAAIAAgBIABgCIABgBIABgBIAAAAQAAgBAAAAQABAAAAAAQAAAAABAAQAAAAABAAIgCgBIgEAAIAAgBIAAgBIABAAIACAAQgCgCgEABIAAgBIgBAAIADgBQAAABAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAIgBgDIAAgBIAAAAIgBgBIgCAAIgBgBIgBAAIABACIAAACIgBACIAAAEIAAAAIgCACQAAgBAAAAQAAAAAAAAQAAgBAAAAQgBAAAAAAIAAgBIABAAIABgBIAAgBIAAAAQAAAAABgBQAAAAAAAAQAAgBAAAAQgBAAAAgBIAAAAIgCgBIAAAAIgBgBIgBgCIAAABIAAAAIgBAAIABgBIgFACQgBAAAAAAQAAAAAAAAQgBAAAAABQAAAAAAAAIgBABIgDAEIABACIAEABIABAAIAAAAIgCAAIgDABIABgBIgCgBIAAABQAAAAAAAAQAAABAAAAQAAAAABAAQAAABAAAAIACABIgBABIgBACIAAABIgBgBIgDgBIgBABIAAABIABAAIABABIAAABIABAAIgBAAIgHAAIgGAAQgNADgGAOIgBABQABAAAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAIgCgBIgCgEIgBgDIABgCIAGgJIADgBIABgCIAAAAIAFgDIABAAQAAgBgBAAQAAAAgBgBQAAAAAAAAQgBAAAAAAIgEABIAAABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIABABIgBABIgBAAIAAABIgCgBIABgEIgBgBIgCgCIAAgCIAAgBIABAAIAAABIABAAIAAgBIgBgBIAAgBIAAgBIABABIAAAAIAAgBIAAgDIAAgBIADADIgCgDIABAAIgBgBIABgBIAAgCIAAAAIABABIAAgCIABgBIADgDIABABIAAgDIABABIABABQABAAAAABIABgBIAAABIABAAIABAAIAAAAIgBACIABAAIABAAIABAAIAJAHQAAAAABAAQAAAAAAABQAAAAAAAAQAAAAAAABIgDAEIgCADQAAAAABAAQAAgBAAAAQABAAAAAAQAAABABAAIgCABIACAAIgDABIADAAIAFABIABAAIAAgCIAAgBIACgDQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAgBgBAAIABgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIAAgBQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAAAgBAAIAAgBIgCgCIACABIgBgBQAAgBAAAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgBAAIgBAAIAAABIgDAAIAAAAIgBAAQAAAAgBAAQAAAAgBAAQAAgBAAAAQAAgBAAAAIABgCIAAgBIAAgCIAAgBIgCAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgBIgBAAIgBgDIABABIABAAIAAgBIABAAIgBgCIgBAAIAAAAIAAABIgBgBIAAABIgBgCIAAgBIABABQABgBAAAAQAAAAABAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAgBABAAIABgBIABAAIgEgCIAEABIABAAQABAAAAgBQABAAAAAAQABAAAAAAQAAAAABAAIAAgCIABAAQAAAAAAgBQAAAAgBAAQAAAAgBgBQAAAAgBAAIgBABIgBAAIAAgBIAAgCIABgBIABABQABAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgDIgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIAAAAQABAAAAAAQABAAAAAAQABAAAAABQAAAAAAABIABAAIAFgBIAEAAIgCgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABIAAgDIACAEQAAAAABAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgBAAIAAABIAAAAIACAAIACAAIAFACIAAABIAAACIABABIAAgBIABACQAAAAAAAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAAEIgBgBIABACQAAAAAAAAQABAAAAAAQAAABABAAQAAABAAABIAAABIAAAAIgBAAIgBAAIAAAAIAAABIADAAIAAADQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAAAAAIAAACQAAAAABAAQAAAAABAAQAAAAAAgBQABAAAAgBIABgBIgCgBIAAgBIAFABIAAgBQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAAAAAIAEAAIgCACIACgBIABAAIABgBIgCAAIACgBQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAgBIACAAIgCgDIABAAIACAAIACAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIAAAAIABAAIgBgCIgBgCIgBAAIgBgBIgBAAIAAgCQABAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAIgBgCIgBAAIgCgCIAAAAIABAAIADABQAAAAAAABQABAAAAAAQAAABAAAAQAAAAAAABIAAABIABABIABgBIgBgDIgBgCIgDgBIgEgBIAMAAIgBACIgBgBIAAAAIAAAAQAAAAgBABQAAAAAAABQAAAAAAABQAAABABAAQAAAAAAABQAAAAAAAAQAAAAAAgBQAAAAAAAAIABgBIABgBIABABIgBACIAAABIABAAIABABIAAABIABABIAAAAIAAABIAAAAIABAEIABABQgBAAAAAAQAAAAAAgBQgBAAAAAAQAAAAAAgBIgBgCIAAAAIgBAAIAAABQgBAAAAABIABACIABACIAAgBIgCgCIgBAAQgBAAAAAAQAAABABAAIABAAQAAABAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIABACIABgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABgCIAAgBIABAAIAAABIABABIAAgBQAAgBABAAQAAAAAAAAQAAAAAAABQABAAAAAAIABABIACADIADADIACACIABgBIACAAIABgCIABgBIAFgEIABgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAABgBIABgBQAAAAAAAAQABAAAAAAQAAgBAAAAQgBAAAAAAIAAgDIABgBIACgBQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAIABABIABgBIAAgBIAAgBIABABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIAJgEQABAAAAAAQAAAAAAAAQABAAAAABQAAAAAAAAIABACIABABIAFAQIAAACIABABIABACIACAFIAAABQAAAAAAAAQAAABAAAAQAAAAgBAAQAAABAAAAIgRAGQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBIgBADIACADIgCAAIgDAAQAAgBAAAAQABAAAAAAQAAgBAAAAQAAgBAAAAIgCgCIAAAAIAAACIAAABIgBAAIgDgBIgBAAIgBAAIAAABIABABIgCAAIAAgBIgBAAIAAABIABACQgBgBAAAAQAAgBgBAAQAAgBAAAAQAAAAABgBIAAgCIgDgCQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAIgBgBIABADQAAABAAAAIABAAIgBABIAAABIABAAIAAAAIADgBIAAgBIAAABIAAABIgCACIgCAAIABABIAAAAIABAAIAAACQAAAAABABQAAAAAAAAQAAABAAAAQgBAAAAABIADAAIADABIABAAIABgDIABgCQABgBAAAAQAAAAABAAQAAAAAAAAQAAAAAAABIABABIAGAIQAAAAAAABQAAAAAAAAQABAAAAAAQAAAAABAAIgCgDQAAAAAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBIAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIABgBIgDgBIgDgCIAAAAIAEACIADABIADACIgBAAIgBgBIgCABIAAACIAAAAIABACIACABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABABAAQAAAAABAAQAAAAABAAQAAAAABgBQAAAAABAAIAAgBQABgBAAABIAAABIABgBIAAgBIgCgBIAAACIgEgFIAAgBIAAgBIABABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIAAgCIgBABQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAAAABAAIABAAIAAAAIgCABIABABIgBACIABAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAABAAAAQAAAAgBABQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAgBQAAAAAAAAQAAAAAAgBIABgBIAAAAIAAgBIAAAAIABAAQAAAAAAgBQAAAAgBAAQAAAAAAgBQAAAAAAAAIgCgCIAAgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABIACAAIAEABIABABIABgBIgCACQAAAAABgBQAAAAABAAQAAAAAAgBQABAAAAgBIAAAAIAAAAIAAABIgBADIAAACQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIAAAEIgCgCQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIAAABIgCAAIgCABIgBAAIACABIABgBQABAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAABQAAAAAAAAQAAAAAAABQAAAAABAAQAAAAAAAAIAGABIACAAIAEABIAAABIAAABIgCAAIgGgBIgBABIACABIAFABQABAAAAAAQAAAAAAAAQABAAAAABQAAAAAAAAIABACIAAABIgDAAIgDgCIgBAAIgBAAIgDABIgBAAIgDgBIgBAAIABAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAIgBAAIgCgCIgCAAIgBgBIgBAAIgCAAIgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBABgBAAIgBABIACAAIgBACQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAIgBgBQAAgBAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAIgEADQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAIgCgBIAAgBIgCgEQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgCAAIgCACIAAACQAAABABAAQAAAAAAABQAAAAAAAAQgBABAAAAIgBABIgCABIgBAAQgBABAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIADABIACABIACABIADABIABAAIADAAIABgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAgBAAAAIABAAIAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAABAAIADADIAAAAIABAAIAAgBIABAAQAAAAAAAAQAAABABAAQAAAAAAABQABAAAAAAQAEABACACQADACAEAAIABgBQAAAAABAAQAAAAABAAQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAAAAAAAQAAAAABAAIAAAAIAAgBQAAAAABABQAAAAAAAAQAAAAAAgBQABAAAAAAIABACQABABAAAAQAAAAAAAAQAAABAAAAQAAAAgBAAIAAABQAAAAAAABQAAAAAAAAQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAAAABQAAAAABAAQAAAAAAAAIAFAFIAFACQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIgBgCIgCAAIAAABIACAGQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAABQAAAAAAAAIABACIgCADIgBAAQAAABgBAAQAAAAgBABQAAAAAAABQAAAAABABIAAACIgBgBIgBAAIgBABIAAACIABAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAABAAIAAABIABABIACAAIACAAQAAAAABAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIAAgBIACACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIAAgBIAAgBIgBgDIgBAAQgBgGgCgCQABAAAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgBgBIAAgCIgBgBIgBgBIABgBIACAAQAAAAAAAAQABAAAAgBQAAAAAAAAQgBAAAAgBIAAgCIAAAAIgBgCIgBgCIgBgBQgBAAAAgBQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIAAgBIgBgBIgBABIAAADIgBAAQAAgBgBAAQAAAAgBgBQAAAAAAAAQgBAAAAAAIgCgBQABAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQABAAAAAAIADgBQAAgBAAABIABACQAAABAAAAQABAAAAAAQAAAAAAAAQABAAAAgBIAAAAIgCgCIAAgCIABgBIADACIADAFIABAEIgBABIAAAAIgBgBIgBgBIgBABIgBABIABABIACADIgBABIABACIACAEQAAAAAAABQAAAAAAAAQAAAAABAAQAAAAAAAAIADAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAABAAAAIgBABIgDAAIAAABQABAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgBABIACABQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAIACADIACADIAAABIAAAEIABACIABACIAAABIAAAAIgBgBQAAABAAABQAAAAAAABQABAAAAABQAAAAABAAIACAEIgCgDIgBAAIgBABIAAABIABAAIABACIgCAAQAAABAAAAQAAAAgBAAQAAAAAAgBQAAAAAAAAIABgBIAAgBIgBAAIgDACQAAABAAAAQgBAAAAABQAAAAAAAAQAAABAAAAIgBABIAAABIgDAAIABAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAAAIgBgBQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIgBAAQAAABgBAAQAAAAAAAAQAAAAAAAAQgBAAAAgBIgBAAQAAAAgBgBQAAAAAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAABAAAAIAAgCIgBAAQAAAAgBAAQAAAAAAAAQAAAAAAABQAAAAABAAIAAABIgBAAIgDgBIgCAAIgCACQAAAAgBAAQAAAAAAAAQAAABABAAQAAAAAAAAIADABIABAAIABgBIACABIAAACIABAAIABABIACACIAAACIACABQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAAAgBIgBgEIACABIABACIAAABQAAAAAAAAQAAAAAAAAQgBAAAAABQAAAAAAAAIAAABIAAAAQgBAAAAABQAAAAAAAAQAAABAAAAQABAAAAAAIAEACIAAABIAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAABAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIAAAAIgBACIAAAAIADABQAAAAABAAQAAAAABAAQAAAAAAgBQABAAAAAAIABgBIAAADIABABQAAgBABAAQAAAAAAAAQABAAAAABQAAAAABAAIAAABIACAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIABABIAAAAIACADQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABIAAAAIgBACIgCgBIgBgCIgCgBIABgBIAAgBIAAgBIgBAAIgBABIgBABIgCAAIAAAAIAAABIADACIAAABIgBAAIgCABIAAABIAAABIgCAAIAAgEIAAgCIAAAAIABgBIgCAAIgDADIgBACQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIAAgCIABAAQABAAgBgBIABAAIAAgCIABAAIACgBIAAgCIgCgBIgBgBIgCADIgBABIgBACIABgBIgBACIAAABIABACIAAACIAAABIABABIAIABIADgBQABAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIACABQAAAAAAABQABAAAAAAQAAAAAAAAQgBABAAAAIgBABQAAABgBAAIgBAAIABABIACgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABIADAGQABAAAAAAQAAAAABABQAAAAAAABQAAABABABIgBABIgCADIgBAAIAAABIACABIACADQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIABABQABAAAAABQAAAAAAABQAAAAAAABQAAAAgBABIAAAEIACABIABgBIgBgBIgBAAIAAgBIABAAIADAAQAAABAAAAQAAAAAAAAQABAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAIAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBIgDgEQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAAAAAIABAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAgBAAIgBAAIgCgCIgEgJQgBAAAAAAQAAgBAAAAQAAAAABAAQAAAAAAAAIACAAIACAAIABAAIAAAAIABACIACgBQAAAAAAAAQABAAAAAAQAAAAABAAQAAABAAAAIAAABQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIABAAIAAAAIgEgHIgBgCQAAAAAAAAQAAgBABAAQAAAAAAAAQAAABAAAAIABAAIAAABIAAACIABABIAAgDIACAAIABACIACACIABAAIAEALIACAGIABAAIAIAXQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAgBAAIgBACQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAIAAgEIgCAAIAAAAIAAACIABACQABAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIgBAAIgBAAIgBABIgBACQAAAAAAgBQAAAAAAAAQAAAAgBgBQAAAAAAAAIAAAAIgBgBIgBAAIAAABIABAAIgEAAIACADIABADIACABIACAAIABAAQADgCADABQACACAAAEQgBAEgDAAIgDABIAAABIABADIABAGIAAABIADABIAEAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAEADABADIABABIACACQAAAAAAAAQABAAAAABQAAAAAAAAQAAAAAAAAIgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAEgFAEIgBAAIAAACIADAAIgBABIAAACQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIABAAQABAAAAAAQAAgBABAAQAAAAAAAAQAAgBABAAIACgDIAAAAIADABIADAIIACACIABABQAAAAABABQAAAAAAAAQAAAAAAABQAAAAAAAAIAAABIABADIgCgDIAAABIABADIABAAIAAABQAAAAgBAAQAAAAAAABQAAAAAAAAQABAAAAAAIABABIgBAAQAAABAAAAQABAAAAABQAAAAABABQAAAAABAAIgCAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAABIAAAAQgBAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAIACADIgBABQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAIAAAAIgFgCQgBAAAAABQAAAAABABQAAAAAAABQABAAAAAAQAAABABAAIABAAIADACIAAABIADADIAAACQAAAAAAABQAAAAgBAAQAAABAAAAQAAAAgBAAIAAABIABAAIADABIABAAIADAHIABAEIgBACIAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAAAAAIAAAAIABABIgzABgACTCcQgBAAAAAAQAAAAAAAAQgBABAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAABAAIgDAEIADAAIACgEQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAIAAAAgACFCgIAAAAIAAABIADgCgABjCdQAAAAAAAAQABAAAAAAQAAABAAAAQgBAAAAAAQAAABAAAAQAAABABAAQAAAAAAAAQABABAAAAIAAgDIABgCIgBgBIgBABIgBAAgABdCbIACACIAAACQAAAAAAAAQAAABAAAAQAAAAABAAQAAABAAAAIABgBIAAgBIgBgCIABAAIgCgCIgBAAIAAgBIAAAAIABAAIAAgBIgBAAIgBAAIgBgBIABgBIAAgBQABAAAAgBQAAAAAAAAQAAAAAAAAQAAAAgBAAIgBAAIgBACIgDAAIgCgBIAAABIAAAFIAAACIABACIACAAIABABIABAAIAAgBQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIACgDIABgBIAAAAgACNCeIgDABIgBAAIAAABIACAAIACAAQABAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIgBAAIgCAAgAByCdIAAACQAAABgBAAQAAAAAAAAQAAAAABAAQAAAAAAAAIADgCIAAgBIgBgBIgCABgABwCbIABAEIAAgCIABgCIAAAAIgBAAgAh1CYIAAABIABADIADAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIAAgCIgDACgACQCaIAAABQABAAAAABQABAAAAAAQABAAAAgBQAAAAABAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAIgBAAgABlCaIABABIABAAIAEgDIABgCQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAgBAAAAIAAAAIgBADIgCAAQgBAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAABgAhxCaIABABIABAAIABgBIgBgBIgBAAIgBAAgAiTCaIACABIABgBIgBgBIgCAAgAiPCYIAAABIABABQAAAAAAABQABAAAAAAQABAAAAAAQAAgBABAAIgBgBIgCgBIgBgDgACZCYQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAgBgBIAAgCIgBABgAiLCZIABABIACgBIgCgBgACDCZIABABIAAgBIACgDIgDACIABgBIABgBQAAAAABgBQAAAAAAAAQAAAAAAAAQgBgBAAAAIgBABIgBABIAAABIAAABgACSCYIAFAAIABgBIgBgCIgBAAQAAAAgBgBQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQAAAAAAAAQAAABABAAQAAAAAAAAIABAAIABAAIgBABIgCAAgACLCXIABABIABAAIAAAAQAAgBAAAAQAAAAAAAAQAAAAgBAAQAAAAAAAAgAh5CVIACACIABAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIAAgBIgBAAIgCAAgACHCUIABACIABgBIgBgBgABnCTIAAABIABAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABgBQAAAAAAAAQAAAAAAgBQgBAAAAAAIgBgFQAAgBAAAAQAAAAAAgBQgBAAAAAAQgBAAAAAAIgBAAIAAgBIAAgBQABAAAAAAQAAgBAAAAQAAAAAAAAQgBAAAAAAIgCgBIgBAAIgCACIgDABIgDADQAAABAAgBQABAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABIABABIACgCQAAAAAAAAQABAAAAAAQAAAAABAAQAAABAAAAIABgBIgCgCIABAAIACAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQABABAAAAIAAABIgBADIAAABIABABQAAAAAAABQAAAAAAAAQAAABAAAAQABAAAAAAIAAAAIABgCgABXCUIABAAIAAgBIgCgDIABAEgACKCUQAAAAABAAQAAAAAAgBQAAAAABAAQAAAAAAgBIgBgBQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAgACQCPQABAAAAABQABAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAQAAgBABAAQAAAAgBgBQAAAAAAgBIgDgEIgBAAIgEAAIgCABIgBABIABADQAAABAAAAQAAABABAAQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIABgBgAhwCLIgBABIgCABIAAABIABACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIAAgCIABAAQAAAAAAAAQABAAAAgBQAAAAAAAAQAAAAAAgBQAAAAABAAQAAAAAAAAQAAAAAAAAQgBgBAAAAIAAAAIgBAAgAhlCLQAAAAAAABQAAAAAAABQAAAAAAAAQgBABAAAAIAEgCIAAAAIAAgBIAAABIgCgBIgCgCgAhoCKIABABIAAABIgBABIABAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAgCIgBAAgAiDCKIAAABIAEACIgCgDIgBgBIAAABIgBAAIAAAAgAh+CLIABABIAAgBIgBgBgAh5CIIACACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIgBAAIAAAAIABgBIABgBIgBgDQAAAAAAgBQAAAAAAAAQgBgBAAAAQAAAAgBAAIAAACIgBACIgBgBIgDgBIAAAAIgBAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAABAAAAIgBACIAAgDIgCgFIAAgFIAAgCQgBAAAAgBQAAAAAAAAQABAAAAAAQAAAAABAAIACgBIABAAIAAgBIAAgBIACgBQAAAAABAAQAAAAABAAQAAAAAAAAQABABAAAAIAAAFIABADIAAADIgBgDIAAACIACAEIAFAEQABABAAAAQAAAAAAAAQABAAAAAAQAAAAABgBIACgEIABAAIgCAEIABABIACAAIAAgBQAAgBABAAQAAAAAAAAQAAAAAAgBQgBAAAAAAQgBAAABgBIgBgCIACABIAAgBIAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIAAgBQABAAAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAIgCABIAAAAIAAgCIABAAIACAAIAAgDIgCABIgBAAIAAgCIgBgBIAAABQAAAAgBAAQAAABAAAAQAAAAgBAAQAAgBAAAAIgBgCIAAABIgBAAIgBgBIAAgBIAAAAIgBAAIAAADIgBACIAAgCIgBABQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAQABAAAAgBIACgBIAAgBIAAgBIgBAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIACgBIAAgBIABgDIgDAEIAAABQAAAAgBgBQAAAAAAAAQAAAAAAgBQAAAAAAgBIADgFIAAgCIgBADQAAgBAAAAQgBAAAAAAQAAAAAAAAQAAAAAAABIgDAEQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBIAAAAQgBAAAAgBQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAgBgBAAQAAAAgBAAIgBABIgBACIgDABQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIABABIABAAIACAAIgBABQAAABAAAAQAAAAAAAAQAAABgBAAQAAAAAAAAIgCACIgBACIABABQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABIgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABIADACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABgDIAAgBIABAAQABAAAAABQAAAAAAAAQAAAAAAAAQAAABgBAAIgBACIABACIACABQABAAAAAAQAAABABAAQAAAAABAAQAAAAABAAIADgBgAhgCHIABAAIAAAAIgCgDIgBAAIgBAAIAAABIABAAIAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQABAAAAAAIABAAIAAAAgAhbCGIABABIABgBIgBAAIgBAAgAhpCHIABAAIACgBQAAAAAAgBQABAAAAAAQAAAAAAAAQgBAAAAgBIAAgBIACAAIABAAIgBgBIgBABIAAAAIAAgBIABgBIgCgBIAAgBQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABIABADIgBAAIgBAAIAAABIABABQAAABAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIgBAAIAAABgAh1CFIABACIABAAQAAgBAAAAQABAAAAAAQAAgBgBAAQAAAAAAAAIgBgBIAAAAIgBABgAiPCFIABAAIAAAAIACgDQABgBgBAAQgBABAAAAQgBAAAAABQAAAAgBABQAAAAAAABgACJCEIACABIABAAIgBgCIgBAAIgDgBIAAAAQAAAAgBABQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAgBgABbB4IABAEQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABIABAEIABABQACgCABgEQAAgBABAAQAAAAAAAAQAAgBAAAAQgBAAAAAAIgCgFIABABQABAAAAAAQAAAAAAAAQABAAAAAAQAAgBAAAAIABgBIABgBIABAAIACgBIAAgBIAAgBIgBgDIgBgBIABgBIAAAAIABABIADAAIABgBIAAgDIAAgCQABAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIgDgBIgCAAIgFgBQgBgBAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAIAAAAIgBACIABACIABAAIABgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIACADQABAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIgBAEIgBABIgBAAIgBAAIAAAAIAAABIAAABIgDgCIgBgCIgDABIAAACIABgBIABAAIgBACQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABAAIABACIgBAAIgBAAgAhfCBIAAABIABABIAAgBIABgCgAhFCBIAAAAIABABIABAAIAAgCIgBAAgAhIB/IAAABQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAABAAIABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBAAIAAAAgAhWB+IAEACIAAAAIgEgCIAAAAgAhnB8IABABIACADIAAgCIgBgCIAAgBIgCgBgAhhB/IABAAIABAAIAAgBIgBgBQAAAAgBAAQAAAAAAABQAAAAAAAAQAAAAAAABgAhSB5IAAACQAAAAAAAAQAAABABAAQAAAAAAAAQAAABABAAIgBABIABAAQABAAABgBQAAAAAAAAQABgBAAAAQAAgBAAgBIgBgBIgHgCIgBAAIgBABQAAABAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIABAAIACAAgAhdB7QAAAAAAABQABAAAAAAQAAAAABAAQAAAAAAAAIACAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIAAgBIACABQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAgBgBAAIgCAAIgEgCIABAAIAEABQAAAAABABQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAAAIgDgCQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAIgBgCIgDABIAFACIgBADIgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAABQAAAAAAAAQAAABABAAQAAAAAAAAIABAAIgBABIAAABIABAAIADgBIgBgBQAAAAABAAQAAAAABAAQAAAAAAAAQABABAAAAgAg/B5QABAAAAAAQABAAAAAAQAAAAABAAQAAAAAAgBIACgGIAAgBIgBgCQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAABAAAAIgCAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAIAAABIABACIABAAIgCABIgBABIAAADIACgBIgBABIAAABIAAAAIABAAIgBABgAhJB2IABABIABABQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABAAIgCgCQABAAAAAAQAAAAAAAAQABAAAAgBQAAAAAAgBIABABIAAAAIABgBIgBgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQABAAAAAAIABAAIAAgEIgBgBQgCAAgDgCIgBAAIgCADIgBAEIgCAGIAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABAAIAAgBIABABgAhuBzIAAAAQAAABgBAAQAAAAAAABQAAAAABABQAAAAAAAAIABABIAAgBIAAgBIACgEQgBAAAAAAQgBAAAAABQAAAAAAAAQgBAAAAABgAhnBrIgDAJIgBABIABABIABgBIABgCIAAgDQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIACgEIAAgBgAhyByIgCAAIABACIABABQABAAAAAAQAAAAAAAAQABAAAAAAQAAgBAAAAIAAgBIgBgCgAhTBoIAAACIABAGIAAABIABAAIAAAAIAAgOQAAgBAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgDABIgBACIgBAJIABABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBQABgEAAgCIAAAAIABgBgAiGBwIgCABIAGgBIAAgBQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAgBAAAAIgFAAIgBAAIABABIABgBIACACgAh+BsIABABQABAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABIABABIABgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgDgBIAAAAIgBAAgABgBqQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAIgBABIAAAAIABAAIACAAIABgCIAAgEIgBAAQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAAAgAg/BrIABABIABACIACAAIAAgBIABgDIgDABIAAAAIgCAAgABuBkIAAACQAAAEAEABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIACgCQAAAAABgBQAAAAAAAAQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAAAAAgBQAAAAAAAAQABAAAAAAIABAAIACABQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIAAgBIAAAAIgHgBIgCAAIgDAAgAg8BmIgCABIAAAAIAAABQABAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAAABIADAAIABgBIAAgDgAg4BoIABAAIABAAIgBgCgAh+BmIABACIABgBIgBgBgABrBjIAAAAIACABIABAAIAAgBIAAAAIgDgBgABpBjIABAAIgBgCIgBgFIAAgBIAAAAQAAgBAAABIgDAEQAAABAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAIAAAAIgCACIACABIAFAAIAAAAIAAgBgAhVBeIAAABIgBADQAAAAAAAAQAAABABAAQAAAAAAAAQAAAAABAAIABgBIABgBIAAgBIgBABIAAAAIgBAAQAAAAAAgBQgBAAAAAAQAAgBABAAQAAAAAAAAIACAAIgBgBIgBAAIgBAAgABvBeQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIABACQABABAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIgCgEgACBBSIgBABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAQADAGgDAGIgCADIADgBIACgBQAAAAABAAQAAAAAAgBQABAAAAAAQAAAAAAgBQACgEgBgEQgCgEgCgBIgBAAIAAAAgABuBhIgBABIAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIgBgBIAAABgAhzBiIABAAIABgBIABgBIgBAAIgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAIgBABIAAAAgAB5BdQAAABAAAAQAAABAAAAQAAAAAAAAQABABAAAAIACABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAgBABAAQAAAAAAAAQAAgBABAAQAAAAAAgBIABgGIgBgEQgBgBAAAAQgBgBAAAAQgBAAgBAAQAAAAgBABQAAAAgBAAQAAABAAAAQAAAAAAABQABAAAAAAIABACIgBABIgBAAIAAgDIgBAAIAAAAQgBABAAAAQAAABAAAAQgBABAAAAQAAABAAABIAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAgBQAAAAAAAAQAAAAABAAQAAgBAAAAQAAAAABAAgABsBfIgBABQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIABgCIgBgBIgBABgAg5BgQAAABAAAAIADAAIgBgEQAAAAgBAAQAAABgBAAQAAAAAAABQAAABAAAAgABrBTIgBABQgCAGABACIABAEIACgCQAAgBAAAAQAAAAAAgBQAAAAAAAAQgBgBAAAAIAAgBIABABIAAgCIgBgEIABgCIgBAAIAAAAgAg1BeQAAAAgBAAQAAAAAAAAQAAAAAAAAQABABAAAAIAAAAQABABAAAAQABAAAAAAQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAgABjBUQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQACACgCADIAAABIACAAQACgCABgEQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAIAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAIgCAAgAg7BdQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAIABAAIABgBIgBgBIAAgBgAhTBcIAAABIABACIACgBIABgBIAAgBIgCAAIgBAAIgBAAgABvBUIAAACIgBAEIAAACIABABQAAAAAAgBIACgIQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAgBAAIgBABgAh5BbIABABIACgCQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAABIABAAIAAABIgBAAgAiJBaIABACIABgBQAAgBAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAIgBABgACGBVIAAABIABAEIAAABIAAgGIgBAAgAhZBZQAAABgBAAQAAAAABABQAAAAAAAAQAAAAABAAIADAAIAAAAIAAgBIgCgBIgCgBgAg4BSIgBABIAAADIAAABIAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIgBgCIABgEIABgBIgBgBIAAAAgABcBTQAAAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIADABQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAgBIAAgBQAAAAABAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIgBgBIAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAIgBgBIgBgBIgBABgAh7BVIAAABIABgCIABABIABgBIgCAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAgAhhBVIABAAIACgBIgBgBIgBAAIgBACgAgGBKIgBAEIAAAFIAAABIABAAIABAAIACAAIABgBQAAgBAAAAQAAAAAAgBQAAAAAAAAQABAAAAAAIABgCQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgCIAAgBIgCgCQAAAAAAAAQABAAAAgBQAAAAAAgBQAAAAAAgBgAhfBRIgBABIABABIAAAAQABAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIgBgBIgBAAgAAfBJIgBACIAAABQACAEAEAAIABgBQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAIABgBIAAgFQABgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBgBIgEAIQAAAAAAAAQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgBgEIAAgBIAAgBgAiFBOQAAABAAAAQAAAAAAAAQAAABABAAQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBgBQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAAAAAgAh5A9IgBACIgCANIAAABIACABIAAgEIACgNIAAAAIgBAAgAAiBJIgBACIAAACIACAAIACgDQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIAAAAIgCAAIAAAAgAg6BIIABAAIAAACIACgBIACAAIAAgDQgBAAgBAAQAAAAgBABQAAAAgBAAQAAAAAAABIAAgCIgBgBIgDADIABABIAAAAIABgBIABgBIAAABgAAzBJQAAAAAAAAQAAABABAAQAAAAAAgBQAAAAAAAAQABgBAAAAQABgBAAAAQAAgBABAAQAAgBAAAAIAAgBQABABAAgBIABgCIAAgCIgCABIAAABIgDABIACgEIAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAgBAAIgJgIIgBgBIgDgFIAAAAIACAAIgBgBIgBgBIAAAAIAAgCIABAAIABgBIAAgBIgDgDIgBAAIAAACIgDAAIgGgBIgOgBQgBAAABAAIgBAAIAAABQAAABAAAAQAAABgBAAQAAAAAAAAQAAABgBAAIAAgCIAAgBIAAgBIgCAAIAAgCIgBABQAAAAAAABQAAAAAAAAQAAAAgBABQAAAAAAAAQgCACgDAAIgBAAQgBAAgBgBQAAAAAAAAQAAAAAAAAQgBABAAAAIAAAAQgFAAAAADIgCAGQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIACAAIgDAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAIAAgCIgBAAIgBAAIAAACIAAAAIgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAABAAAAIAAACIAAABIgBgBIABAAIgBgBIAAABIAAACIgBADIAAACIABAAIABgBIACgFIABAAIABgEIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAAAAAQABABAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAgBIABAAIgBABQgBAAAAABQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAABQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAAAIABgGIAAgBIgCgCQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAAAIABAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABgDIABgBIABAAIACgBIAFgBIAAAAIABABQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAgBAAIgBABIgBAEQAAABAAAAQAAAAAAAAQAAAAAAAAQAAABABAAIABAAIgCABIAAACIABABIAAAAQAAAAABABQAAAAAAAAQAAAAAAAAQgBABAAAAIgBAAIgBABIABABIAAAAQAAAAgBABQAAAAAAAAQgBAAAAABQAAAAAAAAIABACIAAABIABAAIACgDIADgHIAAgBIgBgBQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAgBIACgEIAAAAIAAABIABAAQABAAAAABQAAAAABAAQAAABAAAAQAAABAAAAIABABIAAgCQABAAAAAAQAAgBAAAAQABAAAAAAQAAAAAAAAIADAAIACAAIAFAAIADAAIAAABIAAAAIgBAAIgDAAIABABQAAAAABABQAAABAAAAQAAABAAAAQAAABAAAAIgBACIAAACIACgDIABgBIAAABQAAABAAAAQAAABAAAAQAAABAAAAQgBAAAAABIAAAAIABABIAAgBIACgEIABgBIAAABIgBADIgBADQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAgBIAAAAIAAgCIACAAIAAgBIAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAgBIABgBIAAAAIgBACIABABIABACIAAABIACgCIACgBIgCACIACgBIAAADIABgCIgBAIIABAAIAAgBIABABgAhZBJIABgBIgEgBgAgBBFQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAgCIgBABIAAAAIAAABgAg4BGIAEgCIgCgCQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAABAAAAIgBAAIAAgCIAAgBQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIAAABIACgBIABgBIgCAAIgCgBIAAgBIgBABIgCAFIgBABIAAACIABAAIACgCQAAAAAAABQABAAAAAAQAAAAAAABQgBAAAAABgAAYBEIACABIACgFQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABgBIAAAAIABgEIAAAAIAAgBIgDgBQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAABAAAAIgBAGIABgGIgBgBIgDAGIACgEIgBgBIgBAAIAAgBIABgBIgBgBQgBAAAAAAQAAAAAAABQgBAAAAAAQAAAAAAABIgBADQgBAFABABIgCACIAAABIABABIABgBIACgCIgBACIAAABIADAAIABAAQAAgBAAgBQAAAAAAgBQgBAAAAAAQAAgBAAAAIAAAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABAAIACgBIAAABIABABIAAABIgBgBQAAABAAAAQAAAAAAABQAAAAAAAAQAAABABAAIgBAAIAAABIAAABIAAAAgAAHBEQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIACgBIABgBIAAgDIAAAAIgCABIgCADIAAAAgAAqBDIAAABIABAAIABgCIAAAAIgCABgAh0BDIAAAAIACABIgBgCIAAAAIgBABgAgBBAIgBADQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIACgBIAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAAAAAAAIgBAAgAAPA4IgCACIgBACIAAABIgBAFQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIABgCIACgDIgDAGIABAAIABgBIACgHIgBABQACgDgCgCIgBAAIAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABgAgPBAIgCABIAAABQAAAAAAABQABAAAAAAQAAAAAAAAQAAgBABAAIABgCIgBgBIAAABgAhnA9IADABIABABIADACIAAABIAAgBIAAgFIACgDIACgBIgBgCIgBgBIgCABIAAABIgDgBIgBgBIAAgCIgBAAQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAAAIgBABIAAABQABABAAAAQAAAAAAAAQABAAAAAAQAAAAABAAIAAAAIACAAIABACQAAAAAAAAQAAABAAAAQAAAAgBAAQAAABAAAAIgBAAIABAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAABAAAAIAAACIgBABIgCgBIAAgDIgBgBIAAACQAAABgBgBIgDgBIAAACIAAABIAAgBIABAAIABAAgAhWA9QABABAAAAQAAAAAAABQAAAAAAABQAAAAAAAAIABABIABgBIABgCIgBgCIABgBQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAIAAgBIAAgBIgBAAIAAABIgDAGIABABIAAgBIADgBIgDABgAADA/IACACQAAgBAAgBQAAAAgBgBQAAAAgBgBQAAAAgBAAgAAeBAIACAAIABAAIAAgBQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBIgCADIAAABIgBAAIAAABgAguA9IAAAAIACACIABABIAJAAIAAAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAgBIAAAAIgDgEIgBgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAgBAAIgBAAgAgTA8IACADIABABIAAgCIgCgCIgBgBgAArAxIABACIACADIAKAHIAAABQABAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAIAAgBIgBgBIgNgLIgBgBgAgcA8IAAABIACAAIAAAAQABgCAEAAIABAAIgBgCIgCAAIgBgBIAAgBIgBgBIAAAAgAgCA8IACgCIABAAIAAgCIAAgCIABAAIgBgBIAAABIgBABIAAABQAAAAABAAQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQAAgBAAAAIgBgBgAhDA8IgCgCIABgBIgCAAIAAgBQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAgBAAAAIAAAAIgBABIgBgBIgBAAIgBgBIgBAAIAAACIABABIABABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAgBIACABIABABIADABgABnA3IgBABIAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAAAAAQAAAAAAgBIgBgDgAAEA4IABACIABgBIAAgEIAAAAIgDgBQAAgBgBAAQAAAAAAAAQgBAAAAAAQgBAAAAABIAAAAIABABQABAAAAAAQAAAAABAAQAAABAAAAQAAAAgBABIAAAAIAAABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIABgBgAgRAzIAAABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABABAAQAAAAAAAAQAAAAABgBQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAgBAAIgBgCIAAgBQABAAAAAAQAAAAAAAAQAAAAAAgBQAAAAgBAAIAAAAIgBABgAgVA0IgBABIgBABIABABQABAAAAABQAAAAAAAAQAAAAAAAAQABgBAAAAIABgBQAAAAABAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIgCgBIAAgBIAAAAIgBABgABRA2IABABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABgBIgBAAIgBAAIAAgBIAAAAIADAAIABABQAAABABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIAAAAQABgBAAAAQAAAAABAAQAAgBAAAAQAAAAAAgBIgBgBIgCAAIAAABIAAAAIgEAAIgBAAQAAAAgBAAQAAAAAAABQgBAAAAAAQAAAAAAABgAg+AmIgBADIAAACIADADQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgDADIAAABIACABQABABAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIACgCIAAgCIAAgBIgBgFIAAgBIABgBIADgBIAAgBIgBAAIgFgCgABgA0QAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIABAAQAAABABAAQAAAAABAAQAAAAAAAAQABAAAAgBIAAAAIgBAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIgCAAgAgOA0QAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAABAAIAAgBIgBgBgAgYAxQAAAAAAABQAAAAAAABQAAAAAAAAQAAABABAAIgBABIAEgDIAAgBIgCgBIgBAAgAgSAvIgCADQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIACABIABgBIgBgBQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIABAAQgBgBABAAIABAAIAAgEIAAAAIgBABIAAABIAAAAIgBgBQAAAAABAAQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAIgBABIACACIAAAAIABgBIACABgAgjAyIgBABIABAAIABABQAAAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIAAAAIgBAAgAg4AzIACABIADgBIABgBIgBgCIgEABIAAAAQgBAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAgAgQAwQAAAAAAABQAAAAABAAQAAABAAAAQAAAAABAAIACABQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIgBgBIABAAIgDgBgABUAxIgBABIABABIABgBIAAgBIgBAAgAAGAxIgBABIgBABIACAAIABgCIAAgBIgBgCIgDABIgBAAIgBAAQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIAAAAIACgCIgBgBQABAAAAABQAAAAAAAAQAAAAAAAAQAAABAAAAIABAAIABAAgAhAAyIAAABIABgCIgBAAIAAABgAgbAvIgBACIAAAAIACABIABAAIABgEIgBgBgAgNAuIAAABIABAAIACABQAAAAAAAAQABAAAAAAQAAAAAAAAQgBABAAAAIABAAQAAABAAgBIABgEIAAgBIgCAAIgBABIgBAAIgBgCIgCAAIAAACIACAAIABABIgBAAgAgeAtQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAgBAAIAAAAQABAAAAABQAAAAAAAAQAAAAAAAAQAAABgBAAQABAAAAAAQABgBAAAAQABAAAAgBQABAAAAgBIgBgBIgBgBIAAAAIgBABgABVAvIADAAIACAAIABABQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAgBAAIgBgDIgBgCIAAgBQgBAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIgBAAQAAAAgBABQAAAAAAAAQAAAAAAAAQAAAAgBAAIgCgDIAAAAIAAgCQAAgBgBAAQAAAAAAAAQAAAAAAAAQABgBAAAAIgBAAIgOgDIgCAAIgBgBQAAAAgBgBQAAAAAAAAQAAAAAAABQgBAAAAAAIAAACIABAFQAAAAAAAAQAAAAAAABQAAAAAAAAQAAABABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIACgBIACABIAAABIABAAIAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQABgBAAAAIAAABIAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIABAAIAAABIgBAAIADABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIABgBIACgCIAAACIACABIACAAIgBACIgBgBIgCAAQgBAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIgBAAQAAAAAAAAQgBABAAAAQAAAAABAAQAAABAAAAIADAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABACgAgiAvIAAAAIACgBIAAgBIAAAAIgDgBIgCACIABAAIABAAIABABgABgAtIAAABIAAAAIABgCQAAgBgBAAIgBAAIAAAAIgBAAIAAABQAAABAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQABABAAgBIAAgBgAA/ArIABABIACABQAAAAAAAAQAAgBABAAQAAAAAAAAQAAgBAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIAAgBIgCgBIgCgBQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAQAAAAAAABIACAAQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAAAIAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIgDAAIAGADIABgBIACAAgABwAqIABAAIgBgBIgBgBgAgcAlIgBAEIAAABIACgBIAAgCIAAgCIgBgBIAAABgAghApIABAAIAAgDIAAgBQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABIAAABIAAABIABgBIAAgCIABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIAAgBIAAABQAAAAgBABQAAAAAAAAQgBAAAAAAQAAAAgBAAIAAAAIgBAAIgCABIAAABQAAABAAAAQAAABAAAAQABAAAAAAQAAAAABAAgABbAkIAAACQgBAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIABAAIACgEQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAAAgBIgCgCIgDgBIADADQAAAAAAAAQABAAAAABQAAAAAAAAQABAAAAABIgBgBIgCABgAA5AoIABAAQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBIABgBIABAAIgBgBIgBAAIAAAAQgBAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQAAAAAAABIACAAIgBgBIgDgDQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAABgBAAIAAABIAAABIgBAAIgCABQAAABgBAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIABgCIABAAIAAgBQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAABIgCAAIAAAAIAAgBIACgBIAAgCIAAgCQAAAAABAAQAAAAAAgBQAAAAgBAAQAAAAAAAAIgCABIgCABIABgCIAAAAIAEgDIAAAAIAAgBIAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAgBAAIgBAAIgDAAQAAgBgBAAQgBAAAAAAQgBAAAAAAQAAAAgBABIgDAAIgBABQAAAAgBAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAADIABAEIAAABIAAACIABACIgBABIgBAAIgCgBQAAABAAAAQAAABAAAAQABAAAAAAQABAAAAAAIACABIACADIABAAIAAgBQABAAgBAAIgCgDIACgBQAAACADACIABgBIADgFIABgBQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIABADQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIABAAIAAABQgBAAAAABIABAAQAAABAAAAQAAAAAAAAQABABAAAAQAAAAABAAIABgBIAAAAIABABgAhFAjQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIABABIABACIABAAQABAAAAAAQABAAAAgBQAAAAAAAAQABgBAAAAIgBgCIgEgBIgBAAgAAAAlIgBAAQAAABAAAAQABAAAAABQAAAAAAAAQAAAAABAAIADgBQgBAAAAgBQAAAAgBAAQAAgBgBAAQAAAAAAAAIgBABgABvAlIgBABIABABIABgBIAAAAIgBgBIAAgBgAAAAiIAAABIAEAAIgCgBIgBAAIAAAAIgBAAgAhUAZIgCABIAAABIADADIAAgDIAAgBIgBgBIAAAAgABmAcIABABIAAgBIAAgBgABaASIAAABIABABQABABAAAAQAAAAAAABQABAAAAABQAAABAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAIACAEQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAAAIgBgCIgCgEIADADIAAgDQAAgBgBAAQAAAAAAgBQgBAAAAAAQgBAAAAgBIAAACIgBgBIgBgBIAAAAgABJAWIAAABIAAABIAAADQAAABAAAAQAAAAABAAQAAABAAAAQAAgBAAAAIAFAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAgBgBIABgBIAAgBIAAgEIAAgBIgBAAQAAAAgBAAQAAAAAAABQAAAAAAAAQAAAAAAABgABPAaIABABIAAAAIABAAIAAAAIAAgCgAhdAZIACABIAAgBIAAgBIgDAAgAA5AJQgCADABAEIACADIAEADQADACAEgCIABgBIgBAAIgDgBIgBAAIgBAAIgCgBIABAAIAAgCIAAgCIABAAIgBgCQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAIgBAAIAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIgBgBgAgyAXIABgBIABAAIAAgBIgBAAIgBACgABOATIAAAAIABAAIAAgBIgCAAIABABgABFAOIAAABIgBAAIgBABIACAAQAAABAAAAQAAABAAAAQABAAAAAAQABABAAAAIABgBQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIgBgCIgDgCIACABIABgBIAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAAAgBAAIgGAAIADABQAAAAgBABQAAAAAAAAQAAAAAAAAQAAgBgBAAIgCAAIgBAAIACACIABAAIACgBIAAgBIABgBgAhNAKIgCABQAAABAAAAQAAAAAAAAQAAABAAAAQgBAAAAAAIAAABIAAACQAAgBABgBQAAAAABAAQAAgBAAAAQABAAAAAAIADACQAAgDgBgCIgBAAIgBAAgABHAJQAAAAAAAAQABAAAAAAQAAABAAAAQAAAAAAABIABABIABABIAAABIABABIAAgBIAAgDQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAIgBAAgAhJAOIABAAIAAgBIAAgBIgBgBQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAABABgABCALQAAAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIADAAIABAAIAAgBIgBgCIgBgBQAAgBAAAAQAAAAAAgBQAAAAAAAAQgBAAAAAAIgBgBIgDAAIACABQAAABgBAAQAAABAAAAQAAAAAAAAQAAAAgBAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQgBAAAAAAIgBAAQAAAAgBAAQgBAAAAAAQgBABAAAAQAAABgBAAIAAABIADADIABAAIADAAIAAAAIABAAgABRAKIABgBIACABIAAAAIgEgEIgDgBQAAAEAEABgAhOAIQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAIAAgBIgBgBgAg4AEQAAAAAAABQAAABAAAAQAAABABAAQAAABABAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAgBIABgBIACAAIAAgBQAAAAgBAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAABgBAAIgCgBIgBAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAgAAxAAIAAAAIABAHIABABQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIABgCIAAgBQAAAAABAAQAAgBAAAAQAAAAABAAQAAAAAAAAIABABQAAAAABgBQAAAAAAAAQAAgBABAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBAAAAAAIgBgBIgBAAIgDAAIAAgBIAAgBIABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgBgBIgCgBIAAgBIABAAIABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIAFAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIAFACQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAIgBABIAFAAIgBgBIABgBIgBgDIgBgCIgBAAIgBABQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIgCAAIABAAIACgCIABAAIAAgDIgBgCIgCgBIAAACQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAAAAAABQgEABgDgCIgCAAIgCAAIgBAAIAAABQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAgBAAIAAABIgCABQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAgBIgBgCQAAgBAAAAQAAgBAAAAQAAAAAAAAQAAgBABAAIAAAAIgBAAIgCgBIAAAAIgBABIADAGQAAABAAAAQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQAAAAAAABIACADIgBAGIAAABIAEAAQABAAAAAAQABAAABABQAAAAAAAAQABAAAAAAIAAABIgBAAIAAgBIgBAAgAhFgBIAGAEIAEACIAAAAIABAAIAAgBIgDgBIABgBIACABIABABQAAgBAAAAQABAAAAAAQAAgBgBAAQAAAAAAAAIgBgCIAAAAIAAgBIgBABIAAAAIAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBAAAAAAIgFAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAgAhlgDIAAACIgBADIABABQAAABAAgBIABgBIABAAIAAgCIAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIAAAAQABgBAAAAQAAAAAAgBQAAAAgBAAQAAAAgBAAIAAAAgAgnACQABABAAAAQABAAAAAAQAAAAAAAAQABgBAAAAIAAgBQgBAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBAAIAAAAIgBACgAhUAAIADABQABABAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABgCIgBAAIgCgBQAAAAAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAIgCAAgAg7gNQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABABAAABQAAAAAAABQAAAAAAABIAEACIABAAIAAACIAAABIACABIABAAIAAAAIgBgBIACAAIgBgBQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBIABABIACABQAAAAAAABQABAAAAAAQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQAAABAAAAIAEACQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABAAIABgBIABgFIACgCIACgBIAAgCQABAAAAgBQAAAAAAAAQAAAAAAAAQAAgBgBAAIABgBQAAAAAAABQAAAAABAAQAAAAAAgBQAAAAAAAAIgBgBIgBgBQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAAAABAAIACgCIACgCIACgGIgBgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQABgBAAAAIAAgBIAAAAIAAgBIgBgBIABgBIABgBIgBgBIgBABIgBADIgCACIAAAAIAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgBABIgEADIgBACIACAEIAAABIABAAIAAABQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIAAgBIABgBIABgCIAAgBIACgCIADgDIAAABIgBABIgGANIAAABIABAEIAAABIgBgBIgBAEIgEABIACgBIABgBIgBgBQAAAAAAgBIABAAQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAIAAgDIgBABIgBABIABgCQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAAAAAIgCgDIADACIgBgDIgBgEIgBgBIgCABQAAAEACABIgCABIgBABIgBgBIAAgBIABAAQABgDgBgCIgCACIABgEIABgCIABgFIAAgCQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIABgBQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIAAgBQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIABABIAAABIAAAAQAAAAgBgBQAAAAAAAAQAAAAAAABQAAAAAAAAIgBAEQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAABIABgBIAAgBIAAgCIAAAAQADgCAAgDIABgBQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAAAgBAAIgCgBIgBAAIAAAAIAAgBIABABIACAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIgBgHIgBAAIAAAAIAAABIgBACIAAADIgBAAIAAgBQABAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAIAAgBIAAgDIAAgBIgGgCIABAAIADAAIABABIABAAIAAgBIgBgCQAAgBgBAAQAAgBAAAAQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAgBAAAAIADABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIgBgBIAAgCIABgFIAAAAIgBgBIgBAAIgBABIAAgBIAAgBIgBABIgBACIgCACIgCACQAAABgBAAQAAAAAAABQAAAAAAABQAAAAAAABIABADIgEAAIgBABQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIABgBIABABIABgBIgBgDIgCACIgBACIAAACIABAAIABABIgBAEQAAABAAAAQABABAAAAQAAAAABABQABAAAAAAIADAAQgBABAAAAQAAAAgBAAQAAABgBAAQAAAAgBAAIAAACIAAABIgBgBIgBgCQgBgEgCgBIgBAAIAAgCIAAgCIACAAIgBAAQAAgBAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgCAAIgBAAIAAABIAAABIgBACQgBAAAAABQAAAAgBAAQAAABAAABQAAAAABABIAAACQAAABAAABQAAAAAAABQAAAAABABQAAAAAAAAIABACIAAABIABAAIAAACIgBABIAAABIgBARIABABIABgCIAAABIABABIAAACIAAgCQAAgBABABIACAAIAAAGIAAgEQAAAAABAAQAAgBAAAAQAAAAABAAQAAAAAAAAIABABIgBAGIAAAAIgBAAIgCgBgAhVgEIABABIABAAIAAgDIAAAAIAAAAgAhYgXIgBAFIgCAFIgCAGIgBACIAHACIABAAIAAgBIgBAAIgCgBQgCgCABgDQAAAAABgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABABQABAAAAAAQABABAAAAQAAABAAABIABABIABgCIAAgBQAAAAAAAAQABAAAAgBQAAAAAAAAQgBAAAAgBIABgBIABAAIAAgBQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAABAAAAIgCABIgBgBQgDAAgBgEQAAgDADgBIABAAIgDgBIgBgBQAAAAgBABQAAAAAAAAQAAAAAAAAQAAAAAAABgAA2gEIABgBIABgCIgCABIgCABIAAAAIAAABIAAAAIABgBIABABgABAgOQAAABABAAQAAABAAAAQAAAAAAABQAAAAAAAAIAAACQAAABAAABQABAAAAABQAAAAABAAQAAABABAAIAAAAIABAAIABgBIAAgBIgCgBQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAgBIgBgCIABAAIABgBIABgCIgGACgAhcgZIgBACQgBAAAAAAQgBABAAAAQAAAAAAABQAAAAAAABIgBAEIgBABQAAAAAAAAQgBABAAAAQAAAAABAAQAAABABAAIgBABIAAACIAAACIgBABIABABIABAAIACgGIgBgCIgBgBIABgBQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAgBAAIAAgBIABgBQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAIgBgBIABAAQAAAAABAAQAAAAAAgBQABAAAAAAQAAAAAAgBIACgDIgBAAIgCABgAhEgPIgBABIACACIABgBIAAgBQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAgBAAgAA+gTIAAABIABACIABABIAHgCIABgBIgDAAIgDABIAAgBIABgCgAhJgZIABAAIAEADIABADIAAABIAAABIAAAAIAAAAIABgCIgBgDIAAgBIgEgDIgBAAgAhLgSIABAAIACABIAAAAIABAAIAAgBIgDgBgAhLgVIAAABIABABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAgBIAAgBIgCgBgAhIggIgBABIAAACIAAABIABAAIACABIABAAIAAgBIgBgBIAAAAIgCgBIAAgBIABgCIAAgBIABAAIABAAQAAAAAAgBQgBgBAAAAQgBAAAAgBQgBAAgBAAIgBAAIAAABIABABQAAAAABAAQAAAAAAABQAAAAAAAAQAAAAAAABIgBgBIgBABIABABIABAAIAAAAgAgogfIgBACIACABIACgBIABgDIAEAAIgCgBIABAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAIgDgBIgBAAQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAgAAogiIABAFIABAAIgBgDIACgBIADgDQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgDABIAAADIgCgBgAhOggIAAABIACAAIABgBIgCgBgABBghIABAAIABgBIAAAAIgBgBIgBACgAhFgiIACABIAAgBIgBgCQgBgDgEgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBgBAAIgBADIAAABQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAAAAAIgCACIABABQAAAAABAAQAAAAABgBQAAAAAAAAQAAAAAAgBIABAAIAAAAIAAACIABgBQgBgDADABQADABACACIAAABIgBAAgABTgrIgBABIgBAAIAAABQAAABAAAAQABABAAAAQAAAAABABQABAAAAAAIACgBIAAgCIgCgCIAAAAIgBAAgAhDgnIABAAIABgBIgBgBIgCgBgAgdgrIgBABQAAABAAAAQAAAAABABQAAAAAAAAQAAAAABAAIABgBIgBgCIgBAAgAArg3IgCABIAAACIAAAAIADgBIAAAAIAAgBIABABIgCgCgAgRg/IAAACIABAAQAAAAAAABQAAAAAAAAQABAAAAAAQAAgBAAAAQAAAAgBAAIAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAAAAAgAg8g+IAAABIACAAIABAAIgBgBIgBgBgAAbhCIgBABQAAABAAAAQAAAAAAAAQAAAAAAAAQABABAAAAIAAABQABAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIABgBIAAgEIgBgBIgCACIABgCIABgBIgBAAIgCAAIAAABIgBACIgBAAIgBACIAAACIgBABIABAAgAgQhBIACACIAAgBIAAAAQgBAAAAAAQAAgBAAAAQgBAAAAAAQAAgBAAAAQAAAAgBAAQAAAAAAAAQAAABAAAAQAAAAABAAgAAXhKIgCAAIAAAGIACABQAAAAAAABQAAAAABAAQAAAAAAgBQAAAAAAAAIAAgBIABgBIgBgBIAAgEIAAgBIgBAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAgAAmhEIABAAIgBgCQAAABAAAAQgBAAAAAAQAAABAAAAQAAAAABAAgAAphOIAAACIABgBQAAAAABAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgBABIgBgBIAAABgAAIhfQAAAAAAAAQgBAAAAAAQAAABAAAAQABAAAAAAIABABIAAgCIAAAAgAA8hkIABABIADAAIgDgCgAA1hlIACABQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIACAAIABgBIgBAAIgCAAIgDgBIgBABgAAghnIABABIACAAIABAAIgBgBIgCgBgAAchtIACACQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAgBQAAAAAAgBQAAgBAAAAQgBAAAAgBQgBAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAAAQAAABAAAAgAgwhwQgBAAAAABQAAAAAAAAQAAAAABAAQAAAAAAAAIACAAIgCABIADABIACABIABAAIgBgBIABgBIAAgBIgFgBIAAAAIgBAAgAg4hwIABADQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAQgBAAAAgBQAAAAAAgBQgBAAAAAAQAAAAgBAAIgCgBgAgDhxIACABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAgBAAAAIgBgCIgBABIAAAAIgBAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAgAg4h0IABACIAAAAIAFACIAAAAIAAgBIAAgBQABAAAAABQAAAAAAAAQAAAAAAAAQAAgBAAAAIAAgBQgCgBgDAAIgCAAgAgDh4QAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIABACIgBABIACAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIABgBIAAgBIAAgBIAAABIAAAAIgBgBIAAgBIgBgBIgDgCIADgBIAAgCIgCgBIgCgEQgBgEgEABIgBAAIgCgBIAEAAIAAAAIAAgBIgBAAQgBABAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAIAAAAIgBAAIABACIgCABQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIgCAAIAAABIABABQAAAAABABQAAAAAAAAQAAAAAAAAQABAAAAAAIAAAAIADABIgBgDIAAgBIABAAIABACIAAACIAAACIACAEIABABIACgBIAAACIAAAAIAFACgAgGhzIADAAIAAgBIgBgBIAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCAAIABABgAguh2IABABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIACgDIgBgCIgBgBIgFgDQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIgBABIgBACIgBACIAFAEIABAAIAAgCgAgLh6IABACQABAAAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAgBAAgAASh5IACgBIgCAAIAAABgAgBh8QAAABAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABgBIgBgBIABgBIAAAAIABgBIAAgBQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIgBgCIAAgBIAAgBQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAAAAAIAAAFIABABQAAABgBgBIAAABgAgEiEIgBABIABABIABABIABgBIAAgBIgCgBIAAAAgAApiDIACABQAAAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAIAAgBIgBgBIACAAIACgBIAAgBQAAgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIABAAIACgBQAAAAAAgBQABAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAAAAAAAIgFABIgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAABAAAAIAAABIgCAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAABAAIAAgBIgBAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAgBgBIgBAAIAAABIACACQAAABAAAAQAAAAAAAAQAAABABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAABIACABQABAAAAAAQAAAAAAAAQABAAAAAAQAAABAAAAIgBgBQAAAAAAAAQAAAAgBABQAAAAAAAAQAAAAAAABgAgEiGIABABIABgBIgBgBQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAAAgAABiMIAAgCIAAgCIgBgBIABAFgAgDiOIABAAIABAAIAAgBQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAAAgBAAgAgUiQIABABIABAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAAAAAAAgAAwiWIgBACIAAABIABAAIACgBIAAgBIAAgBIgCgBgAgmiZIABABIAAABIAAAAQABAAAAAAQAAgBAAAAQAAgBAAAAQAAAAgBgBIAAAAgAgpibIABABIABAAIAAgBIgBAAIAAgBgAhcCLIAAAAgAAEBIgAg4BDIAAAAgAAZA9IAAAAgAh9A2gAhoAMgAAHiSIAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAIgBACIgBgCg");
	this.shape_127.setTransform(168.275,167.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25}]},61).to({state:[]},7).to({state:[]},33).wait(77));

	// 2-T-2
	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AAhCoQgNAAgLgKQgJgKAAgNQAAAOgJAJQgLAKgNAAQAAgOAKgKQAJgJAOgBQgNAAgKgJQgKgKAAgPQAAgNAKgKQAJgKAOAAQgNAAgKgJQgKgKAAgPQAAgOAKgJQAJgKAOAAQgOAAgJgJQgKgJAAgPQAAgOAKgJQAJgKAOAAQgOAAgJgKQgKgJAAgPIAAAAQgOAAgKgJQgJgKAAgOQAAAOgKAKQgKAJgOAAQAAgOAKgJQAJgKAOAAQgNAAgKgKQgKgJAAgPQAOAAAKAKQAKAKAAANQAAgNAJgKQAKgKAOAAQAOAAAKAKQAJAKAAANQAAgMAJgLQAKgKAOAAQAOAAAKAKQAKAKAAANQAAgMAJgLQAKgKAPAAQAAAOgKAKQgLAKgNAAQAOAAAKAKQAKAKAAANIgBAAQgOAAgKgJQgJgLAAgNQAAAOgKAKQgKAJgOAAQAAAPgKAJQgJAKgOAAQANAAAKAKQAKAJAAAOQAAAPgKAJQgJAJgOAAQANAAAKAKQAKAJAAAOQAAAPgKAKQgJAJgOAAQANAAAKAKQAKAKAAANQAAAPgKAKQgKAJgNAAQAOAAAJAKQAKAKAAAOgAgJBbQgKAJgNAAQANAAAKAKQAJAKAAAOQAAgNAJgLQAKgJANgBQgNAAgKgJQgJgLAAgNQAAAOgJAKgAgJAYQgKAJgNAAQANAAAKAKQAJAKAAANQAAgMAJgLQAKgJANgBQgNAAgKgJQgJgLAAgNQAAAOgJAKgAgJgqQgKAJgNAAQANAAAKAKQAJAKAAANQAAgMAJgLQAKgJANgBQgNAAgKgJQgJgLAAgNQAAAOgJAKgAgJhtQgKAJgNAAQANAAAKAKQAJAKAAANQAAgMAJgLQAKgJANgBQgNAAgKgJQgJgLAAgNQAAAOgJAKgAAXiPQgKAKgNAAQAOAAAJAKQAKAJAAAOQAAgNAKgKQAJgKAOAAQgNAAgKgKQgKgKAAgNQAAAOgKAJgAgriPQgKAKgNAAQAOAAAJAKQAKAKAAANQAAgOAKgJQAJgKAOAAQgNAAgKgKQgKgJAAgOQAAANgKAKg");
	this.shape_128.setTransform(192.975,167.425);
	this.shape_128._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_128).wait(65).to({_off:false},0).to({_off:true},5).wait(108));

	// 2-O-2
	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AgMChIgCABIgBAAQgGAEgGAAQgLAAgHgJIgGABQgJAAgHgHQgHgGgBgJQgDgBgDgCIAAAAIABgBIAGgFIACgBIADgGIAAgCQACgDAAgEQAAgLgKgIIAAgBIAAAAIgBAAIAAgBIgFgCIADgKIAAgBQADAHAAAFIAAABIAIgBQAKAAAGAGQAHAGABAKQAHABAFAGIAGAAQAGAAAHADQAGgHAKAAQAFAAAFACQAGgJALgCQAGgQAQAAIAHABQAEgEAGgCIgBgEQAAgOANgHQACgLAIgFIAAABIAAACIACAKIAAABIABAAQAFAMAOABIABABIACAAQAFAAAGgDIAAAAIABgBQgCALgKAGIAAABIgBgBIAAgBIAAAAIAAgBQgIgMgOAAQgDAAgFACIgBAAIgBABQgHADgEAHIgBABIAAABIgBACIAAABIgBAHIAAACQAAAIAGAGIABABIAAABQAIAHAJAAIADAAQgGAJgLACQAAAKgHAGQgHAHgKAAQgFAAgHgDIgKACIgDgBIABAAIAAgCQAAgIgFgGIAAgBIgBgCQgFgFgJgDIgBAAIgEAAQgGAAgGADIABACIABABQAFgDAFAAIADAAIACAAQAJADAFAIIABABIAAACIACAIIAAACQgBAIgGAGQgHAFgIAAQgMAAgFgKgAhrB+QgHgGAAgJIAAgDIADgJIAGABQAMAAAIgKIAEACIABAAIACACIABABQAHAHAAAJQAAANgNAGIAAABIgBAAQgEABgEAAQgJAAgGgGgABcB1QgLAAgGgJIgBgCIgCgFIgBgGIAAgCIAAgDIAEgHQADgGAGgCIAAAAIABAAQADgCAEAAQANAAAGALIAAAAIABABIABACIAAABIAAABIABAGQAAAIgFAGQgFAGgHABIgBABgAh9BaIACACQAEAEAFADIgCAGIAAABIgBABQgHgHgBgKgAhtBhIgDgBQgHgDgEgGIgBgCQgDgFAAgFIABgEIgCgBIgBAAQgKgIAAgMQAAgKAHgHIgBgHIAAABIAEACIABAAIAAAAIACAAIABABIAGABQAFAAAFgDIABAAIAAgBQAGgCAEgGIAAgBIAAgBQACgDABgGIAAgCQAJAIAAALIAAAEQACAEAAAGQAAAJgGAIIgBgBIgBAAIAAAAIAAABIgBABIAAAAIABABQAHAGACAJIAAACQAAAHgDAFIgBABIgBABQgHAIgKAAgABwBDIgCAAQgIgCgGgHIgBgCQgCgFAAgFIAAgDIAAgCIACgEQABgEAFgEIABgBIAAAAQAGgEAHAAQAJAAAGAHIABABIAEAFIAAADIABABIAAAFQAAAKgIAHIgBABIgBAAQgGAEgFAAgACGAfIgBgBIAAgBQgHgIgLAAQgJAAgGAFIgBABQgEADgCAEIAAgFQAAgFACgFIAAgCIAAgDIgBgCIACgJIgBgGQgEgHAAgGQAAgFABgEIgBgIIABgHQgOgHAAgPQAAgHAEgFQgGgHAAgIQgNgBgFgLIgCgFQgDgCgDgFIgBgBIAAgBIgBgDIAAAAIAAgBIgBgEQAAgKAIgGIAAgBIABAAQAHgFAGAAIACAAQAKABAGAIIABACIACAAIACACIgBgDIgBAAIAAgBIABAAQAKAAAHAHQAHAHAAAKIAAAEQAJAIAAALQAAAFgCAEIgBAAIAAgBIgFAAIgDAAQgOABgGAMIgBABQgCAGAAAEQAAAHADAGIABABIAAAAIADAEIABABIADACIAAAAIABABQAGADAHAAQAGAAAGgDIABgBIAAAAQAEgDADgEIAAAAIABgBQADAFAAAGIgCAIQABADAAAEQAEAHAAAHQAAAEgBADIABAJQAAAIgDAFIgBACIgCABIAAABIAAAFgAh+AaIgBAAIgFgCIgBgCQgIgGAAgKQAAgGADgEIAAgBIABAAQAEgHAJgDIAFAAQALAAAHAKIAAAAIAAABIADAHIAAADQAAAGgDAEIAAABIAAABQgEAGgHACIgCABIgJAAgAhfAAIgBAAIgCgFIAAAAIAAgBQgIgMgNAAIgFAAIgBABIAAAAQgIABgFAGIgBABIAAABIAAgCQAAgKAHgHQgGgHAAgJQAAgJAHgIIgBgGQAAgHAFgHQAFgGAHgDQgDgGAAgFQAAgJAGgGQAGgHAIgBQACgOANgGIAAABIgBABIAAAFQAAAIAFAHIABACQAGAGAJACIABAAIABAAIACAAIAGgBIAAAAIABAAQgBAFgEAEIABAGQAAAPgOAGIgBABIgCAAIABAFQAAAIgGAGQgFAGgIABIgFAAIgFgBIgDgBIgBgBQgIgEgCgJIAAgBIgBgEQAAgIAFgFIgBgBIgBgCQgGAHAAAJIABAEIAAABQACAJAHAFIAAABIABAAQAFAEAGAAIAHAAIAAAAIABAAQAJAHAAALQAAAOgMAHQgBAGgCADgABpglIAAAAIgCgBIgBgBQgEgCgCgFIgBgBIAAAAQgCgFAAgFIACgJIAAAAIABgBQAGgLANAAIACAAIACAAIABAAIABABQAHACAEAFQAEAGAAAHIgCAKIAAAAIgBABQgDAFgFADIgBABIAAAAIgJACIgKgCgAANh5QgFADgGAAQgHAAgFgEQgHAHgKAAQgIAAgGgEIABgBIAAAAIABgBIACgEIAAAAIAAgBQACgEAAgGQAAgLgIgHIgBgBIgDgCIAAAAIgBAAQgFgDgGAAIgDAAIgBAAQAGgGAJAAIAHABQAGgFAIAAQAFAAAEABIgBABIgGAFIgBABIAAABIgCAFIgBAAIAAABIgBAHQAAAIAEAFIAAABIABABQADAEAFADIABAAIAAABIAGACIABAAIAEAAQAGAAAHgFIgCgCQgGAEgFAAIgBAAIgCAAIgEgBIgBAAIgCgBIgDgCQgEgCgCgFIgBgBIAAgBQgCgFAAgEIAAgDIAAgBIABgBQABgEACgEIABAAIAAgBIAFgEIABgBIABAAQAEgCAGAAQAGAAAFADIABABIABAAIAAAAIACgBQAFgEAIAAQAMAAAHAKIAGgBQAPAAAHANIgCAAQgIABgFAEIgBAAIAAABQgKAIAAALIABAGIAAABIABAAIAAABIAAABIAAABIgDgBQgEACgHAAQgMAAgHgJgAhAhyIgEgBIgGgEIgBgBQgGgHAAgJIABgGIAAgBIAAgBQAEgJAJgDIADgBIAFAAQAFAAAFACIAAABIABAAIACABIABABQAHAHAAAJQAAAFgBADIgBABIAAABIgCAEIgBABIgBABIgBABIgGADIAAABIgBAAIgHABg");
	this.shape_129.setTransform(219.625,168.125);
	this.shape_129._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_129).wait(67).to({_off:false},0).to({_off:true},8).wait(103));

	// 2-R
	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AB7CaQAAgJAJAAQAKAAAAAJQAAAKgKAAQgJAAAAgKgABnCaQAAgJAJAAQAKAAAAAJQAAAKgKAAQgJAAAAgKgABTCaQAAgJAJAAQAKAAAAAJQAAAKgKAAQgJAAAAgKgAgpCaQAAgJAJAAQAKAAAAAJQAAAKgKAAQgJAAAAgKgAg9CaQAAgJAJAAQAEAAADACQADADAAAEQAAAEgDADQgDACgEABQgJAAAAgKgAhOChQgDgDAAgEQAAgEADgDQADgCAEAAQAEAAACACQADADAAAEQAAAEgDADQgCACgEABQgEgBgDgCgAhlCaQAAgHAGgCQgFgDAAgFQAAgFADgDQACgCAEAAQAEAAADACQADADAAAFQAAAGgGADQAFACAAAGQAAAKgJAAQgKAAAAgKgAh5CaQAAgJAKAAQAJAAAAAJQAAAKgJAAQgKAAAAgKgAiNCaQAAgJAKAAQAJAAAAAJQAAAKgJAAQgKAAAAgKgABOCHQAAgKAJABQAKgBAAAKQAAAKgKAAQgJAAAAgKgAhhB8QgDgDAAgEQAAgEADgDQACgCAEAAQAEAAADACQADADAAAEQAAAEgDADQgDADgEAAQgEAAgCgDgABJB0QAAgKAJAAQAKAAAAAKQAAAKgKAAQgJAAAAgKgAhhBoQgDgCAAgFQAAgDADgDQACgDAEAAQAEAAADADQADADAAADQAAAFgDACQgDADgEAAQgEAAgCgDgABGBnQgDgCAAgFQAAgDADgDQADgDAEAAQAEAAADADQADADAAADQAAAFgDACQgDADgEAAQgEAAgDgDgAhhBVQgDgDAAgEQAAgEADgDQACgCAEgBQAEABADACQADADAAAEQAAAEgDADQgDACgEAAQgEAAgCgCgABBBUQgDgDAAgEQAAgEADgDQADgCAEgBQAEABADACQADADAAAEQAAAEgDADQgDADgEgBQgEABgDgDgAA4A6QAAgFAFgDIgEABQgEAAgDgDQgDgCAAgFQAAgDADgEQgCACgEAAQgJAAAAgJQAAgKAJAAQAKAAAAAKQAAAFgDACQADgCADAAQAKAAAAAJQAAAGgFADIAEgBQAJAAAAAJQAAAKgJAAQgKAAAAgKgAhhBCQgDgEAAgEQAAgDADgEQACgCAEAAQAEAAADACQADAEAAADQAAAEgDAEQgDACgEAAQgEAAgCgCgAhhAuQgDgDAAgEQAAgEADgDQACgDAEABQAEgBADADQADADAAAEQAAAEgDADQgDACgEAAQgEAAgCgCgAhhAbQgDgEAAgDQAAgFADgCQACgDAEAAQAEAAADADQADACAAAFQAAADgDAEQgDACgEAAQgEAAgCgCgAAWAVQgDgDAAgEQAAgFAEgDQgEgCAAgEQAAgEADgDQADgDAEAAQAEAAACADQADADAAAEQAAAEgEACQAEADAAAFQAAAEgDADQgCADgEgBQgEABgDgDgAgoAFQAAgIAJAAQAKAAAAAIQAAAKgKAAQgJAAAAgKgAg9AFQAAgIAKAAQAJAAAAAIQAAAKgJAAQgKAAAAgKgAhOANQgDgDAAgFQAAgDADgDQADgCAEAAQAEAAACACQADADAAADQAAAFgDADQgCACgEAAQgEAAgDgCgAgUAFQAAgJAJAAQAKAAAAAJQAAAJgKAAQgJAAAAgJgAAAAEQAAgIAJAAQAJAAAAAIQAAAKgJAAQgJAAAAgKgAhhAHQgDgDAAgEQAAgDADgDQACgCAEAAQAEAAADACQADADAAADQAAAEgDADQgDADgEAAQgEAAgCgDgAAmgKQAAgEACgDQADgDAEAAQAEAAADADQADADAAAEQAAAKgKgBQgJABAAgKgAhhgMQgDgCAAgFQAAgEADgCQACgDAEAAQAEAAADADQADACAAAEQAAAFgDACQgDADgEAAQgEAAgCgDgAA3gRQgDgDAAgEQAAgEADgDQADgCAEAAQAEAAADACQADADAAAEQAAAEgDADQgDADgEAAQgEAAgDgDgAhhgfQgDgDAAgEQAAgEADgDQACgCAEgBQgEAAgCgCQgDgEAAgEQAAgDADgDQADgDADAAQgEAAgCgDQgDgDAAgEQAAgEADgDQADgCADAAQgEgBgCgCQgDgEAAgDQAAgEADgDQADgDADAAQgDAAgDgDQgDgCAAgEQAAgFADgCQACgDAEAAQgDgBgDgDQgDgCAAgEQAAgGAFgCQgHgDAAgHQAAgKAKAAQAIAAABAJQABgJAJAAQAIAAABAJQABgJAJAAQAJAAAAAKQAAAKgJAAQgJAAgBgJQgBAJgIAAQgJAAgBgJQAAAFgFACQAHADAAAHQAAAEgDACQgDADgDABQADAAADADQADACAAAFQAAAEgDACQgDADgDAAQADAAADADQADACAAAFQAAADgDAEQgDACgDABQADAAADACQADADAAAEQAAAEgDADQgDADgDAAQADAAADADQADADAAADQAAAEgDAEQgDACgDAAQADABADACQADADAAAEQAAAEgDADQgDACgEAAQgEAAgCgCgABBgiQgDgDAAgEQAAgEADgDQADgDAEABQAEgBADADQADADAAAEQAAAEgDADQgDACgEAAQgEAAgDgCgABDg9QAAgJAJAAQAKAAAAAJQAAAKgKAAQgJAAAAgKgABDhQQAAgKAJAAQAKAAAAAKQAAAJgKAAQgJAAAAgJgABAhkQAAgFAEgCIgBAAQgKAAAAgKIABgFIgDAAQgKABAAgKIABgDQgCABgEABQgJAAAAgKIAAgCQgDAFgFAAQgEAAgDgDQgDgDAAgEQAAgEADgDQADgCAEAAQAEAAADACQACADAAAEIAAACQADgFAFABQAKAAAAAJIgBADQADgCADABQAJAAAAAJQAAADgBACIAEgBQAJAAAAAKQAAAFgEADIABAAQAKAAAAAJQAAAKgKAAQgJAAAAgKgAgFiYQAAgKAJABQAJgBAAAKQAAAKgJAAQgJAAAAgKgAgYiZQAAgKAJAAQAKAAAAAKQAAAKgKAAQgJAAAAgKgAgsiZQAAgKAJAAQAKAAAAAKQAAAKgKAAQgJAAAAgKgAh5iZQAAgKAJAAQAKAAAAAKQAAAKgKAAQgJAAAAgKgAiNiZQAAgKAKAAQAJAAAAAKQAAAKgJAAQgKAAAAgKg");
	this.shape_130.setTransform(247.375,167.15);
	this.shape_130._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_130).wait(71).to({_off:false},0).to({_off:true},9).wait(98));

	// 2-S
	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AAGCSQBJgFAAhDQAAghgbgPQgLgHgxgOQgtgLgTgPQgagVAAgnQAAglAXgWQAYgXAsgCIAAAUQhCAEAAA7QAAAdAYAQQAPAJApAMQAyAOAUANQAdAVAAApQAAAsgcAYQgaAXguACgAg2CeQgIgDgPgHQgHAAgBAQIgUAAIAAhcIAVAAIAEAuQAgAbApABIAAAUQgZgBgWgHgABHhQIgEgpQgPgLgKgEQgRgIgTgBIAAgUQAUABASAGIAVAIQAGAAABgMIATAAIAABSg");
	this.shape_131.setTransform(274.625,167.075);
	this.shape_131._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_131).wait(74).to({_off:false},0).to({_off:true},4).wait(100));

	// 1-D
	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AiOCkIAAlHIB/AAQBAAAAwAvQAuAuAABCIAAAJQAABCguAuQgwAvhAAAgAiLChIB8AAQBAAAAugtQAtguAAhBIAAgJQAAhBgtgtQguguhAAAIh8AAg");
	this.shape_132.setTransform(30.7,124.725);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("Ah8CQIAAkfIBuAAQA5AAApApQApApAAA6IAAAIQAAA6gpAoQgoApg6AAgAhSBpIBBAAQApAAAegeQAdgdAAgrIAAgFQAAgqgdgeQgegegpAAIhBAAg");
	this.shape_133.setTransform(30.7,124.725);

	this.mc_headline = new lib.mc_headline();
	this.mc_headline.name = "mc_headline";
	this.mc_headline.parent = this;
	this.mc_headline.setTransform(150.95,147.85);
	this.mc_headline._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_133},{t:this.shape_132}]},9).to({state:[{t:this.shape_133},{t:this.shape_132}]},78).to({state:[{t:this.mc_headline}]},17).to({state:[{t:this.mc_headline}]},16).to({state:[]},1).wait(57));
	this.timeline.addTween(cjs.Tween.get(this.mc_headline).wait(104).to({_off:false},0).to({alpha:0},16,cjs.Ease.get(1)).to({_off:true},1).wait(57));

	// 1-I
	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("Ag4CjIAAgQIAbAAQAGAAAEgFQAFgFAAgGIAAkEQAAgFgFgGQgEgFgGAAIgbAAIAAgRIBxAAIAAARIgbAAQgGAAgFAFQgFAGAAAFIAAEEQAAAFAFAGQAFAFAGAAIAbAAIAAAQg");
	this.shape_134.setTransform(52.25,125.15);
	this.shape_134._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_134).wait(15).to({_off:false},0).to({_off:true},89).wait(74));

	// 1-G
	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgVB4IAAjvIArAAIAADvg");
	this.shape_135.setTransform(64.675,124.9);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AhBAWIAAgrICDAAIAAArg");
	this.shape_136.setTransform(73.4,139.075);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AAWA3IAAhBIhWAAIAAgsICBAAIAABtg");
	this.shape_137.setTransform(77.75,131.375);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AhBAWIAAgrICDAAIAAArg");
	this.shape_138.setTransform(73.4,110.725);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AgVAWIAAgrIArAAIAAArg");
	this.shape_139.setTransform(82.125,115.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135}]},19).to({state:[]},85).to({state:[]},1).wait(73));

	// 1-I-2
	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AAjCjIA1g2IgSA2gAgQCjIAzg2IAjAAIg0A2gAhFCjIBohsIgRA2Ig0A2gAhFBtIAjAAIg1A2gAgiBtgAgQA3IAzg3IgRA3Ig0A2gAgQAAIAzg1IgRA1Ig0A3gAgQg1IAzg3IgRA3Ig0A1gAgQhsIAzg2IAjAAIhoBtgAAjhsIA0g2IgRA2gAhFhsIA0g2IAiAAIgzA2gAhGiiIAkAAIg1A2g");
	this.shape_140.setTransform(96.9,124.875);
	this.shape_140._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_140).wait(29).to({_off:false},0).to({_off:true},75).wait(74));

	// 1-T
	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AggCkIAAkFIhBAAIAAhCIDDAAIAABCIhBAAIAAEFg");
	this.shape_141.setTransform(118.575,124.925);
	this.shape_141._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_141).wait(27).to({_off:false},0).to({_off:true},77).wait(74));

	// 1-A
	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("ABuClQgOAAgGgJIgZg3IhjAAIgVA5QgDAHgNAAIg/AAQgIAAAAgFIABgIIBxkuQAFgOAPAAQAOAAAGAOICCEvIABAGQAAAGgLAAgAAGgaIgaBMIgBADQAAAEAFAAIA6AAQAFAAAAgEIAAgCIgihNQAAgBgBAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAABgBAAQAAABAAAAg");
	this.shape_142.setTransform(142.65,124.9);
	this.shape_142._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_142).wait(34).to({_off:false},0).to({_off:true},70).wait(74));

	// 1-L
	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_143.setTransform(179.925,139.225);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_144.setTransform(174.225,139.225);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_145.setTransform(168.5,139.225);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_146.setTransform(162.775,139.225);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_147.setTransform(162.775,133.475);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_148.setTransform(162.775,127.775);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_149.setTransform(162.775,122.025);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_150.setTransform(162.775,116.325);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AgUAVIAAgpIApAAIAAApg");
	this.shape_151.setTransform(162.775,110.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143}]},36).to({state:[]},68).to({state:[]},1).wait(73));

	// 1-I-2_1
	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFFFFF").s().p("AheCjQgHAAgGgEQgEgFAAgHIAAgvQAAgHAEgEQAGgFAHAAIAsAAIAAinIgsAAQgHAAgGgEQgEgFAAgHIAAgvQAAgHAEgFQAGgEAHAAIC+AAQAHAAAEAEQAFAFAAAHIAAAvQAAAHgFAFQgEAEgHAAIgsAAIAACnIAsAAQAHAAAEAFQAFAFAAAGIAAAvQAAAHgFAFQgEAEgHAAg");
	this.shape_152.setTransform(27.65,167.425);
	this.shape_152._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_152).wait(50).to({_off:false},0).to({_off:true},54).wait(74));

	// 1-N
	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("ABGCkIAAlHIAkAAIAAFHgAhpCkIAAlHIAjAAIAAFHgAgzhFIAAhZIBnDNIAABWg");
	this.shape_153.setTransform(53.75,167.4);
	this.shape_153._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_153).wait(49).to({_off:false},0).to({_off:true},55).wait(74));

	// 1-N-2
	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("ABcCkIiijDIAADDIhGAAIAAlHIA1AAICfDEIAAjEIBEAAIAAFHgABmCOIASAAIAAkbIgbAAIAADqIi+jqIgVAAIAAEbIAaAAIAAjog");
	this.shape_154.setTransform(82.5,167.4);
	this.shape_154._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_154).wait(60).to({_off:false},0).to({_off:true},44).wait(74));

	// 1-O
	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("AgNCgQgFADgIAAQgLAAgGgIIgGABQgKAAgGgHQgHgGAAgJQgFgBgEgDQgFADgEAAQgKAAgHgHQgHgHAAgJIABgEQgJgGAAgMIAAAAQgEgGAAgHIABgGQgMgHAAgNQAAgJAIgIQgCgDAAgFQgKgHAAgMQAAgGAFgGIgBgDQAAgLAIgGQgGgGAAgKQAAgKAHgHIgBgGQAAgIAFgGQAFgGAHgCQgDgFAAgHQAAgIAFgHQAGgGAIgBQACgPAOgFQAEgNANgDQAHgHAKAAIAGABQAGgFAIAAQAGAAAEACQAFgDAHAAQAIAAAGAGQAGgFAIAAQAMAAAHAKIAGgBQAQAAAFAOQAMAAAHALIADAAQAJAAAHAHQAHAGAAAKIgBAFQAJAGAAAMQAAAGgCAEQAIACAEAGQAFAHAAAHQAAAGgDAGQADAGAAAFQAAAEgCAFIACAHQAEAGAAAHQAAAFgCADIACAJQAAAHgEAGIAAADQAAAEgCAFQACAFAAADQAAANgLAHQgBALgLAGIgBADIACAJQAAAJgGAHQgGAGgJABQgGAKgLACQAAAJgHAHQgGAHgKAAQgHAAgFgEQgEACgGAAIgEAAQAAAJgHAGQgHAGgJAAQgMAAgHgLgAgNB5QAHgHAJAAQAHAAADACQAGgKALgCQADgHAFgEQAHgFAHAAIAHABQAEgDAGgDIAAgEQAAgOAMgHQACgKAJgGIABgFQgBgEAAgFQAAgHAEgGIAAgDIABgJQgBgDAAgEQgEgGAAgHQAAgEABgEQgBgEAAgFIABgHQgNgGAAgPQAAgGADgGQgGgGAAgJIAAAAQgNgBgGgNQgGgEgDgHIgGAAQgEACgGAAQgMAAgGgKQgFADgHAAQgHAAgFgDQgHAHgKAAQgHAAgGgFIgCABIgJAGQgCAFgFAFIABAGQAAAPgOAGIABAGQAAAIgGAHQgGAHgJABQALAHAAAMQAAANgMAHQAAAGgEAEIABADIAAABQAJAHAAALIAAAEQACAFAAAFQAAALgHAGQAKAIAAAMIAAAAQAEAGAAAHIAAACQAEgCAFAAQAJAAAHAHQAGAGABAJQAHACAFAGIAGgBQAHAAAGAEg");
	this.shape_155.setTransform(113.825,167.425);
	this.shape_155._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_155).wait(56).to({_off:false},0).to({_off:true},48).wait(74));

	// 1-V
	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#FFFFFF").s().p("AgNCjIhskhQgCgHgHgGQgGgGgHAAIgMAAIAAgRIBoAAIAAARIgvAAIBvE0gAALBwIBUjlQAKgcgZAAIgYAAIAAgRIBkAAIAAARIgLAAQgHAAgHAFQgGAGgDAIIhlEMg");
	this.shape_156.setTransform(141,167.35);
	this.shape_156._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_156).wait(66).to({_off:false},0).to({_off:true},38).wait(74));

	// 1-A-2
	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FFFFFF").s().p("ABcClIAAAAIAAhkIgDAAIAAgHIADAAIAAgGIACAAIAAgEIgkAAIAAAEIgFAAIAAgEIhpAAIAAAEIgGAAIAAgEIgkAAIAAAEIADAAIAAAGIADAAIAAAHIgDAAIAABkIAAAAQgFACgHAAIgCAAIgKgCIAAhkIgDAAIAAgHIADAAIAAgGIACAAIAAgbIgCAAIAAgHIgDAAIAAgGIADAAIAAhHIgDAAIAAgFIADAAIAAgKIACAAIAAgDQABgGAFgFIAEgCIgCgDIAGgEIgCgCIAEgEIACADIBHg4IgCgCIAEgDIACACIAHgGIADADIABgBQADgDAGgBQAGABAEADIABABIACgDIAHAGIACgCIAFADIgCACIBHA4IACgDIAEAEIgBACIAFAEIgCADIAEACQAGAFgBAGIAAADIADAAIAAAKIADAAIAAAFIgDAAIAABHIADAAIAAAGIgDAAIAAAHIgDAAIAAAbIADAAIAAAGIADAAIAAAHIgDAAIAABkIAAAAIgLACQgJAAgEgCgAhwBfIAAAGQAAABAAAAQAAAAAAABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAgBAAAAQAAAAAAgBIAAgGIgCgBQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAAAgAhwA5IAAAhQAAAAAAAAQAAAAAAABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAgBAAAAQAAAAAAAAIAAghIgCgBQAAAAAAABQAAAAgBAAQAAAAAAAAQAAAAAAAAgAARAiQAAAAAAAAQAAAAAAABQAAAAAAAAQABAAAAAAIAgAAQAAAAABAAQAAAAAAAAQAAgBAAAAQABAAAAAAIgCgCIggAAQAAAAgBAAQAAAAAAAAQAAABAAAAQAAAAAAABgAAEAiQAAAAABAAQAAAAAAABQAAAAAAAAQABAAAAAAIAGAAQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQgBAAAAAAIgGAAQAAAAgBAAQAAAAAAAAQAAABAAAAQgBAAAAABgAA6AZIAAADIAkAAIAAgDIgCAAIAAgHIgDAAIAAgGIADAAIAAhHIgDAAIAAgFIADAAIAAgLIgGgEIgCACIgEgCIACgDIhHg3IgCADIgEgEIACgCIgHgFIAAAAIgGAFIACACIgEAEIgCgDIhHA3IACADIgFACIgCgCIgFAEIAAALIADAAIAAAFIgDAAIAABHIADAAIAAAGIgDAAIAAAHIgDAAIAAADIAkAAIAAgDIAGAAIAAADIBpAAIAAgDgABfgbIAAAFQAAABABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABgBIAAgFQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAABAAAAQgBAAAAABgAhwgbIAAAFQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIACgBIAAgFQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAABgABfhCIAAAgQAAABABAAQAAAAAAABQAAAAAAAAQABAAAAAAIABgCIAAggQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAABAAAAQgBAAAAAAgAhwhCIAAAgQAAABAAAAQAAAAAAABQABAAAAAAQAAAAAAAAIACgCIAAggQAAAAAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAAAgAhnhVQgDABgBACQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAgBAAAAQAAgEADAAIABgBIAAgBIgBgCIgBABgAAEigIACAAIABgBIgBgBQgCgCgEAAIgFACQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAIABAAIABAAQAAAAABAAQAAAAAAgBQABAAAAAAQABAAAAAAQAAAAABAAQABAAAAAAQABABAAAAQABAAAAAAg");
	this.shape_157.setTransform(167.75,167.35);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FFFFFF").s().p("AgFAHQgDgDAAgEQAAgDADgDQACgCADAAQAEAAADACQACADAAADQAAAEgCADQgDACgEAAQgDAAgCgCg");
	this.shape_158.setTransform(167.725,162.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_158},{t:this.shape_157}]},68).to({state:[]},36).to({state:[]},1).wait(73));

	// 1-T-2
	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFFFFF").s().p("AgLCiIgGgDQgEgBAAgDIgBgLQgCgKgDh7IgCgvQAAgOACg1IgBgCIgBAAQgcgBg+gFQgEgBgBgBIgCgDQAAgGAGgBIABAAIAAgKQgHAAAAgEIADgUQABgEAEgBQAZgHBrAGIBpAHQAFAAABAFIACASIgBADIgDACIgEAAIgBALIAEACIACACQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAIgCAEIgBABIhkAAIgBABIAIBpQABAUgBBIIAAAjIgCAjIAAAAIgCACQgDACgDAAIgDAAIgFAAIgBAAIAAAAIgBAAIgCABQgEAAgNgFgAAKCgIABABIAEACIADAAIABgNIgKAAgAAFhNIgBACQAFBPgCATQgBATAAAqQgBArACADQAFAAAHgCQABAAAAgBQAAAAAAAAQABAAAAgBQAAAAAAgBQgGhfABgTQACgNgDhKQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAIgFAAgAAEhgIAJACIAAAAIAAgOIAAAAIgJgBgAhniEIAAALIDNAEIAAgNQhzgEg0AAQgeAAgIACg");
	this.shape_159.setTransform(192.5214,167.731);
	this.shape_159._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_159).wait(70).to({_off:false},0).to({_off:true},34).wait(74));

	// 1-O-2
	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FFFFFF").s().p("AhwB4QgjgsAAhMQABgyARgfQAOgaAggZQAZgRAVgIQAXgJAdABQCEAAABCWQAAA2gTAmQgPAegfAaQgXASgVAIQgWAIgZAAQhDgBglgugAg/huQgRAZAAA8QAABRAZAoQAYAmAvAAQAQAAAJgDQALgFAIgLQAVgfAAhMQAAhLgXghQgXgfgwAAQghAAgRAVg");
	this.shape_160.setTransform(219.65,167.55);
	this.shape_160._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_160).wait(75).to({_off:false},0).to({_off:true},29).wait(74));

	// 1-R
	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFFFFF").s().p("AgqDFQgJgCgGgCIgOgFQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAIgCgHIABgJQACgIgBgEIgFgXIgIgZQgDgGADgXIADgbIgGgSIgFgTIgCgMIgHgPQgBgGAAgGIABgFIgGgEQAOgtABgIQAAgHgGgWQgCgGAAgFIAAgEQgBgHAFgIIAIgKQAEgEAZgNQAEgDACgFIAFgHIAIgGQAEgCAEgBIgBgBQACgBAEABIAAgCQACAAADAFQADgEADAEIAAAAIAEAGQACABADAIIgBAIQAAABABABQAAAAAAABQABAAAAAAQABABABAAQAAAGgEADQgBAAAAAAQgBAAgBABQAAAAgBAAQAAAAgBAAIgBgBIgDADIAEABQAEACAHgEQABAAAAAAQABAAAAgBQAAAAAAgBQAAgBAAgBQgDgHAFgEIADgEQAHgDALAHIAMAHIAIACIAKAAIAMACQAMAEAGAMQACAFAIACQAGAEgBAGQgBgCgDgEQgEgCgCAAIADAFIAEAEQAHAIgBAIQgDgJgIgFIADAHQACAFgCADIgCgGIAAAEIAAAAQgBAJAFAHQgEgCgCgEIgBABQgEALgCAPQgNAsgOAHQgLAGgYAAIgUAAIgCAGIAQAVIAEAAIAFAAIABAAQABAAAAABQAAAAAAAAQABAAAAABQAAAAAAABIAAAGIgBACIADACIABAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAIAAAJIADAGIADAFQABACABAFIACAGIACAAIAIADQAHAEAEAIQABADgCADIAEACIAFAAQADABAFAEQAEADACAEQAFAJgEAKIgBgHIgBAJIgBAGQAAgBgBAAQAAAAAAAAQAAABgBAAQAAABAAABQAAADACACIADAGIABAAIAEAGQABACAGACIADACIADAAQAAABABAAQAAAAgBAAQAAAAAAABQAAAAgBAAIABABQAAAAAAAAQAAABAAAAQAAAAgBAAQAAAAgBABQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAIgDgCIgEgCQgBAAAAAAQgBAAAAAAQAAABABAAQAAABABABIACADIAHAHIABABIAGAHQADADAGADQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAgBAAIgCACQAAAAAAAAQAAAAgBAAQAAAAgBAAQgBABgCAAIgFgDIgEgDIgBgBIACAGQABAAAAAAQAAABAAAAQAAAAAAAAQAAABgBAAQgDAAgCgFIgDgFIgHgHIgFgJIgLgJIgDAAQgBABAAAAQgBAAAAABQAAAAAAABQAAAAAAABIABADQgEgDAAgEIACgDQgBgBAAAAQgBAAgBgBQAAAAAAAAQgBABAAAAIgCAEIAAgBQgBgEABgCIADgDIgPgSQAAABAAABQAAAAAAABQgBAAAAABQgBAAAAAAQgEAAgEAFIgBgCQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAABgBQAAAAAAAAQABAAAAgBQAAAAAAgBQAAgBAAgBQgBABAAAAQgBAAAAAAQAAAAgBgBQAAAAAAAAIgBgBQAGACABgGQAAgBgCgGIgEgCIgGgDIgBgBIgBgEQAAgBgBAAQAAgBAAAAQgBAAAAAAQgBgBgBAAIgGgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAAAIABgCIgDgEQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAAAQgDgCACgGIADgCIADgBQABgCgEgCQgLgEgIgFQgFgCgFgHIgHgJQgHgHgEgHQAAgBgBAAQAAgBgBAAQAAAAgBAAQgBAAAAAAQgBABAAAAQgBAAAAABQAAAAgBABQAAAAAAABIgDAPIgDAUIgEALQABAEgCAFIgBAgQgBAIACAHIADADIAMALIAPAGQAAADgFACIgLABIAHADIAFAEIgIgDIANAFQADACADADQAAABABAAQAAABAAAAQAAABAAAAQAAAAgBAAQgGACgGAAIgNgBIgFgCIAXAQQAFADACADQAAADgHADIgHABIgJgBgAgriHIgGABIgCACIgBACIgCACQAHAKABAMIAAAQIgCASIgCASQAKAJAIADIADgEIALgFQANgFAHAAQAQgCACgCQAFgDAKgaQACgDgDgFQgCgEAAgCIgDgFQgEgDABgCIACgJIgGAAQAAABgBAAQAAABAAAAQAAAAgBAAQAAABAAAAQgBAAgFgEIgGgBIgEgBIgDgCQgJgFgLgCIgUgDg");
	this.shape_161.setTransform(247.825,167.55);
	this.shape_161._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_161).wait(80).to({_off:false},0).to({_off:true},24).wait(74));

	// 1-S
	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#FFFFFF").s().p("AgECmQg8AAg6gcQgIgDADgJIATgpQACgFAHAAIAEAAQA0AZAoABQA8AAABgiQAAgbgTgRQgJgIgggRQgdgOgMgMQgTgSABgdQAAgWASgPQAUgPAlAAQAjAAAlAPIALgZQgigOgxgBQgsgBgdAUQggAUgBAmQAAA7A6AbQAFADAAAFQAAADgDADQgDADgEAAIgFgBQhFghABhFQABgvAngZQAjgYAzABQAiAAAZAGQAUAFAVAKQAJAEgEAHIgSArQgCAFgHAAIgEgBQgmgRgkgBQg2gBgBAkQAAAWAPAOQAJAJAYANQAlARALALQAXAWAAAhQAAAVgPANQgUASguAAQgpgBgygWIgKAYQAwAXA0AAQAvABAegQQAjgUAAgoQABgjgSgYQgRgYgngRQgGgDAAgFQAAgFAFgDQAFgCAFACQBWAlgBBPQgBAugmAYQgiAXg4AAIgEAAg");
	this.shape_162.setTransform(272.6252,167.55);
	this.shape_162._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_162).wait(78).to({_off:false},0).to({_off:true},26).wait(74));

	// Talent
	this.mc_talent = new lib.mc_talent();
	this.mc_talent.name = "mc_talent";
	this.mc_talent.parent = this;
	this.mc_talent.setTransform(99.2,466.95,0.898,0.898,0,0,0,166.3,242.1);
	this.mc_talent.alpha = 0;
	this.mc_talent._off = true;

	this.timeline.addTween(cjs.Tween.get(this.mc_talent).wait(4).to({_off:false},0).wait(1).to({regX:300,regY:274,x:219.25,y:491.35,alpha:0.0032},0).wait(1).to({y:487.25,alpha:0.0066},0).wait(1).to({y:483.25,alpha:0.0104},0).wait(1).to({y:479.4,alpha:0.0146},0).wait(1).to({y:475.7,alpha:0.0193},0).wait(1).to({y:472.1,alpha:0.0245},0).wait(1).to({y:468.65,alpha:0.0303},0).wait(1).to({y:465.35,alpha:0.0369},0).wait(1).to({y:462.15,alpha:0.0443},0).wait(1).to({y:459.1,alpha:0.0528},0).wait(1).to({y:456.15,alpha:0.0624},0).wait(1).to({y:453.35,alpha:0.0733},0).wait(1).to({y:450.7,alpha:0.0858},0).wait(1).to({y:448.15,alpha:0.1},0).wait(1).to({y:445.75,alpha:0.1163},0).wait(1).to({y:443.45,alpha:0.135},0).wait(1).to({y:441.3,alpha:0.1563},0).wait(1).to({y:439.3,alpha:0.1806},0).wait(1).to({y:437.4,alpha:0.2083},0).wait(1).to({y:435.65,alpha:0.2397},0).wait(1).to({y:434,alpha:0.2752},0).wait(1).to({y:432.5,alpha:0.3148},0).wait(1).to({y:431.15,alpha:0.3589},0).wait(1).to({y:429.9,alpha:0.4074},0).wait(1).to({y:428.8,alpha:0.4603},0).wait(1).to({y:427.8,alpha:0.5173},0).wait(1).to({y:426.95,alpha:0.5782},0).wait(1).to({y:426.25,alpha:0.6424},0).wait(1).to({y:425.65,alpha:0.7097},0).wait(1).to({y:425.2,alpha:0.7795},0).wait(1).to({y:424.9,alpha:0.8514},0).wait(1).to({y:424.7,alpha:0.925},0).wait(1).to({regX:166.3,regY:242.1,x:99.2,y:396,alpha:1},0).wait(68).to({y:420.25,alpha:0},16,cjs.Ease.get(1)).wait(57));

	// Background
	this.mc_bg = new lib.mc_bg();
	this.mc_bg.name = "mc_bg";
	this.mc_bg.parent = this;
	this.mc_bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.mc_bg).wait(129).to({scaleX:1.4068,scaleY:1.4068,rotation:11.7482,y:300.1},24,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,rotation:0,y:300},24,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(120,284,348.1,626.2);
p.frameBounds = [rect, rect, rect, rect, new cjs.Rectangle(120,284,460.3,737.9), new cjs.Rectangle(120,284,460.4,733.6), new cjs.Rectangle(120,284,460.4,729.5), new cjs.Rectangle(120,284,460.4,725.6), new cjs.Rectangle(120,284,460.4,721.7), new cjs.Rectangle(120,284,460.4,718), new cjs.Rectangle(120,284,460.4,714.4), new cjs.Rectangle(120,284,460.4,711), new cjs.Rectangle(120,284,460.4,707.6), new cjs.Rectangle(120,284,460.4,704.5), new cjs.Rectangle(120,284,460.4,701.4), new cjs.Rectangle(120,284,460.4,698.5), new cjs.Rectangle(120,284,460.4,695.7), new cjs.Rectangle(120,284,460.4,693), new cjs.Rectangle(120,284,460.4,690.4), new cjs.Rectangle(120,284,460.4,688), new cjs.Rectangle(120,284,460.4,685.8), new cjs.Rectangle(120,284,460.4,683.6), new cjs.Rectangle(120,284,460.4,681.6), new cjs.Rectangle(120,284,460.4,679.7), new cjs.Rectangle(120,284,460.4,677.9), new cjs.Rectangle(120,284,460.4,676.3), new cjs.Rectangle(120,284,460.4,674.8), new cjs.Rectangle(120,284,460.4,673.4), new cjs.Rectangle(120,284,460.4,672.2), new cjs.Rectangle(120,284,460.4,671.1), new cjs.Rectangle(120,284,460.4,670.1), new cjs.Rectangle(120,284,460.4,669.3), new cjs.Rectangle(120,284,460.4,668.6), new cjs.Rectangle(120,284,460.4,668), new cjs.Rectangle(120,284,460.4,667.5), new cjs.Rectangle(120,284,460.4,667.2), new cjs.Rectangle(120,284,460.4,667), rect=new cjs.Rectangle(120,284,460.3,667), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, new cjs.Rectangle(120,284,460.4,669.9), new cjs.Rectangle(120,284,460.4,672.6), new cjs.Rectangle(120,284,460.4,675.2), new cjs.Rectangle(120,284,460.4,677.6), new cjs.Rectangle(120,284,460.4,679.7), new cjs.Rectangle(120,284,460.4,681.7), new cjs.Rectangle(120,284,460.4,683.5), new cjs.Rectangle(120,284,460.4,685.1), new cjs.Rectangle(120,284,460.4,686.5), new cjs.Rectangle(120,284,460.4,687.8), new cjs.Rectangle(120,284,460.4,688.8), new cjs.Rectangle(120,284,460.4,689.7), new cjs.Rectangle(120,284,460.4,690.3), new cjs.Rectangle(120,284,460.4,690.8), new cjs.Rectangle(120,284,460.4,691.1), rect=new cjs.Rectangle(120,284,460.3,691.2), rect, rect, rect, rect, rect, rect, rect, rect, rect, new cjs.Rectangle(120,275.8,460.3,699.4), new cjs.Rectangle(120,264,460.3,711.3), new cjs.Rectangle(111.1,253.2,469.3,722.1), new cjs.Rectangle(102,242.7,478.3,732.5), new cjs.Rectangle(93.1,232.7,487.2,742.5), new cjs.Rectangle(84.3,223.1,496,754), new cjs.Rectangle(75.7,214,504.6,772.2), new cjs.Rectangle(68.5,205.8,511.9,788.7), new cjs.Rectangle(60.3,197.6,520.1,805), new cjs.Rectangle(53.5,190.3,526.9,819.6), new cjs.Rectangle(46.9,183.6,533.4,833.2), new cjs.Rectangle(40.7,177.2,539.6,845.8), new cjs.Rectangle(35.9,171.9,544.4,856.7), new cjs.Rectangle(30.3,166.5,550,867.4), new cjs.Rectangle(26.2,162,554.2,876.3), new cjs.Rectangle(22.3,158,558,884.3), new cjs.Rectangle(17.6,154.1,564.8,892.2), new cjs.Rectangle(15.7,151.5,568.7,897.4), new cjs.Rectangle(12.9,148.9,574.2,902.6), new cjs.Rectangle(10.4,146.9,579.2,906.7), new cjs.Rectangle(9.6,145.7,581,909.1), new cjs.Rectangle(9,144.9,582,910.5), new cjs.Rectangle(7.5,144,585.1,912.4), new cjs.Rectangle(20.8,157.2,559.5,886.1), new cjs.Rectangle(33.4,169.6,546.9,861.3), new cjs.Rectangle(45.5,181.5,534.9,837.4), new cjs.Rectangle(55.8,192.5,524.5,815.3), new cjs.Rectangle(65.7,203,514.6,794.3), new cjs.Rectangle(75,213.1,505.3,774.1), new cjs.Rectangle(84,222.7,496.3,754.9), new cjs.Rectangle(92.5,231.8,487.9,743.5), new cjs.Rectangle(99.5,240,480.9,735.3), new cjs.Rectangle(107,248.1,473.4,727.2), new cjs.Rectangle(113.2,255.3,467.1,719.9), new cjs.Rectangle(118.9,262,461.4,713.2), new cjs.Rectangle(120,268.2,460.3,707), new cjs.Rectangle(120,273.5,460.3,701.8), new cjs.Rectangle(120,278.8,460.3,696.5), new cjs.Rectangle(120,283.2,460.3,692.1), rect=new cjs.Rectangle(120,284,460.3,691.2), rect, rect, rect, rect, rect, rect, rect];
// library properties:
lib.properties = {
	id: '47CBEC762FAA4A1C90A7FD0D708CA264',
	width: 300,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Image.png", id:"Image"},
		{src:"images/Image_1.png", id:"Image_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['47CBEC762FAA4A1C90A7FD0D708CA264'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;